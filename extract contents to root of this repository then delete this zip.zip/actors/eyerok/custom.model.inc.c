#include "custom.model.inc.h"
Vtx VB_eyerok_right_hand_geo_0x500b558[] = {
{{{ 348, 201, -202 }, 0, { 0, -16 }, { 0, 0, 129, 255}}},
{{{ 348, 0, -202 }, 0, { 0, 990 }, { 0, 0, 129, 255}}},
{{{ 0, 0, -202 }, 0, { 1702, 990 }, { 0, 0, 129, 255}}},
{{{ 348, 0, 0 }, 0, { 0, 990 }, { 0, 0, 127, 255}}},
{{{ 348, 201, 0 }, 0, { 0, -16 }, { 0, 0, 127, 255}}},
{{{ 0, 201, 0 }, 0, { 1702, -16 }, { 0, 0, 127, 255}}},
{{{ 0, 0, 0 }, 0, { 1702, 990 }, { 0, 0, 127, 255}}},
{{{ 348, 201, -202 }, 0, { 0, -16 }, { 127, 0, 0, 255}}},
{{{ 348, 0, 0 }, 0, { 990, 990 }, { 127, 0, 0, 255}}},
{{{ 348, 0, -202 }, 0, { 990, -16 }, { 127, 0, 0, 255}}},
{{{ 348, 201, 0 }, 0, { 0, 990 }, { 127, 0, 0, 255}}},
{{{ 348, 201, -202 }, 0, { 0, -16 }, { 0, 127, 0, 255}}},
{{{ 0, 201, -202 }, 0, { 1702, -16 }, { 0, 127, 0, 255}}},
{{{ 348, 201, 0 }, 0, { 0, 990 }, { 0, 127, 0, 255}}},
{{{ 0, 201, 0 }, 0, { 1702, 990 }, { 0, 127, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500b648[] = {
{{{ 348, 0, -202 }, 0, { 0, -16 }, { 0, 129, 0, 255}}},
{{{ 348, 0, 0 }, 0, { 0, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 0, 0 }, 0, { 1702, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 201, -202 }, 0, { 1702, -16 }, { 0, 0, 129, 255}}},
{{{ 348, 201, -202 }, 0, { 0, -16 }, { 0, 0, 129, 255}}},
{{{ 0, 0, -202 }, 0, { 1702, 990 }, { 0, 0, 129, 255}}},
{{{ 0, 0, -202 }, 0, { 1702, -16 }, { 0, 129, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500b7d0[] = {
{{{ 339, 201, -201 }, 0, { 1708, -16 }, { 0, 0, 130, 255}}},
{{{ 339, 0, -202 }, 0, { 1708, 990 }, { 0, 0, 130, 255}}},
{{{ 0, 0, -202 }, 0, { 3406, 990 }, { 0, 0, 130, 255}}},
{{{ 0, 0, 0 }, 0, { 3406, 990 }, { 0, 0, 127, 255}}},
{{{ 339, 0, 0 }, 0, { 1708, 990 }, { 0, 0, 127, 255}}},
{{{ 0, 201, 0 }, 0, { 3406, -16 }, { 0, 0, 127, 255}}},
{{{ 339, 201, 0 }, 0, { 1708, -16 }, { 0, 0, 127, 255}}},
{{{ 0, 201, -201 }, 0, { -16, -16 }, { 129, 0, 0, 255}}},
{{{ 0, 0, -202 }, 0, { 990, -16 }, { 129, 0, 0, 255}}},
{{{ 0, 201, 0 }, 0, { -16, 990 }, { 129, 0, 0, 255}}},
{{{ 0, 0, 0 }, 0, { 990, 990 }, { 129, 0, 0, 255}}},
{{{ 339, 201, -201 }, 0, { 1708, -16 }, { 0, 127, 0, 255}}},
{{{ 0, 201, -201 }, 0, { 3406, -16 }, { 0, 127, 0, 255}}},
{{{ 339, 201, 0 }, 0, { 1708, 990 }, { 0, 127, 0, 255}}},
{{{ 0, 201, 0 }, 0, { 3406, 990 }, { 0, 127, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500b8c0[] = {
{{{ 339, 0, -202 }, 0, { 1708, -16 }, { 0, 129, 0, 255}}},
{{{ 339, 0, 0 }, 0, { 1708, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 0, 0 }, 0, { 3406, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 201, -201 }, 0, { 3406, -16 }, { 0, 0, 130, 255}}},
{{{ 339, 201, -201 }, 0, { 1708, -16 }, { 0, 0, 130, 255}}},
{{{ 0, 0, -202 }, 0, { 3406, 990 }, { 0, 0, 130, 255}}},
{{{ 0, 0, -202 }, 0, { 3406, -16 }, { 0, 129, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500ba48[] = {
{{{ -200, 200, -100 }, 0, { -1020, -512 }, { 129, 0, 0, 255}}},
{{{ -200, -202, -100 }, 0, { 990, -512 }, { 129, 0, 0, 255}}},
{{{ -200, 200, 200 }, 0, { -1020, 990 }, { 129, 0, 0, 255}}},
{{{ -200, -202, -100 }, 0, { 5728, 990 }, { 0, 0, 129, 255}}},
{{{ -200, 200, -100 }, 0, { 5728, -1022 }, { 0, 0, 129, 255}}},
{{{ 202, -202, -100 }, 0, { 3716, 990 }, { 0, 0, 129, 255}}},
{{{ 202, 200, -100 }, 0, { 3716, -1022 }, { 0, 0, 129, 255}}},
{{{ 202, -202, 200 }, 0, { 3716, 990 }, { 0, 0, 127, 255}}},
{{{ 202, 200, 200 }, 0, { 3716, -1022 }, { 0, 0, 127, 255}}},
{{{ -200, -202, 200 }, 0, { 5728, 990 }, { 0, 0, 127, 255}}},
{{{ -200, 200, 200 }, 0, { 5728, -1022 }, { 0, 0, 127, 255}}},
{{{ -200, -202, -100 }, 0, { 5728, -512 }, { 0, 129, 0, 255}}},
{{{ 202, -202, -100 }, 0, { 3716, -512 }, { 0, 129, 0, 255}}},
{{{ -200, -202, 200 }, 0, { 5728, 990 }, { 0, 129, 0, 255}}},
{{{ 202, -202, 200 }, 0, { 3716, 990 }, { 0, 129, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500bb38[] = {
{{{ 202, 200, -100 }, 0, { 0, -512 }, { 127, 0, 0, 255}}},
{{{ 202, 200, 200 }, 0, { 0, 990 }, { 127, 0, 0, 255}}},
{{{ 202, -202, 200 }, 0, { 1980, 990 }, { 127, 0, 0, 255}}},
{{{ -200, -202, -100 }, 0, { 990, -512 }, { 129, 0, 0, 255}}},
{{{ -200, -202, 200 }, 0, { 990, 990 }, { 129, 0, 0, 255}}},
{{{ -200, 200, 200 }, 0, { -1020, 990 }, { 129, 0, 0, 255}}},
{{{ 202, 200, -100 }, 0, { 3716, -512 }, { 0, 127, 0, 255}}},
{{{ -200, 200, -100 }, 0, { 5728, -512 }, { 0, 127, 0, 255}}},
{{{ 202, 200, 200 }, 0, { 3716, 990 }, { 0, 127, 0, 255}}},
{{{ -200, 200, 200 }, 0, { 5728, 990 }, { 0, 127, 0, 255}}},
{{{ 202, -202, -100 }, 0, { 1980, -512 }, { 127, 0, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500bd10[] = {
{{{ 403, 0, 101 }, 0, { 990, 990 }, { 127, 0, 0, 255}}},
{{{ 403, 0, -100 }, 0, { -16, 990 }, { 127, 0, 0, 255}}},
{{{ 403, 201, 101 }, 0, { 990, -16 }, { 127, 0, 0, 255}}},
{{{ 0, 201, 101 }, 0, { -34, 974 }, { 0, 127, 0, 255}}},
{{{ 403, 201, 101 }, 0, { 1978, 974 }, { 0, 127, 0, 255}}},
{{{ 0, 201, -100 }, 0, { -34, 0 }, { 0, 127, 0, 255}}},
{{{ 403, 201, -100 }, 0, { 1978, 0 }, { 0, 127, 0, 255}}},
{{{ 403, 0, -100 }, 0, { 1978, 0 }, { 0, 129, 0, 255}}},
{{{ 403, 0, 101 }, 0, { 1978, 974 }, { 0, 129, 0, 255}}},
{{{ 0, 0, 101 }, 0, { -34, 974 }, { 0, 129, 0, 255}}},
{{{ 0, 0, -100 }, 0, { -34, 0 }, { 0, 129, 0, 255}}},
{{{ 403, 0, -100 }, 0, { 1982, 990 }, { 0, 0, 129, 255}}},
{{{ 0, 0, -100 }, 0, { 0, 990 }, { 0, 0, 129, 255}}},
{{{ 403, 201, -100 }, 0, { 1982, -16 }, { 0, 0, 129, 255}}},
{{{ 0, 201, -100 }, 0, { 0, -16 }, { 0, 0, 129, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500be00[] = {
{{{ 403, 0, 101 }, 0, { 1982, 990 }, { 0, 0, 127, 255}}},
{{{ 403, 201, 101 }, 0, { 1982, -16 }, { 0, 0, 127, 255}}},
{{{ 0, 201, 101 }, 0, { 0, -16 }, { 0, 0, 127, 255}}},
{{{ 403, 0, -100 }, 0, { -16, 990 }, { 127, 0, 0, 255}}},
{{{ 403, 201, -100 }, 0, { -16, -16 }, { 127, 0, 0, 255}}},
{{{ 403, 201, 101 }, 0, { 990, -16 }, { 127, 0, 0, 255}}},
{{{ 0, 0, 101 }, 0, { 0, 990 }, { 0, 0, 127, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500bf88[] = {
{{{ 1, 0, 101 }, 0, { -16, -1024 }, { 0, 0, 127, 255}}},
{{{ 405, 0, 101 }, 0, { -16, 990 }, { 0, 0, 127, 255}}},
{{{ 1, 201, 101 }, 0, { 990, -1024 }, { 0, 0, 127, 255}}},
{{{ 1, 0, -100 }, 0, { -16, -1024 }, { 0, 129, 0, 255}}},
{{{ 405, 0, -100 }, 0, { -16, 990 }, { 0, 129, 0, 255}}},
{{{ 1, 0, 101 }, 0, { 990, -1024 }, { 0, 129, 0, 255}}},
{{{ 405, 0, 101 }, 0, { 990, 990 }, { 0, 129, 0, 255}}},
{{{ 1, 201, 101 }, 0, { 990, -1024 }, { 0, 127, 0, 255}}},
{{{ 405, 201, 101 }, 0, { 990, 990 }, { 0, 127, 0, 255}}},
{{{ 1, 201, -100 }, 0, { -16, -1024 }, { 0, 127, 0, 255}}},
{{{ 405, 201, -100 }, 0, { -16, 990 }, { 0, 127, 0, 255}}},
{{{ 405, 0, -100 }, 0, { -16, 990 }, { 0, 0, 129, 255}}},
{{{ 1, 0, -100 }, 0, { -16, -1024 }, { 0, 0, 129, 255}}},
{{{ 405, 201, -100 }, 0, { 990, 990 }, { 0, 0, 129, 255}}},
{{{ 1, 201, -100 }, 0, { 990, -1024 }, { 0, 0, 129, 255}}},
{{{ 405, 201, 101 }, 0, { 990, 990 }, { 0, 0, 127, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c188[] = {
{{{ 403, 0, -100 }, 0, { 986, -16 }, { 0, 129, 0, 255}}},
{{{ 403, 0, 101 }, 0, { 986, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 0, 101 }, 0, { -1024, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 201, 101 }, 0, { -1024, 990 }, { 0, 127, 0, 255}}},
{{{ 403, 201, 101 }, 0, { 988, 990 }, { 0, 127, 0, 255}}},
{{{ 0, 201, -100 }, 0, { -1024, -16 }, { 0, 127, 0, 255}}},
{{{ 403, 201, -100 }, 0, { 988, -16 }, { 0, 127, 0, 255}}},
{{{ 0, 0, -100 }, 0, { 990, -16 }, { 129, 0, 0, 255}}},
{{{ 0, 0, 101 }, 0, { -16, -16 }, { 129, 0, 0, 255}}},
{{{ 0, 201, -100 }, 0, { 990, -1022 }, { 129, 0, 0, 255}}},
{{{ 0, 201, 101 }, 0, { -16, -1022 }, { 129, 0, 0, 255}}},
{{{ 403, 0, -100 }, 0, { 990, -16 }, { 0, 0, 129, 255}}},
{{{ 0, 0, -100 }, 0, { -1022, -16 }, { 0, 0, 129, 255}}},
{{{ 403, 201, -100 }, 0, { 990, 990 }, { 0, 0, 129, 255}}},
{{{ 0, 201, -100 }, 0, { -1022, 990 }, { 0, 0, 129, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c278[] = {
{{{ 403, 0, 101 }, 0, { 0, -16 }, { 0, 0, 127, 255}}},
{{{ 403, 201, 101 }, 0, { 0, 990 }, { 0, 0, 127, 255}}},
{{{ 0, 201, 101 }, 0, { 1982, 990 }, { 0, 0, 127, 255}}},
{{{ 0, 0, -100 }, 0, { -1024, -16 }, { 0, 129, 0, 255}}},
{{{ 403, 0, -100 }, 0, { 986, -16 }, { 0, 129, 0, 255}}},
{{{ 0, 0, 101 }, 0, { -1024, 990 }, { 0, 129, 0, 255}}},
{{{ 0, 0, 101 }, 0, { 1982, -16 }, { 0, 0, 127, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c400[] = {
{{{ 464, 12, -523 }, 0, { 0, 0 }, { 0, 0, 129, 255}}},
{{{ -3, -2, -523 }, 0, { 2306, 0 }, { 0, 0, 129, 255}}},
{{{ 330, 409, -523 }, 0, { 576, 1966 }, { 0, 0, 129, 255}}},
{{{ -3, -2, -523 }, 0, { 2304, -3034 }, { 3, 130, 0, 255}}},
{{{ 464, 12, -523 }, 0, { 0, -3034 }, { 3, 130, 0, 255}}},
{{{ -3, -2, 282 }, 0, { 2304, 990 }, { 3, 130, 0, 255}}},
{{{ 464, 12, 282 }, 0, { 0, 990 }, { 3, 130, 0, 255}}},
{{{ -16, 398, 282 }, 0, { 2368, 990 }, { 252, 126, 0, 255}}},
{{{ 330, 409, 282 }, 0, { 640, 990 }, { 252, 126, 0, 255}}},
{{{ -16, 398, -523 }, 0, { 2368, -3034 }, { 252, 126, 0, 255}}},
{{{ 330, 409, -523 }, 0, { 640, -3034 }, { 252, 126, 0, 255}}},
{{{ -3, -2, -523 }, 0, { -3032, -50 }, { 130, 252, 0, 255}}},
{{{ -3, -2, 282 }, 0, { 990, -50 }, { 130, 252, 0, 255}}},
{{{ -16, 398, -523 }, 0, { -3032, 1948 }, { 130, 252, 0, 255}}},
{{{ -16, 398, 282 }, 0, { 990, 1948 }, { 130, 252, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c4f0[] = {
{{{ 464, 12, 282 }, 0, { 0, 0 }, { 0, 0, 127, 255}}},
{{{ 330, 409, 282 }, 0, { 576, 1966 }, { 0, 0, 127, 255}}},
{{{ -16, 398, 282 }, 0, { 2306, 1966 }, { 0, 0, 127, 255}}},
{{{ -3, -2, -523 }, 0, { 2306, 0 }, { 0, 0, 129, 255}}},
{{{ -16, 398, -523 }, 0, { 2306, 1966 }, { 0, 0, 129, 255}}},
{{{ 330, 409, -523 }, 0, { 576, 1966 }, { 0, 0, 129, 255}}},
{{{ 464, 12, 282 }, 0, { 990, 0 }, { 120, 40, 0, 255}}},
{{{ 464, 12, -523 }, 0, { -3032, 0 }, { 120, 40, 0, 255}}},
{{{ 330, 409, 282 }, 0, { 990, 1946 }, { 120, 40, 0, 255}}},
{{{ 330, 409, -523 }, 0, { -3032, 1946 }, { 120, 40, 0, 255}}},
{{{ -3, -2, 282 }, 0, { 2306, 0 }, { 0, 0, 127, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c6c8[] = {
{{{ 273, 357, 281 }, 0, { 2306, 1978 }, { 0, 0, 127, 255}}},
{{{ -89, 181, 281 }, 0, { 4318, 1978 }, { 0, 0, 127, 255}}},
{{{ 86, -181, 281 }, 0, { 4318, 0 }, { 0, 0, 127, 255}}},
{{{ 86, -181, -522 }, 0, { 4316, -3022 }, { 55, 142, 0, 255}}},
{{{ 449, -5, 281 }, 0, { 2304, 990 }, { 55, 142, 0, 255}}},
{{{ 86, -181, 281 }, 0, { 4316, 990 }, { 55, 142, 0, 255}}},
{{{ 449, -5, -522 }, 0, { 2304, -3022 }, { 55, 142, 0, 255}}},
{{{ -89, 181, 281 }, 0, { 4380, 990 }, { 201, 114, 0, 255}}},
{{{ 273, 357, -522 }, 0, { 2370, -3022 }, { 201, 114, 0, 255}}},
{{{ -89, 181, -522 }, 0, { 4380, -3022 }, { 201, 114, 0, 255}}},
{{{ 273, 357, 281 }, 0, { 2370, 990 }, { 201, 114, 0, 255}}},
{{{ -89, 181, 281 }, 0, { 0, 990 }, { 142, 201, 0, 255}}},
{{{ 86, -181, -522 }, 0, { 3980, -1022 }, { 142, 201, 0, 255}}},
{{{ 86, -181, 281 }, 0, { 0, -1022 }, { 142, 201, 0, 255}}},
{{{ -89, 181, -522 }, 0, { 3980, 990 }, { 142, 201, 0, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c7b8[] = {
{{{ -89, 181, -522 }, 0, { 4318, 1978 }, { 0, 0, 129, 255}}},
{{{ 273, 357, -522 }, 0, { 2306, 1978 }, { 0, 0, 129, 255}}},
{{{ 449, -5, -522 }, 0, { 2306, 0 }, { 0, 0, 129, 255}}},
{{{ 273, 357, 281 }, 0, { 2306, 1978 }, { 0, 0, 127, 255}}},
{{{ 86, -181, 281 }, 0, { 4318, 0 }, { 0, 0, 127, 255}}},
{{{ 449, -5, 281 }, 0, { 2306, 0 }, { 0, 0, 127, 255}}},
{{{ 273, 357, -522 }, 0, { -3020, 990 }, { 114, 55, 0, 255}}},
{{{ 449, -5, 281 }, 0, { 990, -1056 }, { 114, 55, 0, 255}}},
{{{ 449, -5, -522 }, 0, { -3020, -1056 }, { 114, 55, 0, 255}}},
{{{ 273, 357, 281 }, 0, { 990, 990 }, { 114, 55, 0, 255}}},
{{{ 86, -181, -522 }, 0, { 4318, 0 }, { 0, 0, 129, 255}}},
};

Vtx VB_eyerok_right_hand_geo_0x500c978[] = {
{{{ 212, 365, 63 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 212, 365, -255 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -73, 190, -255 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ -73, 190, 63 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Gfx DL_eyerok_left_hand_geo_0x500cc18[] = {
gsSPGeometryMode(G_CULL_BACK, 0),
gsSPGeometryMode(0, G_CULL_FRONT),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500c3f0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500c3e8 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500c640[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500c5a0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500c5a0[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500c3f0.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500c3e8.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c400, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 6, 5, 0,7, 8, 9, 0),
gsSP2Triangles(8, 10, 9, 0,11, 12, 13, 0),
gsSP1Triangle(12, 14, 13, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c4f0, 11, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,7, 9, 8, 0),
gsSP1Triangle(10, 0, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500bd00 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500bcf8 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500bf00[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500be70),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500be70[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500bd00.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500bcf8.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500bd10, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 6, 5, 0,7, 8, 9, 0),
gsSP2Triangles(10, 7, 9, 0,11, 12, 13, 0),
gsSP1Triangle(12, 14, 13, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500be00, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP1Triangle(6, 0, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500bf78 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500bf70 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500c100[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500c088),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500c088[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500bf78.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500bf70.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500bf88, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 6, 5, 0,7, 8, 9, 0),
gsSP2Triangles(8, 10, 9, 0,11, 12, 13, 0),
gsSP2Triangles(12, 14, 13, 0,1, 15, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500c178 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500c170 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500c378[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500c2e8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500c2e8[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500c178.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500c170.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c188, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 6, 5, 0,7, 8, 9, 0),
gsSP2Triangles(8, 10, 9, 0,11, 12, 13, 0),
gsSP1Triangle(12, 14, 13, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c278, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP1Triangle(6, 0, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500c6b8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500c6b0 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500c908[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500c868),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500c868[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500c6b8.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500c6b0.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c6c8, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 6, 4, 0,7, 8, 9, 0),
gsSP2Triangles(7, 10, 8, 0,11, 12, 13, 0),
gsSP1Triangle(11, 14, 12, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c7b8, 11, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,6, 9, 7, 0),
gsSP1Triangle(0, 2, 10, 0),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500c9b8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05009540),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c978, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500ca50[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05009D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c978, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500cae8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_0500A540),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c978, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500cb80[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_0500AD40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_eyerok_left_hand_geo_0x500c978, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500ba38 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500ba30 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500bc88[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500bbe8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500bbe8[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500ba38.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500ba30.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500ba48, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 6, 5, 0,7, 8, 9, 0),
gsSP2Triangles(8, 10, 9, 0,11, 12, 13, 0),
gsSP1Triangle(12, 14, 13, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500bb38, 11, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,7, 9, 8, 0),
gsSP1Triangle(10, 0, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500b548 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500b540 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500b748[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500b6b8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500b6b8[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500b548.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500b540.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500b558, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 3, 5, 0,7, 8, 9, 0),
gsSP2Triangles(7, 10, 8, 0,11, 12, 13, 0),
gsSP1Triangle(12, 14, 13, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500b648, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP1Triangle(6, 0, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_eyerok_left_hand_geo_0x500b7c0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_eyerok_left_hand_geo_0x500b7b8 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_eyerok_left_hand_geo_0x500b9c0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_eyerok_left_hand_geo_0x500b930),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500b930[] = {
gsDPSetTextureImage(0, 2, 1, eyerok_left_hand_geo__texture_05008D40),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_eyerok_left_hand_geo_0x500b7c0.col, 1),
gsSPLight(&Light_eyerok_left_hand_geo_0x500b7b8.col, 2),
gsSPVertex(VB_eyerok_left_hand_geo_0x500b7d0, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 6, 5, 0,7, 8, 9, 0),
gsSP2Triangles(8, 10, 9, 0,11, 12, 13, 0),
gsSP1Triangle(12, 14, 13, 0),
gsSPVertex(VB_eyerok_left_hand_geo_0x500b8c0, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP1Triangle(6, 0, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_eyerok_left_hand_geo_0x500cc30[] = {
gsSPGeometryMode(G_CULL_FRONT, 0),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

