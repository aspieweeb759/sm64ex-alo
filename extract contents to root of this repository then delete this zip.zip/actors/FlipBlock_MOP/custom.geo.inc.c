const GeoLayout FlipBlock_MOP[]= {
GEO_SHADOW(10,180,128),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(0,DL_FlipBlock_MOP_0x5f1710),
GEO_CLOSE_NODE(),
GEO_END(),
};
