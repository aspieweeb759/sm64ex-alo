#ifndef Flipswitch_Panel_MOP_Flipswitch_Panel_MOP_model_HEADER_H
#define Flipswitch_Panel_MOP_Flipswitch_Panel_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Flipswitch_Panel_MOP_0x5fa830[];
extern Vtx VB_Flipswitch_Panel_MOP_0x5fa920[];
extern Vtx VB_Flipswitch_Panel_MOP_0x5faa10[];
extern Vtx VB_Flipswitch_Panel_MOP_0x5fab00[];
extern Vtx VB_Flipswitch_Panel_MOP_0x5fabf0[];
extern Vtx VB_Flipswitch_Panel_MOP_0x5face0[];
extern u8 Flipswitch_Panel_MOP__texture_005FA030[];
extern Light_t Light_Flipswitch_Panel_MOP_0x5fa020;
extern Ambient_t Light_Flipswitch_Panel_MOP_0x5fa028;
extern Gfx DL_Flipswitch_Panel_MOP_0x5fadd0[];
extern u8 Flipswitch_Panel_MOP__texture_005FB1A0[];
extern Gfx DL_Flipswitch_Panel_MOP_0x5fb0b0[];
extern Gfx DL_Flipswitch_Panel_MOP_0x5fae20[];
extern u8 Flipswitch_Panel_MOP__texture_005FB9A0[];
extern Gfx DL_Flipswitch_Panel_MOP_0x5fb110[];
#endif