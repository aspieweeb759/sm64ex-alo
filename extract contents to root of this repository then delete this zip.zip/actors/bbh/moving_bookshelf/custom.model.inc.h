#ifndef bbh_moving_bookshelf_model_HEADER_H
#define bbh_moving_bookshelf_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_000610_0x701fb38[];
extern Vtx VB_geo_bbh_000610_0x701fb78[];
extern u8 geo_bbh_000610__texture_09003800[];
extern u8 geo_bbh_000610__texture_09002800[];
extern Light_t Light_geo_bbh_000610_0x701fb28;
extern Ambient_t Light_geo_bbh_000610_0x701fb20;
extern Gfx DL_geo_bbh_000610_0x701fd28[];
extern Gfx DL_geo_bbh_000610_0x701fc78[];
extern Gfx DL_geo_bbh_000610_0x701fcc0[];
#endif