#ifndef bbh_staircase_step_model_HEADER_H
#define bbh_staircase_step_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_0005B0_0x701f0f8[];
extern Vtx VB_geo_bbh_0005B0_0x701f138[];
extern u8 geo_bbh_0005B0__texture_0900A000[];
extern u8 geo_bbh_0005B0__texture_09005000[];
extern Light_t Light_geo_bbh_0005B0_0x701f0e8;
extern Ambient_t Light_geo_bbh_0005B0_0x701f0e0;
extern Gfx DL_geo_bbh_0005B0_0x701f2e8[];
extern Gfx DL_geo_bbh_0005B0_0x701f238[];
extern Gfx DL_geo_bbh_0005B0_0x701f280[];
#endif