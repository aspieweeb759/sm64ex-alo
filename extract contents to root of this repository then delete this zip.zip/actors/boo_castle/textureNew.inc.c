ALIGNED8 u8 boo_castle_geo__texture_06016760[] = {
#include "actors/boo_castle/boo_castle_geo_0x6016760_custom.rgba16.inc.c"
};
ALIGNED8 u8 boo_castle_geo__texture_06015760[] = {
#include "actors/boo_castle/boo_castle_geo_0x6015760_custom.rgba16.inc.c"
};
