ALIGNED8 u8 dirt_animation_geo__texture_0302BDF8[] = {
#include "actors/dirt_animation/dirt_animation_geo_0x302bdf8_custom.rgba16.inc.c"
};
