#ifndef bowser_2_tilting_platform_model_HEADER_H
#define bowser_2_tilting_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_2_geo_000170_0x7000800[];
extern Vtx VB_bowser_2_geo_000170_0x7000900[];
extern Vtx VB_bowser_2_geo_000170_0x7000a00[];
extern Vtx VB_bowser_2_geo_000170_0x7000aa0[];
extern Vtx VB_bowser_2_geo_000170_0x7000ba0[];
extern Vtx VB_bowser_2_geo_000170_0x7000c30[];
extern u8 bowser_2_geo_000170__texture_09009800[];
extern u8 bowser_2_geo_000170__texture_09003000[];
extern u8 bowser_2_geo_000170__texture_09005800[];
extern u8 bowser_2_geo_000170__texture_09005000[];
extern Gfx DL_bowser_2_geo_000170_0x7000fe0[];
extern Gfx DL_bowser_2_geo_000170_0x7000d30[];
extern Gfx DL_bowser_2_geo_000170_0x7000e28[];
extern Gfx DL_bowser_2_geo_000170_0x7000ed0[];
extern Gfx DL_bowser_2_geo_000170_0x7000f38[];
#endif