ALIGNED8 u8 Flipswap_Platform_MOP__texture_005F8780[] = {
#include "actors/Flipswap_Platform_MOP/Flipswap_Platform_MOP_0x5f8780_custom.rgba16.inc.c"
};
