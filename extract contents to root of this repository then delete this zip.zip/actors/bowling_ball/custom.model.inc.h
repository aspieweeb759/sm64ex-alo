#ifndef bowling_ball_bowling_ball_model_HEADER_H
#define bowling_ball_bowling_ball_model_HEADER_H
#include "types.h"
extern Vtx VB_bowling_ball_track_geo_0x8022bb8[];
extern Vtx VB_bowling_ball_track_geo_0x8022bf8[];
extern u8 bowling_ball_geo__texture_0801DA60[];
extern u8 bowling_ball_geo__texture_0801EA60[];
extern Gfx DL_bowling_ball_geo_0x8022d08[];
extern Gfx DL_bowling_ball_geo_0x8022c38[];
#endif