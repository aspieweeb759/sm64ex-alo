const GeoLayout castle_geo_001940[]= {
GEO_CULLING_RADIUS(550),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_geo_001940_0x7068b10),
GEO_CLOSE_NODE(),
GEO_END(),
};
