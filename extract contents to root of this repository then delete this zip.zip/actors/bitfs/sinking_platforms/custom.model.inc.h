#ifndef bitfs_sinking_platforms_model_HEADER_H
#define bitfs_sinking_platforms_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000770_0x7011808[];
extern Vtx VB_bitfs_geo_000770_0x7011908[];
extern Vtx VB_bitfs_geo_000770_0x7011988[];
extern Vtx VB_bitfs_geo_000770_0x7011a68[];
extern u8 bitfs_geo_000770__texture_09002000[];
extern Gfx DL_bitfs_geo_000770_0x7011ba0[];
extern Gfx DL_bitfs_geo_000770_0x7011ab8[];
extern Gfx DL_bitfs_geo_000770_0x7011b48[];
#endif