#ifndef bitfs_11_model_HEADER_H
#define bitfs_11_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000588_0x70079c8[];
extern Vtx VB_bitfs_geo_000588_0x7007ac8[];
extern Vtx VB_bitfs_geo_000588_0x7007b08[];
extern Vtx VB_bitfs_geo_000588_0x7007bf8[];
extern Vtx VB_bitfs_geo_000588_0x7007ce8[];
extern Vtx VB_bitfs_geo_000588_0x7007de8[];
extern Vtx VB_bitfs_geo_000588_0x7007ee8[];
extern Vtx VB_bitfs_geo_000588_0x7007fd8[];
extern Vtx VB_bitfs_geo_000588_0x70080b8[];
extern Vtx VB_bitfs_geo_000588_0x70081b8[];
extern Vtx VB_bitfs_geo_000588_0x70082a8[];
extern Vtx VB_bitfs_geo_000588_0x7008368[];
extern Vtx VB_bitfs_geo_000588_0x7008468[];
extern Vtx VB_bitfs_geo_000588_0x7008548[];
extern Vtx VB_bitfs_geo_000588_0x70085a8[];
extern Vtx VB_bitfs_geo_000588_0x70086a8[];
extern Vtx VB_bitfs_geo_000588_0x7008728[];
extern Vtx VB_bitfs_geo_000588_0x7008828[];
extern Vtx VB_bitfs_geo_000588_0x7008928[];
extern u8 bitfs_geo_000588__texture_09001000[];
extern u8 bitfs_geo_000588__texture_09001800[];
extern u8 bitfs_geo_000588__texture_09007000[];
extern u8 bitfs_geo_000588__texture_09000800[];
extern u8 bitfs_geo_000588__texture_09007800[];
extern u8 bitfs_geo_000588__texture_07001800[];
extern Gfx DL_bitfs_geo_000588_0x7008f48[];
extern Gfx DL_bitfs_geo_000588_0x70089e8[];
extern Gfx DL_bitfs_geo_000588_0x7008a68[];
extern Gfx DL_bitfs_geo_000588_0x7008ce0[];
extern Gfx DL_bitfs_geo_000588_0x7008db8[];
extern Gfx DL_bitfs_geo_000588_0x7008e20[];
extern Gfx DL_bitfs_geo_000588_0x7008e68[];
extern Gfx DL_bitfs_geo_000588_0x7008f18[];
#endif