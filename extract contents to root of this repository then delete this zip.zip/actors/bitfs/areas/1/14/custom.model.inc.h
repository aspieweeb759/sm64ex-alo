#ifndef bitfs_14_model_HEADER_H
#define bitfs_14_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0005D0_0x7009670[];
extern Vtx VB_bitfs_geo_0005D0_0x7009770[];
extern Vtx VB_bitfs_geo_0005D0_0x7009870[];
extern Vtx VB_bitfs_geo_0005D0_0x7009960[];
extern Vtx VB_bitfs_geo_0005D0_0x7009a60[];
extern Vtx VB_bitfs_geo_0005D0_0x7009b50[];
extern Vtx VB_bitfs_geo_0005D0_0x7009c40[];
extern Vtx VB_bitfs_geo_0005D0_0x7009d30[];
extern Vtx VB_bitfs_geo_0005D0_0x7009e30[];
extern Vtx VB_bitfs_geo_0005D0_0x7009f30[];
extern Vtx VB_bitfs_geo_0005D0_0x700a010[];
extern Vtx VB_bitfs_geo_0005D0_0x700a100[];
extern Vtx VB_bitfs_geo_0005D0_0x700a1f0[];
extern Vtx VB_bitfs_geo_0005D0_0x700a2e0[];
extern Vtx VB_bitfs_geo_0005D0_0x700a3e0[];
extern Vtx VB_bitfs_geo_0005D0_0x700a4a0[];
extern u8 bitfs_geo_0005D0__texture_09001800[];
extern Gfx DL_bitfs_geo_0005D0_0x700aa00[];
extern Gfx DL_bitfs_geo_0005D0_0x700a520[];
extern Gfx DL_bitfs_geo_0005D0_0x700a9d0[];
#endif