#ifndef bitfs_15_model_HEADER_H
#define bitfs_15_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0005E8_0x700aa78[];
extern u8 bitfs_geo_0005E8__texture_09003800[];
extern Gfx DL_bitfs_geo_0005E8_0x700ab90[];
extern Gfx DL_bitfs_geo_0005E8_0x700ab38[];
#endif