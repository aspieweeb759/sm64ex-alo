#ifndef bitfs_20_model_HEADER_H
#define bitfs_20_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000660_0x700ee10[];
extern Vtx VB_bitfs_geo_000660_0x700ef10[];
extern Vtx VB_bitfs_geo_000660_0x700eff0[];
extern u8 bitfs_geo_000660__texture_09001000[];
extern Gfx DL_bitfs_geo_000660_0x700f1c8[];
extern Gfx DL_bitfs_geo_000660_0x700f0e0[];
#endif