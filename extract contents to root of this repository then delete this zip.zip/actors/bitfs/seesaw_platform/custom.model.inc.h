#ifndef bitfs_seesaw_platform_model_HEADER_H
#define bitfs_seesaw_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000788_0x7011c18[];
extern Vtx VB_bitfs_geo_000788_0x7011d18[];
extern u8 bitfs_geo_000788__texture_09001800[];
extern Gfx DL_bitfs_geo_000788_0x7011e28[];
extern Gfx DL_bitfs_geo_000788_0x7011d98[];
#endif