#ifndef bitfs_sinking_cage_platform_model_HEADER_H
#define bitfs_sinking_cage_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000690_0x700f590[];
extern u8 bitfs_geo_000690__texture_07000000[];
extern Gfx DL_bitfs_geo_000690_0x700f6a8[];
extern Gfx DL_bitfs_geo_000690_0x700f650[];
#endif