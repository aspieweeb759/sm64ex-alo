ALIGNED8 u8 Checkpoint_Flag_MOP__texture_00604410[] = {
#include "actors/Checkpoint_Flag_MOP/Checkpoint_Flag_MOP_0x604410_custom.rgba16.inc.c"
};
ALIGNED8 u8 Checkpoint_Flag_MOP__texture_00604C10[] = {
#include "actors/Checkpoint_Flag_MOP/Checkpoint_Flag_MOP_0x604c10_custom.rgba16.inc.c"
};
