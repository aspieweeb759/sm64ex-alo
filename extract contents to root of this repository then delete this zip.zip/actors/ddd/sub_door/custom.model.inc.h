#ifndef ddd_sub_door_model_HEADER_H
#define ddd_sub_door_model_HEADER_H
#include "types.h"
extern Vtx VB_ddd_geo_000478_0x7008fd0[];
extern Vtx VB_ddd_geo_000478_0x7009098[];
extern Vtx VB_ddd_geo_000478_0x7009190[];
extern Gfx DL_ddd_geo_000478_0x7009030[];
extern Gfx DL_ddd_geo_000478_0x7009010[];
extern u8 ddd_geo_000478__texture_07001800[];
extern Light_t Light_ddd_geo_000478_0x7009088;
extern Ambient_t Light_ddd_geo_000478_0x7009080;
extern Gfx DL_ddd_geo_000478_0x7009120[];
extern Gfx DL_ddd_geo_000478_0x70090d8[];
extern u8 ddd_geo_000478__texture_07000000[];
extern Gfx DL_ddd_geo_000478_0x7009208[];
extern Gfx DL_ddd_geo_000478_0x70091d0[];
#endif