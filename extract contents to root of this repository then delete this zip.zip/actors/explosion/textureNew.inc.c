ALIGNED8 u8 explosion_geo__texture_03000A08[] = {
#include "actors/explosion/explosion_geo_0x3000a08_custom.rgba16.inc.c"
};
ALIGNED8 u8 explosion_geo__texture_03001208[] = {
#include "actors/explosion/explosion_geo_0x3001208_custom.rgba16.inc.c"
};
ALIGNED8 u8 explosion_geo__texture_03001A08[] = {
#include "actors/explosion/explosion_geo_0x3001a08_custom.rgba16.inc.c"
};
ALIGNED8 u8 explosion_geo__texture_03002208[] = {
#include "actors/explosion/explosion_geo_0x3002208_custom.rgba16.inc.c"
};
ALIGNED8 u8 explosion_geo__texture_03002A08[] = {
#include "actors/explosion/explosion_geo_0x3002a08_custom.rgba16.inc.c"
};
ALIGNED8 u8 explosion_geo__texture_03003208[] = {
#include "actors/explosion/explosion_geo_0x3003208_custom.rgba16.inc.c"
};
ALIGNED8 u8 explosion_geo__texture_03003A08[] = {
#include "actors/explosion/explosion_geo_0x3003a08_custom.rgba16.inc.c"
};
