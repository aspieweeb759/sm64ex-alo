#ifndef ccm_snowman_base_model_HEADER_H
#define ccm_snowman_base_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_0003F0_0x7012158[];
extern Vtx VB_ccm_geo_0003F0_0x7012258[];
extern Vtx VB_ccm_geo_0003F0_0x7012358[];
extern Vtx VB_ccm_geo_0003F0_0x7012458[];
extern Vtx VB_ccm_geo_0003F0_0x7012558[];
extern Vtx VB_ccm_geo_0003F0_0x7012658[];
extern Vtx VB_ccm_geo_0003F0_0x7012758[];
extern Vtx VB_ccm_geo_0003F0_0x7012858[];
extern u8 ccm_geo_0003F0__texture_07011958[];
extern Light_t Light_ccm_geo_0003F0_0x7011948;
extern Ambient_t Light_ccm_geo_0003F0_0x7011940;
extern Gfx DL_ccm_geo_0003F0_0x7012bd8[];
extern Gfx DL_ccm_geo_0003F0_0x70128e8[];
#endif