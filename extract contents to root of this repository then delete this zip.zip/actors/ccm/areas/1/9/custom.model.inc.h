#ifndef ccm_9_model_HEADER_H
#define ccm_9_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_0004BC_0x700fb90[];
extern u8 ccm_geo_0004BC__texture_09000800[];
extern Light_t Light_ccm_geo_0004BC_0x700fb80;
extern Ambient_t Light_ccm_geo_0004BC_0x700fb78;
extern Gfx DL_ccm_geo_0004BC_0x700fd08[];
extern Gfx DL_ccm_geo_0004BC_0x700fc90[];
#endif