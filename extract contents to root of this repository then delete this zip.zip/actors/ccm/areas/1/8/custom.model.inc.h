#ifndef ccm_8_model_HEADER_H
#define ccm_8_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_000494_0x700f818[];
extern Vtx VB_ccm_geo_000494_0x700f878[];
extern Vtx VB_ccm_geo_000494_0x700f968[];
extern u8 ccm_geo_000494__texture_09008000[];
extern u8 ccm_geo_000494__texture_07001900[];
extern Light_t Light_ccm_geo_000494_0x700f808;
extern Ambient_t Light_ccm_geo_000494_0x700f800;
extern Gfx DL_ccm_geo_000494_0x700fb00[];
extern Gfx DL_ccm_geo_000494_0x700fa18[];
extern Gfx DL_ccm_geo_000494_0x700fa70[];
#endif