#ifndef ccm_7_model_HEADER_H
#define ccm_7_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_00045C_0x700ea48[];
extern Vtx VB_ccm_geo_00045C_0x700eae8[];
extern Vtx VB_ccm_geo_00045C_0x700ebd8[];
extern Vtx VB_ccm_geo_00045C_0x700ecb8[];
extern Vtx VB_ccm_geo_00045C_0x700ed98[];
extern Vtx VB_ccm_geo_00045C_0x700ee38[];
extern Vtx VB_ccm_geo_00045C_0x700ef38[];
extern Vtx VB_ccm_geo_00045C_0x700ef98[];
extern Vtx VB_ccm_geo_00045C_0x700f058[];
extern Vtx VB_ccm_geo_00045C_0x700f148[];
extern Vtx VB_ccm_geo_00045C_0x700f4c0[];
extern Vtx VB_ccm_geo_00045C_0x700f500[];
extern Vtx VB_ccm_geo_00045C_0x700f6f8[];
extern u8 ccm_geo_00045C__texture_09008800[];
extern u8 ccm_geo_00045C__texture_09005000[];
extern u8 ccm_geo_00045C__texture_09008000[];
extern Light_t Light_ccm_geo_00045C_0x700ea08;
extern Light_t Light_ccm_geo_00045C_0x700ea20;
extern Light_t Light_ccm_geo_00045C_0x700ea38;
extern Ambient_t Light_ccm_geo_00045C_0x700ea00;
extern Ambient_t Light_ccm_geo_00045C_0x700ea18;
extern Ambient_t Light_ccm_geo_00045C_0x700ea30;
extern Gfx DL_ccm_geo_00045C_0x700f440[];
extern Gfx DL_ccm_geo_00045C_0x700f1b8[];
extern Gfx DL_ccm_geo_00045C_0x700f210[];
extern Gfx DL_ccm_geo_00045C_0x700f3b0[];
extern u8 ccm_geo_00045C__texture_09004000[];
extern u8 ccm_geo_00045C__texture_09007000[];
extern Gfx DL_ccm_geo_00045C_0x700f650[];
extern Gfx DL_ccm_geo_00045C_0x700f5c0[];
extern Gfx DL_ccm_geo_00045C_0x700f5f8[];
extern u8 ccm_geo_00045C__texture_09000800[];
extern Light_t Light_ccm_geo_00045C_0x700f6e8;
extern Ambient_t Light_ccm_geo_00045C_0x700f6e0;
extern Gfx DL_ccm_geo_00045C_0x700f780[];
extern Gfx DL_ccm_geo_00045C_0x700f738[];
#endif