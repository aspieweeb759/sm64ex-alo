ALIGNED8 u8 Flipswap_Platform_Border_MOP__texture_005F75E0[] = {
#include "actors/Flipswap_Platform_Border_MOP/Flipswap_Platform_Border_MOP_0x5f75e0_custom.rgba16.inc.c"
};
