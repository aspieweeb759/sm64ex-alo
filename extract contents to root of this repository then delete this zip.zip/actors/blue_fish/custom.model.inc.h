#ifndef blue_fish_blue_fish_model_HEADER_H
#define blue_fish_blue_fish_model_HEADER_H
#include "types.h"
extern Vtx VB_fish_geo_0x301bde0[];
extern Vtx VB_fish_geo_0x301c018[];
extern u8 fish_geo__texture_0301B5E0[];
extern Light_t Light_fish_geo_0x301b5d0;
extern Ambient_t Light_fish_geo_0x301b5c8;
extern Gfx DL_fish_geo_0x301bfb8[];
extern Gfx DL_fish_geo_0x301bec0[];
extern Gfx DL_fish_geo_0x301c150[];
extern Gfx DL_fish_geo_0x301c0a8[];
#endif