#ifndef bowser_3_falling_platform_10_model_HEADER_H
#define bowser_3_falling_platform_10_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000368_0x7003d28[];
extern Vtx VB_bowser_3_geo_000368_0x7003d88[];
extern Vtx VB_bowser_3_geo_000368_0x7003dc8[];
extern u8 bowser_3_geo_000368__texture_07000800[];
extern u8 bowser_3_geo_000368__texture_07001000[];
extern Light_t Light_bowser_3_geo_000368_0x7003d00;
extern Light_t Light_bowser_3_geo_000368_0x7003d18;
extern Ambient_t Light_bowser_3_geo_000368_0x7003cf8;
extern Ambient_t Light_bowser_3_geo_000368_0x7003d10;
extern Gfx DL_bowser_3_geo_000368_0x7003fa0[];
extern Gfx DL_bowser_3_geo_000368_0x7003ec8[];
extern Gfx DL_bowser_3_geo_000368_0x7003f38[];
#endif