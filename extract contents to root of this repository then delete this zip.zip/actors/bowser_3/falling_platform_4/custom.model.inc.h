#ifndef bowser_3_falling_platform_4_model_HEADER_H
#define bowser_3_falling_platform_4_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_0002D8_0x70029d8[];
extern Vtx VB_bowser_3_geo_0002D8_0x7002a38[];
extern Vtx VB_bowser_3_geo_0002D8_0x7002a78[];
extern u8 bowser_3_geo_0002D8__texture_07000800[];
extern u8 bowser_3_geo_0002D8__texture_07001000[];
extern Light_t Light_bowser_3_geo_0002D8_0x70029b0;
extern Light_t Light_bowser_3_geo_0002D8_0x70029c8;
extern Ambient_t Light_bowser_3_geo_0002D8_0x70029a8;
extern Ambient_t Light_bowser_3_geo_0002D8_0x70029c0;
extern Gfx DL_bowser_3_geo_0002D8_0x7002c50[];
extern Gfx DL_bowser_3_geo_0002D8_0x7002b78[];
extern Gfx DL_bowser_3_geo_0002D8_0x7002be8[];
#endif