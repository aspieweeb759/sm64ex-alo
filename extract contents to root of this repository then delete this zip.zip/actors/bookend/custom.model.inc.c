#include "custom.model.inc.h"
Vtx VB_bookend_part_geo_0x5001878[] = {
{{{ -10, 0, 108 }, 0, { 0, 990 }, { 131, 237, 0, 255}}},
{{{ -4, -39, -109 }, 0, { 479, 0 }, { 131, 237, 0, 255}}},
{{{ -4, -39, 108 }, 0, { 479, 990 }, { 131, 237, 0, 255}}},
{{{ -10, 0, -109 }, 0, { 0, 0 }, { 131, 237, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x50018b8[] = {
{{{ -4, -39, -109 }, 0, { 479, 0 }, { 0, 129, 0, 255}}},
{{{ 185, -39, 108 }, 0, { 0, 990 }, { 0, 129, 0, 255}}},
{{{ -4, -39, 108 }, 0, { 479, 990 }, { 0, 129, 0, 255}}},
{{{ 185, -39, -109 }, 0, { 0, 0 }, { 0, 129, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x5001a20[] = {
{{{ -4, -39, -107 }, 0, { 479, 990 }, { 131, 237, 0, 255}}},
{{{ -4, -39, 110 }, 0, { 479, 0 }, { 131, 237, 0, 255}}},
{{{ -10, 0, 110 }, 0, { 0, 0 }, { 131, 237, 0, 255}}},
{{{ -10, 0, -107 }, 0, { 0, 990 }, { 131, 237, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x5001a60[] = {
{{{ -4, -39, -107 }, 0, { 0, 990 }, { 0, 129, 0, 255}}},
{{{ 185, -39, 110 }, 0, { 990, 0 }, { 0, 129, 0, 255}}},
{{{ -4, -39, 110 }, 0, { 0, 0 }, { 0, 129, 0, 255}}},
{{{ 185, -39, -107 }, 0, { 990, 990 }, { 0, 129, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x5001bc8[] = {
{{{ -10, 0, 103 }, 0, { 0, 990 }, { 0, 127, 0, 255}}},
{{{ 159, 0, -104 }, 0, { 479, 0 }, { 0, 127, 0, 255}}},
{{{ -10, 0, -104 }, 0, { 0, 0 }, { 0, 127, 0, 255}}},
{{{ 159, 0, 103 }, 0, { 479, 990 }, { 0, 127, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x5001c08[] = {
{{{ 159, 0, 103 }, 0, { 0, -6 }, { 0, 0, 127, 255}}},
{{{ -10, 0, 103 }, 0, { 0, 990 }, { 0, 0, 127, 255}}},
{{{ -4, -38, 103 }, 0, { 479, 990 }, { 0, 0, 127, 255}}},
{{{ 170, -38, 103 }, 0, { 479, 0 }, { 0, 0, 127, 255}}},
{{{ 159, 0, -104 }, 0, { 0, 0 }, { 121, 35, 0, 255}}},
{{{ 159, 0, 103 }, 0, { 0, 990 }, { 121, 35, 0, 255}}},
{{{ 170, -38, 103 }, 0, { 479, 990 }, { 121, 35, 0, 255}}},
{{{ 170, -38, -104 }, 0, { 479, 0 }, { 121, 35, 0, 255}}},
{{{ -10, 0, -104 }, 0, { 0, -6 }, { 0, 0, 129, 255}}},
{{{ 159, 0, -104 }, 0, { 0, 990 }, { 0, 0, 129, 255}}},
{{{ 170, -38, -104 }, 0, { 479, 990 }, { 0, 0, 129, 255}}},
{{{ -4, -38, -104 }, 0, { 479, 0 }, { 0, 0, 129, 255}}},
};

Vtx VB_bookend_part_geo_0x5001df8[] = {
{{{ -10, 0, 105 }, 0, { 0, 0 }, { 0, 127, 0, 255}}},
{{{ 159, 0, -102 }, 0, { 479, 990 }, { 0, 127, 0, 255}}},
{{{ -10, 0, -102 }, 0, { 0, 990 }, { 0, 127, 0, 255}}},
{{{ 159, 0, 105 }, 0, { 479, 0 }, { 0, 127, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x5001e38[] = {
{{{ 170, -38, -102 }, 0, { 479, 990 }, { 0, 0, 129, 255}}},
{{{ -4, -38, -102 }, 0, { 479, 0 }, { 0, 0, 129, 255}}},
{{{ -10, 0, -102 }, 0, { 0, -6 }, { 0, 0, 129, 255}}},
{{{ 159, 0, -102 }, 0, { 0, 990 }, { 0, 0, 129, 255}}},
{{{ 170, -38, 105 }, 0, { 479, 990 }, { 121, 35, 0, 255}}},
{{{ 170, -38, -102 }, 0, { 479, 0 }, { 121, 35, 0, 255}}},
{{{ 159, 0, -102 }, 0, { 0, 0 }, { 121, 35, 0, 255}}},
{{{ 159, 0, 105 }, 0, { 0, 990 }, { 121, 35, 0, 255}}},
{{{ -4, -38, 105 }, 0, { 479, 990 }, { 0, 0, 127, 255}}},
{{{ 170, -38, 105 }, 0, { 479, 0 }, { 0, 0, 127, 255}}},
{{{ 159, 0, 105 }, 0, { 0, -6 }, { 0, 0, 127, 255}}},
{{{ -10, 0, 105 }, 0, { 0, 990 }, { 0, 0, 127, 255}}},
};

Vtx VB_bookend_part_geo_0x5002028[] = {
{{{ 157, -1, -48 }, 0, { 6, 358 }, { 131, 238, 0, 255}}},
{{{ 151, 39, -72 }, 0, { 475, 624 }, { 131, 238, 0, 255}}},
{{{ 157, -1, -99 }, 0, { 372, -1002 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 0 }, 0, { 106, 390 }, { 131, 238, 0, 255}}},
{{{ 151, 39, -24 }, 0, { 465, 636 }, { 131, 238, 0, 255}}},
{{{ 157, -1, -48 }, 0, { 461, -950 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 51 }, 0, { -54, 352 }, { 131, 238, 0, 255}}},
{{{ 151, 39, 26 }, 0, { 478, 570 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 0 }, 0, { 446, -978 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 103 }, 0, { 66, 302 }, { 131, 238, 0, 255}}},
{{{ 151, 39, 78 }, 0, { 495, 590 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 51 }, 0, { 462, -962 }, { 131, 238, 0, 255}}},
};

Vtx VB_bookend_part_geo_0x50021c8[] = {
{{{ 157, -1, 100 }, 0, { 32, 394 }, { 131, 238, 0, 255}}},
{{{ 151, 39, 73 }, 0, { 426, 774 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 49 }, 0, { 414, -722 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 49 }, 0, { -39, 392 }, { 131, 238, 0, 255}}},
{{{ 151, 39, 25 }, 0, { 457, 852 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 0 }, 0, { 363, -564 }, { 131, 238, 0, 255}}},
{{{ 157, -1, 0 }, 0, { -1, 360 }, { 131, 238, 0, 255}}},
{{{ 151, 39, -25 }, 0, { 473, 906 }, { 131, 238, 0, 255}}},
{{{ 157, -1, -50 }, 0, { 372, -932 }, { 131, 238, 0, 255}}},
{{{ 157, -1, -50 }, 0, { 12, 240 }, { 131, 238, 0, 255}}},
{{{ 151, 39, -77 }, 0, { 491, 632 }, { 131, 238, 0, 255}}},
{{{ 157, -1, -102 }, 0, { 365, -1004 }, { 131, 238, 0, 255}}},
};

Light_t Light_bookend_part_geo_0x5001de8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bookend_part_geo_0x5001de0 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_bookend_part_geo_0x5001f98[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 5, 0, 2, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_bookend_part_geo_0x5001ef8),
gsSPDisplayList(DL_bookend_part_geo_0x5001f40),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001ef8[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000860),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_bookend_part_geo_0x5001de8.col, 1),
gsSPLight(&Light_bookend_part_geo_0x5001de0.col, 2),
gsSPVertex(VB_bookend_part_geo_0x5001df8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001f40[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000C60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPVertex(VB_bookend_part_geo_0x5001e38, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,4, 6, 7, 0),
gsSP2Triangles(8, 9, 10, 0,8, 10, 11, 0),
gsSPEndDisplayList(),
};

Light_t Light_bookend_part_geo_0x5001a10 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bookend_part_geo_0x5001a08 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_bookend_part_geo_0x5001b20[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_CULL_BACK|G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 5, 0, 2, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_bookend_part_geo_0x5001aa0),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_bookend_part_geo_0x5001ae8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001aa0[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000060),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_bookend_part_geo_0x5001a10.col, 1),
gsSPLight(&Light_bookend_part_geo_0x5001a08.col, 2),
gsSPVertex(VB_bookend_part_geo_0x5001a20, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001ae8[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05001060),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_bookend_part_geo_0x5001a60, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_bookend_part_geo_0x5002018 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bookend_part_geo_0x5002010 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_bookend_part_geo_0x5002140[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 0, 5, 0, 0, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_bookend_part_geo_0x50020e8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x50020e8[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000460),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_bookend_part_geo_0x5002018.col, 1),
gsSPLight(&Light_bookend_part_geo_0x5002010.col, 2),
gsSPVertex(VB_bookend_part_geo_0x5002028, 12, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,9, 10, 11, 0),
gsSPEndDisplayList(),
};

Light_t Light_bookend_part_geo_0x5001bb8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bookend_part_geo_0x5001bb0 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_bookend_part_geo_0x5001d68[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 5, 0, 2, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_bookend_part_geo_0x5001cc8),
gsSPDisplayList(DL_bookend_part_geo_0x5001d10),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001cc8[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000860),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_bookend_part_geo_0x5001bb8.col, 1),
gsSPLight(&Light_bookend_part_geo_0x5001bb0.col, 2),
gsSPVertex(VB_bookend_part_geo_0x5001bc8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001d10[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000C60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPVertex(VB_bookend_part_geo_0x5001c08, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,4, 6, 7, 0),
gsSP2Triangles(8, 9, 10, 0,8, 10, 11, 0),
gsSPEndDisplayList(),
};

Light_t Light_bookend_part_geo_0x5001868 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bookend_part_geo_0x5001860 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_bookend_part_geo_0x5001978[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_CULL_BACK|G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 5, 0, 2, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_bookend_part_geo_0x50018f8),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_bookend_part_geo_0x5001940),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x50018f8[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000060),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_bookend_part_geo_0x5001868.col, 1),
gsSPLight(&Light_bookend_part_geo_0x5001860.col, 2),
gsSPVertex(VB_bookend_part_geo_0x5001878, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5001940[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05001060),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_bookend_part_geo_0x50018b8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_bookend_part_geo_0x50021b8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bookend_part_geo_0x50021b0 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_bookend_part_geo_0x50022e0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 0, 5, 0, 0, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_bookend_part_geo_0x5002288),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_bookend_part_geo_0x5002288[] = {
gsDPSetTextureImage(0, 2, 1, bookend_part_geo__texture_05000460),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_bookend_part_geo_0x50021b8.col, 1),
gsSPLight(&Light_bookend_part_geo_0x50021b0.col, 2),
gsSPVertex(VB_bookend_part_geo_0x50021c8, 12, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,9, 10, 11, 0),
gsSPEndDisplayList(),
};

