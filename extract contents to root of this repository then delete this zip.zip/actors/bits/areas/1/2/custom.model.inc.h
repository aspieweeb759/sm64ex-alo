#ifndef bits_2_model_HEADER_H
#define bits_2_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000430_0x7002988[];
extern Vtx VB_bits_geo_000430_0x7002a88[];
extern Vtx VB_bits_geo_000430_0x7002b78[];
extern Vtx VB_bits_geo_000430_0x7002c68[];
extern Vtx VB_bits_geo_000430_0x7002d68[];
extern Vtx VB_bits_geo_000430_0x7002e68[];
extern Vtx VB_bits_geo_000430_0x7002f48[];
extern Vtx VB_bits_geo_000430_0x7003048[];
extern Vtx VB_bits_geo_000430_0x7003148[];
extern Vtx VB_bits_geo_000430_0x70031c8[];
extern Vtx VB_bits_geo_000430_0x70032c8[];
extern u8 bits_geo_000430__texture_09007000[];
extern u8 bits_geo_000430__texture_09001000[];
extern u8 bits_geo_000430__texture_09001800[];
extern u8 bits_geo_000430__texture_09000800[];
extern Gfx DL_bits_geo_000430_0x7003670[];
extern Gfx DL_bits_geo_000430_0x7003348[];
extern Gfx DL_bits_geo_000430_0x70033b0[];
extern Gfx DL_bits_geo_000430_0x70034f8[];
extern Gfx DL_bits_geo_000430_0x70035e0[];
#endif