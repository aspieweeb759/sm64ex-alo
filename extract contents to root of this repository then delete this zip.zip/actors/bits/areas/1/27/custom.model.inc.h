#ifndef bits_27_model_HEADER_H
#define bits_27_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000688_0x70141e8[];
extern Vtx VB_bits_geo_000688_0x70142e8[];
extern Vtx VB_bits_geo_000688_0x70143d8[];
extern Vtx VB_bits_geo_000688_0x70144b8[];
extern Vtx VB_bits_geo_000688_0x70145a8[];
extern Vtx VB_bits_geo_000688_0x70146a8[];
extern Vtx VB_bits_geo_000688_0x7014788[];
extern Vtx VB_bits_geo_000688_0x7014878[];
extern Vtx VB_bits_geo_000688_0x7014968[];
extern u8 bits_geo_000688__texture_09001800[];
extern Gfx DL_bits_geo_000688_0x7014c28[];
extern Gfx DL_bits_geo_000688_0x70149a8[];
#endif