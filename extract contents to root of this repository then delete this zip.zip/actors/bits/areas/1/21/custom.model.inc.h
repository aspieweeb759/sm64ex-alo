#ifndef bits_21_model_HEADER_H
#define bits_21_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0005F8_0x7012b80[];
extern Vtx VB_bits_geo_0005F8_0x7012c80[];
extern u8 bits_geo_0005F8__texture_09002000[];
extern Gfx DL_bits_geo_0005F8_0x7012d40[];
extern Gfx DL_bits_geo_0005F8_0x7012cc0[];
#endif