#ifndef bits_25_model_HEADER_H
#define bits_25_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000658_0x7013ce8[];
extern Vtx VB_bits_geo_000658_0x7013de8[];
extern u8 bits_geo_000658__texture_07002000[];
extern Gfx DL_bits_geo_000658_0x7013ef8[];
extern Gfx DL_bits_geo_000658_0x7013e68[];
#endif