#ifndef bits_15_model_HEADER_H
#define bits_15_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000568_0x700ce50[];
extern Vtx VB_bits_geo_000568_0x700cf50[];
extern Vtx VB_bits_geo_000568_0x700d040[];
extern Vtx VB_bits_geo_000568_0x700d0c0[];
extern u8 bits_geo_000568__texture_09007000[];
extern Gfx DL_bits_geo_000568_0x700d278[];
extern Gfx DL_bits_geo_000568_0x700d140[];
extern Gfx DL_bits_geo_000568_0x700d228[];
#endif