#ifndef bits_8_model_HEADER_H
#define bits_8_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0004C0_0x7007f58[];
extern Vtx VB_bits_geo_0004C0_0x7008058[];
extern Vtx VB_bits_geo_0004C0_0x7008098[];
extern Vtx VB_bits_geo_0004C0_0x7008188[];
extern Vtx VB_bits_geo_0004C0_0x7008288[];
extern Vtx VB_bits_geo_0004C0_0x7008388[];
extern Vtx VB_bits_geo_0004C0_0x7008468[];
extern Vtx VB_bits_geo_0004C0_0x70084c8[];
extern Vtx VB_bits_geo_0004C0_0x70085c8[];
extern Vtx VB_bits_geo_0004C0_0x70086c8[];
extern Vtx VB_bits_geo_0004C0_0x7008788[];
extern Vtx VB_bits_geo_0004C0_0x7008888[];
extern u8 bits_geo_0004C0__texture_09001800[];
extern u8 bits_geo_0004C0__texture_09007000[];
extern u8 bits_geo_0004C0__texture_09001000[];
extern u8 bits_geo_0004C0__texture_07001000[];
extern Gfx DL_bits_geo_0004C0_0x7008d18[];
extern Gfx DL_bits_geo_0004C0_0x7008988[];
extern Gfx DL_bits_geo_0004C0_0x7008a08[];
extern Gfx DL_bits_geo_0004C0_0x7008b70[];
extern Gfx DL_bits_geo_0004C0_0x7008c68[];
#endif