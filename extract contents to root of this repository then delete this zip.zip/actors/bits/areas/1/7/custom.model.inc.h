#ifndef bits_7_model_HEADER_H
#define bits_7_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0004A8_0x7007c98[];
extern Vtx VB_bits_geo_0004A8_0x7007d18[];
extern u8 bits_geo_0004A8__texture_09007000[];
extern u8 bits_geo_0004A8__texture_07001000[];
extern Gfx DL_bits_geo_0004A8_0x7007ec8[];
extern Gfx DL_bits_geo_0004A8_0x7007e18[];
extern Gfx DL_bits_geo_0004A8_0x7007e60[];
#endif