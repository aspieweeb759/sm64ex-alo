#ifndef bits_29_model_HEADER_H
#define bits_29_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0006B8_0x7015438[];
extern Vtx VB_bits_geo_0006B8_0x7015478[];
extern Vtx VB_bits_geo_0006B8_0x7015578[];
extern Vtx VB_bits_geo_0006B8_0x7015668[];
extern Vtx VB_bits_geo_0006B8_0x7015748[];
extern Vtx VB_bits_geo_0006B8_0x7015828[];
extern Vtx VB_bits_geo_0006B8_0x7015908[];
extern u8 bits_geo_0006B8__texture_09007000[];
extern u8 bits_geo_0006B8__texture_09008000[];
extern Gfx DL_bits_geo_0006B8_0x7015b60[];
extern Gfx DL_bits_geo_0006B8_0x70159b8[];
extern Gfx DL_bits_geo_0006B8_0x70159f0[];
#endif