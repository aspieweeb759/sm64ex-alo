ALIGNED8 u8 bowser_flames_geo__texture_06000000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6000000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06001000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6001000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06002000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6002000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06003000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6003000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06004000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6004000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06005000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6005000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06006000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6006000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06007000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6007000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06008000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6008000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06009000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6009000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0600A000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x600a000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0600B000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x600b000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0600C000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x600c000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0600D000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x600d000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0600E000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x600e000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0600F000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x600f000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06010000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6010000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06011000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6011000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06012000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6012000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06013000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6013000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06014000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6014000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06015000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6015000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06016000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6016000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06017000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6017000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06018000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6018000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_06019000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x6019000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0601A000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x601a000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_flames_geo__texture_0601B000[] = {
#include "actors/bowser_flames/bowser_flames_geo_0x601b000_custom.rgba16.inc.c"
};
