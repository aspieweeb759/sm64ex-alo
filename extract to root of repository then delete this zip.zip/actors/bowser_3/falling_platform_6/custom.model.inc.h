#ifndef bowser_3_falling_platform_6_model_HEADER_H
#define bowser_3_falling_platform_6_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000308_0x7003048[];
extern Vtx VB_bowser_3_geo_000308_0x70030a8[];
extern Vtx VB_bowser_3_geo_000308_0x70030e8[];
extern u8 bowser_3_geo_000308__texture_07000800[];
extern u8 bowser_3_geo_000308__texture_07001000[];
extern Light_t Light_bowser_3_geo_000308_0x7003020;
extern Light_t Light_bowser_3_geo_000308_0x7003038;
extern Ambient_t Light_bowser_3_geo_000308_0x7003018;
extern Ambient_t Light_bowser_3_geo_000308_0x7003030;
extern Gfx DL_bowser_3_geo_000308_0x70032c0[];
extern Gfx DL_bowser_3_geo_000308_0x70031e8[];
extern Gfx DL_bowser_3_geo_000308_0x7003258[];
#endif