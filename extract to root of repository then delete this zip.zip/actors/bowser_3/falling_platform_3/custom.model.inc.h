#ifndef bowser_3_falling_platform_3_model_HEADER_H
#define bowser_3_falling_platform_3_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_0002C0_0x70026a0[];
extern Vtx VB_bowser_3_geo_0002C0_0x7002700[];
extern Vtx VB_bowser_3_geo_0002C0_0x7002740[];
extern u8 bowser_3_geo_0002C0__texture_07000800[];
extern u8 bowser_3_geo_0002C0__texture_07001000[];
extern Light_t Light_bowser_3_geo_0002C0_0x7002678;
extern Light_t Light_bowser_3_geo_0002C0_0x7002690;
extern Ambient_t Light_bowser_3_geo_0002C0_0x7002670;
extern Ambient_t Light_bowser_3_geo_0002C0_0x7002688;
extern Gfx DL_bowser_3_geo_0002C0_0x7002918[];
extern Gfx DL_bowser_3_geo_0002C0_0x7002840[];
extern Gfx DL_bowser_3_geo_0002C0_0x70028b0[];
#endif