#ifndef bowser_3_falling_platform_5_model_HEADER_H
#define bowser_3_falling_platform_5_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_0002F0_0x7002d10[];
extern Vtx VB_bowser_3_geo_0002F0_0x7002d70[];
extern Vtx VB_bowser_3_geo_0002F0_0x7002db0[];
extern u8 bowser_3_geo_0002F0__texture_07000800[];
extern u8 bowser_3_geo_0002F0__texture_07001000[];
extern Light_t Light_bowser_3_geo_0002F0_0x7002ce8;
extern Light_t Light_bowser_3_geo_0002F0_0x7002d00;
extern Ambient_t Light_bowser_3_geo_0002F0_0x7002ce0;
extern Ambient_t Light_bowser_3_geo_0002F0_0x7002cf8;
extern Gfx DL_bowser_3_geo_0002F0_0x7002f88[];
extern Gfx DL_bowser_3_geo_0002F0_0x7002eb0[];
extern Gfx DL_bowser_3_geo_0002F0_0x7002f20[];
#endif