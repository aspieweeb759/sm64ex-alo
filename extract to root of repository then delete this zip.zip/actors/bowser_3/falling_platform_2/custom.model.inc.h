#ifndef bowser_3_falling_platform_2_model_HEADER_H
#define bowser_3_falling_platform_2_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_0002A8_0x7002368[];
extern Vtx VB_bowser_3_geo_0002A8_0x70023c8[];
extern Vtx VB_bowser_3_geo_0002A8_0x7002408[];
extern u8 bowser_3_geo_0002A8__texture_07000800[];
extern u8 bowser_3_geo_0002A8__texture_07001000[];
extern Light_t Light_bowser_3_geo_0002A8_0x7002340;
extern Light_t Light_bowser_3_geo_0002A8_0x7002358;
extern Ambient_t Light_bowser_3_geo_0002A8_0x7002338;
extern Ambient_t Light_bowser_3_geo_0002A8_0x7002350;
extern Gfx DL_bowser_3_geo_0002A8_0x70025e0[];
extern Gfx DL_bowser_3_geo_0002A8_0x7002508[];
extern Gfx DL_bowser_3_geo_0002A8_0x7002578[];
#endif