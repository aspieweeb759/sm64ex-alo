#ifndef bowser_3_bomb_stand_model_HEADER_H
#define bowser_3_bomb_stand_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000380_0x7004758[];
extern Vtx VB_bowser_3_geo_000380_0x7004848[];
extern u8 bowser_3_geo_000380__texture_07000000[];
extern Light_t Light_bowser_3_geo_000380_0x7004748;
extern Ambient_t Light_bowser_3_geo_000380_0x7004740;
extern Gfx DL_bowser_3_geo_000380_0x7004958[];
extern Gfx DL_bowser_3_geo_000380_0x70048d8[];
#endif