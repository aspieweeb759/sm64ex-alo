#ifndef bowser_3_falling_platform_7_model_HEADER_H
#define bowser_3_falling_platform_7_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000320_0x7003380[];
extern Vtx VB_bowser_3_geo_000320_0x70033e0[];
extern Vtx VB_bowser_3_geo_000320_0x7003420[];
extern u8 bowser_3_geo_000320__texture_07000800[];
extern u8 bowser_3_geo_000320__texture_07001000[];
extern Light_t Light_bowser_3_geo_000320_0x7003358;
extern Light_t Light_bowser_3_geo_000320_0x7003370;
extern Ambient_t Light_bowser_3_geo_000320_0x7003350;
extern Ambient_t Light_bowser_3_geo_000320_0x7003368;
extern Gfx DL_bowser_3_geo_000320_0x70035f8[];
extern Gfx DL_bowser_3_geo_000320_0x7003520[];
extern Gfx DL_bowser_3_geo_000320_0x7003590[];
#endif