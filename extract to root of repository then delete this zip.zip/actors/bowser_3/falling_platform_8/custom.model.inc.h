#ifndef bowser_3_falling_platform_8_model_HEADER_H
#define bowser_3_falling_platform_8_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000338_0x70036b8[];
extern Vtx VB_bowser_3_geo_000338_0x7003718[];
extern Vtx VB_bowser_3_geo_000338_0x7003758[];
extern u8 bowser_3_geo_000338__texture_07000800[];
extern u8 bowser_3_geo_000338__texture_07001000[];
extern Light_t Light_bowser_3_geo_000338_0x7003690;
extern Light_t Light_bowser_3_geo_000338_0x70036a8;
extern Ambient_t Light_bowser_3_geo_000338_0x7003688;
extern Ambient_t Light_bowser_3_geo_000338_0x70036a0;
extern Gfx DL_bowser_3_geo_000338_0x7003930[];
extern Gfx DL_bowser_3_geo_000338_0x7003858[];
extern Gfx DL_bowser_3_geo_000338_0x70038c8[];
#endif