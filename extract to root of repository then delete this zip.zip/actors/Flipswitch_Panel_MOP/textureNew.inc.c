ALIGNED8 u8 Flipswitch_Panel_MOP__texture_005FA030[] = {
#include "actors/Flipswitch_Panel_MOP/Flipswitch_Panel_MOP_0x5fa030_custom.rgba16.inc.c"
};
ALIGNED8 u8 Flipswitch_Panel_MOP__texture_005FB1A0[] = {
#include "actors/Flipswitch_Panel_MOP/Flipswitch_Panel_MOP_0x5fb1a0_custom.rgba16.inc.c"
};
ALIGNED8 u8 Flipswitch_Panel_MOP__texture_005FB9A0[] = {
#include "actors/Flipswitch_Panel_MOP/Flipswitch_Panel_MOP_0x5fb9a0_custom.rgba16.inc.c"
};
