const GeoLayout castle_grounds_geo_0006F4[]= {
GEO_CULLING_RADIUS(2100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_grounds_geo_0006F4_0x700a290),
GEO_CLOSE_NODE(),
GEO_END(),
};
