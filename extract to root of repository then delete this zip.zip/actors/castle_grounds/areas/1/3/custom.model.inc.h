#ifndef castle_grounds_3_model_HEADER_H
#define castle_grounds_3_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_grounds_geo_0006F4_0x70096f8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x70097f8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x70098d8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x70099b8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009aa8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009b98[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009bc8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009cb8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009da8[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009e98[];
extern Vtx VB_castle_grounds_geo_0006F4_0x7009f88[];
extern u8 castle_grounds_geo_0006F4__texture_09007800[];
extern u8 castle_grounds_geo_0006F4__texture_09001000[];
extern Gfx DL_castle_grounds_geo_0006F4_0x700a290[];
extern Gfx DL_castle_grounds_geo_0006F4_0x7009fd8[];
extern Gfx DL_castle_grounds_geo_0006F4_0x700a140[];
extern Gfx DL_castle_grounds_geo_0006F4_0x700a260[];
#endif