#ifndef castle_grounds_11_model_HEADER_H
#define castle_grounds_11_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_grounds_geo_000660_0x700c500[];
extern Vtx VB_castle_grounds_geo_000660_0x700c530[];
extern Vtx VB_castle_grounds_geo_000660_0x700c570[];
extern Vtx VB_castle_grounds_geo_000660_0x700c5b0[];
extern Vtx VB_castle_grounds_geo_000660_0x700c5f0[];
extern Vtx VB_castle_grounds_geo_000660_0x700c640[];
extern Light_t Light_castle_grounds_geo_000660_0x700c4e8;
extern Light_t Light_castle_grounds_geo_000660_0x700c4d0;
extern Ambient_t Light_castle_grounds_geo_000660_0x700c4e0;
extern Ambient_t Light_castle_grounds_geo_000660_0x700c4c8;
extern Gfx DL_castle_grounds_geo_000660_0x700c768[];
extern Gfx DL_castle_grounds_geo_000660_0x700c728[];
extern Gfx DL_castle_grounds_geo_000660_0x700c6e8[];
extern Gfx DL_castle_grounds_geo_000660_0x700c6a8[];
extern Gfx DL_castle_grounds_geo_000660_0x700c670[];
#endif