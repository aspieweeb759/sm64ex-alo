#ifndef castle_grounds_7_model_HEADER_H
#define castle_grounds_7_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_grounds_geo_00070C_0x700bab8[];
extern u8 castle_grounds_geo_00070C__texture_09005800[];
extern Gfx DL_castle_grounds_geo_00070C_0x700bb80[];
extern Gfx DL_castle_grounds_geo_00070C_0x700bb38[];
#endif