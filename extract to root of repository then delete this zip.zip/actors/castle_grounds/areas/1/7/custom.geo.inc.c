const GeoLayout castle_grounds_geo_00070C[]= {
GEO_CULLING_RADIUS(15000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_castle_grounds_geo_00070C_0x700bb80),
GEO_CLOSE_NODE(),
GEO_END(),
};
