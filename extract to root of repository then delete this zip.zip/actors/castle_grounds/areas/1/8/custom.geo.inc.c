const GeoLayout castle_grounds_geo_000724[]= {
GEO_CULLING_RADIUS(15000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_castle_grounds_geo_000724_0x700bc68),
GEO_CLOSE_NODE(),
GEO_END(),
};
