#ifndef castle_grounds_8_model_HEADER_H
#define castle_grounds_8_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_grounds_geo_000724_0x700bbf0[];
extern u8 castle_grounds_geo_000724__texture_09005800[];
extern Gfx DL_castle_grounds_geo_000724_0x700bc68[];
extern Gfx DL_castle_grounds_geo_000724_0x700bc30[];
#endif