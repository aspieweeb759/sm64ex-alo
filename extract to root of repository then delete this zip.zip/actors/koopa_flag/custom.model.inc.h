#ifndef koopa_flag_koopa_flag_model_HEADER_H
#define koopa_flag_koopa_flag_model_HEADER_H
#include "types.h"
extern Vtx VB_koopa_flag_geo_0x6000878[];
extern Vtx VB_koopa_flag_geo_0x60008c8[];
extern Vtx VB_koopa_flag_geo_0x6000a38[];
extern Vtx VB_koopa_flag_geo_0x6000a68[];
extern Vtx VB_koopa_flag_geo_0x6000b80[];
extern Vtx VB_koopa_flag_geo_0x6000c68[];
extern Vtx VB_koopa_flag_geo_0x6000d50[];
extern Vtx VB_koopa_flag_geo_0x6000df0[];
extern Light_t Light_koopa_flag_geo_0x6000850;
extern Light_t Light_koopa_flag_geo_0x6000868;
extern Ambient_t Light_koopa_flag_geo_0x6000848;
extern Ambient_t Light_koopa_flag_geo_0x6000860;
extern Gfx DL_koopa_flag_geo_0x6000a08[];
extern Gfx DL_koopa_flag_geo_0x6000968[];
extern u8 koopa_flag_geo__texture_06000048[];
extern Gfx DL_koopa_flag_geo_0x6000b08[];
extern Gfx DL_koopa_flag_geo_0x6000ab8[];
extern Gfx DL_koopa_flag_geo_0x6000ae8[];
extern Gfx DL_koopa_flag_geo_0x6000bf8[];
extern Gfx DL_koopa_flag_geo_0x6000bc0[];
extern Gfx DL_koopa_flag_geo_0x6000ce0[];
extern Gfx DL_koopa_flag_geo_0x6000ca8[];
extern Gfx DL_koopa_flag_geo_0x6000db0[];
extern Gfx DL_koopa_flag_geo_0x6000d90[];
extern Gfx DL_koopa_flag_geo_0x6000e38[];
extern Gfx DL_koopa_flag_geo_0x6000e20[];
#endif