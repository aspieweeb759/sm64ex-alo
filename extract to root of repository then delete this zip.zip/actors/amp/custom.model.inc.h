#ifndef amp_amp_model_HEADER_H
#define amp_amp_model_HEADER_H
#include "types.h"
extern Vtx VB_amp_geo_0x8002b18[];
extern Vtx VB_amp_geo_0x8002c10[];
extern Vtx VB_amp_geo_0x8002cf8[];
extern Vtx VB_amp_geo_0x8002de0[];
extern u8 amp_geo__texture_08001318[];
extern Gfx DL_amp_geo_0x8002c88[];
extern Gfx DL_amp_geo_0x8002c50[];
extern u8 amp_geo__texture_08000F18[];
extern Gfx DL_amp_geo_0x8002ba0[];
extern Gfx DL_amp_geo_0x8002b68[];
extern u8 amp_geo__texture_08002318[];
extern Gfx DL_amp_geo_0x8002d70[];
extern Gfx DL_amp_geo_0x8002d38[];
extern u8 amp_geo__texture_08001B18[];
extern Gfx DL_amp_geo_0x8002e58[];
extern Gfx DL_amp_geo_0x8002e20[];
#endif