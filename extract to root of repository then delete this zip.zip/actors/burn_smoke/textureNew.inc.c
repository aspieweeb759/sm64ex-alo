ALIGNED8 u8 burn_smoke_geo__texture_04021800[] = {
#include "actors/burn_smoke/burn_smoke_geo_0x4021800_custom.rgba16.inc.c"
};
