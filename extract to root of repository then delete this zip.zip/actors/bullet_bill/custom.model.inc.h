#ifndef bullet_bill_bullet_bill_model_HEADER_H
#define bullet_bill_bullet_bill_model_HEADER_H
#include "types.h"
extern Vtx VB_bullet_bill_geo_0x500daa8[];
extern Vtx VB_bullet_bill_geo_0x500db98[];
extern Vtx VB_bullet_bill_geo_0x500dc28[];
extern Vtx VB_bullet_bill_geo_0x500dd18[];
extern Vtx VB_bullet_bill_geo_0x500de08[];
extern Vtx VB_bullet_bill_geo_0x500dec8[];
extern Vtx VB_bullet_bill_geo_0x500dfb8[];
extern Vtx VB_bullet_bill_geo_0x500e0a8[];
extern Vtx VB_bullet_bill_geo_0x500e198[];
extern Vtx VB_bullet_bill_geo_0x500e288[];
extern Vtx VB_bullet_bill_geo_0x500e378[];
extern Vtx VB_bullet_bill_geo_0x500e468[];
extern Vtx VB_bullet_bill_geo_0x500e558[];
extern u8 bullet_bill_geo__texture_0500BAA8[];
extern u8 bullet_bill_geo__texture_0500CAA8[];
extern Light_t Light_bullet_bill_geo_0x500ba98;
extern Ambient_t Light_bullet_bill_geo_0x500ba90;
extern Gfx DL_bullet_bill_geo_0x500e8a8[];
extern Gfx DL_bullet_bill_geo_0x500e5e8[];
extern Gfx DL_bullet_bill_geo_0x500e678[];
extern Gfx DL_bullet_bill_geo_0x500e730[];
#endif