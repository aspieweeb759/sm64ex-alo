#include "custom.model.inc.h"
Vtx VB_piranha_plant_geo_0x60153f8[] = {
{{{ 0, 1, -223 }, 0, { 0, 2012 }, { 0, 127, 0, 255}}},
{{{ 519, 1, 211 }, 0, { 990, 28 }, { 0, 127, 0, 255}}},
{{{ 519, 1, -223 }, 0, { 0, 28 }, { 0, 127, 0, 255}}},
{{{ 0, 1, 211 }, 0, { 990, 2012 }, { 0, 127, 0, 255}}},
};

Vtx VB_piranha_plant_geo_0x60154f0[] = {
{{{ 518, 2, -223 }, 0, { 990, 8 }, { 0, 130, 0, 255}}},
{{{ 518, 1, 211 }, 0, { 0, 8 }, { 0, 130, 0, 255}}},
{{{ 0, -1, 211 }, 0, { 0, 2012 }, { 0, 130, 0, 255}}},
{{{ 0, 0, -223 }, 0, { 990, 2012 }, { 0, 130, 0, 255}}},
};

Vtx VB_piranha_plant_geo_0x60155e8[] = {
{{{ 49, -71, 0 }, 0, { 800, 384 }, { 110, 195, 13, 255}}},
{{{ 46, -7, -87 }, 0, { 168, 384 }, { 108, 229, 196, 255}}},
{{{ 67, 22, 0 }, 0, { 488, -128 }, { 126, 7, 0, 255}}},
{{{ -6, -131, 0 }, 0, { 990, 990 }, { 92, 172, 235, 255}}},
{{{ -12, -28, -141 }, 0, { 0, 990 }, { 87, 255, 164, 255}}},
{{{ -22, 138, -87 }, 0, { 1016, 990 }, { 81, 90, 221, 255}}},
{{{ 40, 95, 54 }, 0, { 166, 368 }, { 102, 68, 28, 255}}},
{{{ 40, 95, -53 }, 0, { 814, 370 }, { 103, 53, 206, 255}}},
{{{ -22, 138, 88 }, 0, { 0, 990 }, { 83, 65, 70, 255}}},
{{{ 67, 22, 0 }, 0, { 490, -156 }, { 126, 7, 0, 255}}},
{{{ -12, -28, -141 }, 0, { 990, 990 }, { 87, 255, 164, 255}}},
{{{ -22, 138, -87 }, 0, { 0, 990 }, { 81, 90, 221, 255}}},
{{{ 40, 95, -53 }, 0, { 124, 380 }, { 103, 53, 206, 255}}},
{{{ 46, -7, -87 }, 0, { 756, 380 }, { 108, 229, 196, 255}}},
};

Vtx VB_piranha_plant_geo_0x60156c8[] = {
{{{ 40, 95, 54 }, 0, { 796, 370 }, { 102, 68, 28, 255}}},
{{{ 46, -7, 88 }, 0, { 164, 370 }, { 107, 254, 68, 255}}},
{{{ 67, 22, 0 }, 0, { 482, -152 }, { 126, 7, 0, 255}}},
{{{ 46, -7, -87 }, 0, { 756, 380 }, { 108, 229, 196, 255}}},
{{{ 40, 95, -53 }, 0, { 124, 380 }, { 103, 53, 206, 255}}},
{{{ 67, 22, 0 }, 0, { 406, -134 }, { 126, 7, 0, 255}}},
{{{ 46, -7, 88 }, 0, { 822, 370 }, { 107, 254, 68, 255}}},
{{{ 49, -71, 0 }, 0, { 190, 370 }, { 110, 195, 13, 255}}},
{{{ 67, 22, 0 }, 0, { 530, -154 }, { 126, 7, 0, 255}}},
{{{ -12, -28, 142 }, 0, { 990, 990 }, { 89, 213, 78, 255}}},
{{{ -6, -131, 0 }, 0, { 0, 990 }, { 92, 172, 235, 255}}},
{{{ -22, 138, 88 }, 0, { 990, 990 }, { 83, 65, 70, 255}}},
{{{ -12, -28, 142 }, 0, { 0, 990 }, { 89, 213, 78, 255}}},
};

Vtx VB_piranha_plant_geo_0x60158b0[] = {
{{{ 519, 74, 0 }, 0, { 0, 84 }, { 126, 0, 0, 255}}},
{{{ 387, 136, 249 }, 0, { 4082, 990 }, { 90, 0, 89, 255}}},
{{{ 387, 66, 249 }, 0, { 4074, 0 }, { 112, 0, 59, 255}}},
{{{ 519, 136, 0 }, 0, { 0, 990 }, { 126, 0, 0, 255}}},
{{{ 387, 66, -248 }, 0, { -3114, 0 }, { 75, 0, 154, 255}}},
{{{ 387, 136, -248 }, 0, { -3122, 990 }, { 90, 0, 167, 255}}},
{{{ 519, 74, 0 }, 0, { 990, 84 }, { 126, 0, 0, 255}}},
{{{ 519, 136, 0 }, 0, { 990, 990 }, { 126, 0, 0, 255}}},
{{{ 387, 68, 249 }, 0, { -54, -20 }, { 22, 0, 124, 255}}},
{{{ 387, 136, 249 }, 0, { -36, 988 }, { 90, 0, 89, 255}}},
{{{ 186, 56, 286 }, 0, { 3382, 996 }, { 22, 0, 124, 255}}},
{{{ 186, 56, -285 }, 0, { -2756, 990 }, { 22, 0, 132, 255}}},
{{{ 387, 136, -248 }, 0, { 982, 990 }, { 90, 0, 167, 255}}},
{{{ 387, 66, -248 }, 0, { 990, 0 }, { 75, 0, 154, 255}}},
};

Vtx VB_piranha_plant_geo_0x6015990[] = {
{{{ 597, 13, 0 }, 0, { -166, 532 }, { 124, 23, 254, 255}}},
{{{ 385, 72, 255 }, 0, { 872, 938 }, { 44, 108, 47, 255}}},
{{{ 391, 10, 335 }, 0, { 1064, 610 }, { 48, 254, 117, 255}}},
{{{ 391, 10, -334 }, 0, { 1090, 606 }, { 45, 24, 140, 255}}},
{{{ 381, -93, -260 }, 0, { 1028, -16 }, { 72, 191, 176, 255}}},
{{{ 101, -60, -288 }, 0, { -4, 150 }, { 216, 201, 150, 255}}},
{{{ 108, 56, -294 }, 0, { 2, 850 }, { 218, 101, 191, 255}}},
{{{ 385, 72, -253 }, 0, { 1004, 972 }, { 22, 119, 221, 255}}},
{{{ 56, 2, -271 }, 0, { -192, 522 }, { 175, 251, 159, 255}}},
{{{ 391, 10, 335 }, 0, { -70, 596 }, { 48, 254, 117, 255}}},
{{{ 385, 72, 255 }, 0, { -12, 966 }, { 44, 108, 47, 255}}},
{{{ 108, 56, 296 }, 0, { 910, 840 }, { 228, 115, 44, 255}}},
{{{ 58, 2, 277 }, 0, { 1100, 562 }, { 175, 252, 97, 255}}},
{{{ 100, -62, 291 }, 0, { 952, 216 }, { 198, 200, 97, 255}}},
{{{ 381, -93, 261 }, 0, { 14, 86 }, { 44, 190, 98, 255}}},
};

Vtx VB_piranha_plant_geo_0x6015a80[] = {
{{{ 391, 10, -334 }, 0, { -64, 582 }, { 45, 24, 140, 255}}},
{{{ 385, 72, -253 }, 0, { 130, 944 }, { 22, 119, 221, 255}}},
{{{ 519, 79, 0 }, 0, { 978, 956 }, { 51, 115, 244, 255}}},
{{{ 391, 10, 335 }, 0, { 1064, 610 }, { 48, 254, 117, 255}}},
{{{ 381, -93, 261 }, 0, { 866, 20 }, { 44, 190, 98, 255}}},
{{{ 545, -83, 0 }, 0, { -96, 0 }, { 107, 191, 20, 255}}},
{{{ 597, 13, 0 }, 0, { -166, 532 }, { 124, 23, 254, 255}}},
{{{ 519, 79, 0 }, 0, { -26, 904 }, { 51, 115, 244, 255}}},
{{{ 385, 72, 255 }, 0, { 872, 938 }, { 44, 108, 47, 255}}},
{{{ 597, 13, 0 }, 0, { 1100, 560 }, { 124, 23, 254, 255}}},
{{{ 381, -93, -260 }, 0, { 88, -48 }, { 72, 191, 176, 255}}},
{{{ 545, -83, 0 }, 0, { 1000, -20 }, { 107, 191, 20, 255}}},
};

Vtx VB_piranha_plant_geo_0x6015b40[] = {
{{{ 545, -83, 0 }, 0, { -118, 908 }, { 107, 191, 20, 255}}},
{{{ 381, -93, 261 }, 0, { 1050, 888 }, { 44, 190, 98, 255}}},
{{{ 343, -231, 195 }, 0, { 880, 40 }, { 52, 160, 63, 255}}},
{{{ -76, -53, 0 }, 0, { 858, 140 }, { 141, 204, 246, 255}}},
{{{ -89, 12, 0 }, 0, { 742, -130 }, { 143, 56, 0, 255}}},
{{{ 56, 2, -271 }, 0, { -398, 542 }, { 175, 251, 159, 255}}},
{{{ 101, -60, -288 }, 0, { -382, 902 }, { 216, 201, 150, 255}}},
{{{ 148, -221, -195 }, 0, { 230, 1518 }, { 202, 163, 191, 255}}},
{{{ 11, -205, 0 }, 0, { 1066, 914 }, { 171, 163, 12, 255}}},
{{{ 58, 2, 277 }, 0, { 1510, 656 }, { 175, 252, 97, 255}}},
{{{ -89, 12, 0 }, 0, { 64, 1326 }, { 143, 56, 0, 255}}},
{{{ -76, -53, 0 }, 0, { -16, 1022 }, { 141, 204, 246, 255}}},
{{{ 100, -62, 291 }, 0, { 1546, 266 }, { 198, 200, 97, 255}}},
{{{ 11, -205, 0 }, 0, { -100, 168 }, { 171, 163, 12, 255}}},
{{{ 440, -225, 0 }, 0, { 48, -18 }, { 83, 162, 243, 255}}},
{{{ 148, -222, 196 }, 0, { 962, -438 }, { 225, 162, 78, 255}}},
};

Vtx VB_piranha_plant_geo_0x6015c40[] = {
{{{ 440, -225, 0 }, 0, { -64, 1068 }, { 83, 162, 243, 255}}},
{{{ 343, -231, 195 }, 0, { 342, 310 }, { 52, 160, 63, 255}}},
{{{ 249, -293, 0 }, 0, { 640, 920 }, { 254, 130, 0, 255}}},
{{{ 381, -93, 261 }, 0, { 0, 766 }, { 44, 190, 98, 255}}},
{{{ 148, -222, 196 }, 0, { 800, -16 }, { 225, 162, 78, 255}}},
{{{ 343, -231, 195 }, 0, { -22, -8 }, { 52, 160, 63, 255}}},
{{{ 100, -62, 291 }, 0, { 1186, 906 }, { 198, 200, 97, 255}}},
{{{ 343, -231, 195 }, 0, { 1280, -514 }, { 52, 160, 63, 255}}},
{{{ 148, -222, 196 }, 0, { 738, -860 }, { 225, 162, 78, 255}}},
{{{ 249, -293, 0 }, 0, { 682, 56 }, { 254, 130, 0, 255}}},
{{{ 148, -222, 196 }, 0, { 740, -860 }, { 225, 162, 78, 255}}},
{{{ 11, -205, 0 }, 0, { -28, -436 }, { 171, 163, 12, 255}}},
{{{ 249, -293, 0 }, 0, { 592, 44 }, { 254, 130, 0, 255}}},
{{{ 148, -221, -195 }, 0, { -80, 542 }, { 202, 163, 191, 255}}},
{{{ 343, -231, -194 }, 0, { 430, 930 }, { 33, 161, 179, 255}}},
{{{ 440, -225, 0 }, 0, { 1090, 430 }, { 83, 162, 243, 255}}},
};

Vtx VB_piranha_plant_geo_0x6015d40[] = {
{{{ 101, -60, -288 }, 0, { -78, 848 }, { 216, 201, 150, 255}}},
{{{ 343, -231, -194 }, 0, { 878, 562 }, { 33, 161, 179, 255}}},
{{{ 148, -221, -195 }, 0, { 264, 390 }, { 202, 163, 191, 255}}},
{{{ 381, -93, -260 }, 0, { 838, 1014 }, { 72, 191, 176, 255}}},
{{{ 381, -93, -260 }, 0, { -186, 708 }, { 72, 191, 176, 255}}},
{{{ 440, -225, 0 }, 0, { 862, -86 }, { 83, 162, 243, 255}}},
{{{ 343, -231, -194 }, 0, { -84, -2 }, { 33, 161, 179, 255}}},
{{{ 545, -83, 0 }, 0, { 1162, 670 }, { 107, 191, 20, 255}}},
};

Vtx VB_piranha_plant_geo_0x6015dc0[] = {
{{{ 108, 56, 296 }, 0, { 0, 0 }, { 228, 115, 44, 255}}},
{{{ 108, 56, -294 }, 0, { 0, 0 }, { 218, 101, 191, 255}}},
{{{ -89, 12, 0 }, 0, { 0, 0 }, { 143, 56, 0, 255}}},
{{{ 519, 79, 0 }, 0, { 0, 0 }, { 51, 115, 244, 255}}},
{{{ 385, 72, -253 }, 0, { 0, 0 }, { 22, 119, 221, 255}}},
{{{ 385, 72, 255 }, 0, { 0, 0 }, { 44, 108, 47, 255}}},
{{{ 58, 2, 277 }, 0, { 0, 0 }, { 175, 252, 97, 255}}},
{{{ 56, 2, -271 }, 0, { 0, 0 }, { 175, 251, 159, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016190[] = {
{{{ 228, 3, 232 }, 0, { -2174, 1002 }, { 245, 0, 126, 255}}},
{{{ 412, -109, 249 }, 0, { 988, 986 }, { 81, 0, 97, 255}}},
{{{ 412, -41, 249 }, 0, { 982, -34 }, { 245, 0, 126, 255}}},
{{{ 412, -39, -248 }, 0, { 984, 58 }, { 57, 0, 143, 255}}},
{{{ 412, -109, -248 }, 0, { 990, 990 }, { 80, 0, 158, 255}}},
{{{ 229, 3, -229 }, 0, { -2282, 990 }, { 243, 0, 130, 255}}},
{{{ 554, -39, 0 }, 0, { -36, -44 }, { 126, 0, 0, 255}}},
{{{ 412, -109, -248 }, 0, { 4004, 996 }, { 80, 0, 158, 255}}},
{{{ 412, -39, -248 }, 0, { 4006, -36 }, { 57, 0, 143, 255}}},
{{{ 554, -109, 0 }, 0, { -38, 990 }, { 126, 0, 0, 255}}},
{{{ 412, -39, 249 }, 0, { -3106, -70 }, { 110, 0, 62, 255}}},
{{{ 412, -109, 249 }, 0, { -3106, 952 }, { 81, 0, 97, 255}}},
{{{ 554, -39, 0 }, 0, { 990, 0 }, { 126, 0, 0, 255}}},
{{{ 554, -109, 0 }, 0, { 990, 990 }, { 126, 0, 0, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016270[] = {
{{{ 109, -3, -277 }, 0, { -290, 482 }, { 196, 177, 178, 255}}},
{{{ 432, 43, -319 }, 0, { 2054, 520 }, { 43, 251, 137, 255}}},
{{{ 410, -50, -253 }, 0, { 1758, -58 }, { 27, 137, 225, 255}}},
{{{ 410, -50, 254 }, 0, { 1096, -6 }, { 18, 134, 26, 255}}},
{{{ 554, -47, 0 }, 0, { -1736, -12 }, { 28, 133, 2, 255}}},
{{{ 645, 27, 0 }, 0, { -2250, 462 }, { 126, 4, 0, 255}}},
{{{ 432, 43, 320 }, 0, { 1488, 596 }, { 43, 251, 119, 255}}},
{{{ 417, 98, 263 }, 0, { 1116, 942 }, { 61, 86, 69, 255}}},
{{{ 551, 106, 0 }, 0, { -1734, 970 }, { 91, 87, 247, 255}}},
{{{ 645, 27, 0 }, 0, { 1558, 510 }, { 126, 4, 0, 255}}},
{{{ 432, 43, -319 }, 0, { -1512, 534 }, { 43, 251, 137, 255}}},
{{{ 417, 98, -262 }, 0, { -1202, 890 }, { 43, 87, 175, 255}}},
{{{ 410, -50, -253 }, 0, { -1164, -52 }, { 27, 137, 225, 255}}},
{{{ 554, -47, 0 }, 0, { 1168, 24 }, { 28, 133, 2, 255}}},
{{{ 551, 106, 0 }, 0, { 1146, 998 }, { 91, 87, 247, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016360[] = {
{{{ 109, -3, 278 }, 0, { -848, 398 }, { 196, 177, 78, 255}}},
{{{ 153, 41, 300 }, 0, { -1332, 812 }, { 214, 61, 102, 255}}},
{{{ -39, 22, 0 }, 0, { 2340, 726 }, { 145, 59, 10, 255}}},
{{{ 153, 41, -299 }, 0, { 80, 732 }, { 197, 59, 161, 255}}},
{{{ 417, 98, -262 }, 0, { 1982, 884 }, { 43, 87, 175, 255}}},
{{{ 432, 43, -319 }, 0, { 2054, 520 }, { 43, 251, 137, 255}}},
{{{ 109, -3, -277 }, 0, { -290, 482 }, { 196, 177, 178, 255}}},
{{{ 153, 41, 300 }, 0, { 1252, 774 }, { 214, 61, 102, 255}}},
{{{ 109, -3, 278 }, 0, { 1494, 500 }, { 196, 177, 78, 255}}},
{{{ 432, 43, 320 }, 0, { -100, 618 }, { 43, 251, 119, 255}}},
{{{ 417, 98, 263 }, 0, { -30, 998 }, { 61, 86, 69, 255}}},
{{{ 410, -50, 254 }, 0, { 74, 2 }, { 18, 134, 26, 255}}},
{{{ -48, -7, 0 }, 0, { 2426, 480 }, { 214, 137, 0, 255}}},
{{{ 109, -3, -277 }, 0, { 920, 274 }, { 196, 177, 178, 255}}},
{{{ -48, -7, 0 }, 0, { -36, 506 }, { 214, 137, 0, 255}}},
{{{ -39, 22, 0 }, 0, { -30, 756 }, { 145, 59, 10, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016460[] = {
{{{ -39, 22, 0 }, 0, { -30, 756 }, { 145, 59, 10, 255}}},
{{{ 153, 41, -299 }, 0, { 1032, 676 }, { 197, 59, 161, 255}}},
{{{ 109, -3, -277 }, 0, { 920, 274 }, { 196, 177, 178, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016490[] = {
{{{ 276, 254, 0 }, 0, { 514, 234 }, { 248, 126, 0, 255}}},
{{{ 177, 186, 185 }, 0, { -146, 84 }, { 199, 95, 61, 255}}},
{{{ 373, 203, 195 }, 0, { 8, 832 }, { 23, 104, 68, 255}}},
{{{ 470, 201, 0 }, 0, { 750, 1032 }, { 74, 102, 10, 255}}},
{{{ 373, 203, -194 }, 0, { 1288, 480 }, { 43, 103, 198, 255}}},
{{{ 177, 186, -184 }, 0, { 1068, -250 }, { 220, 98, 185, 255}}},
{{{ 37, 161, 0 }, 0, { 334, -600 }, { 170, 92, 244, 255}}},
{{{ 373, 203, -194 }, 0, { 906, 12 }, { 43, 103, 198, 255}}},
{{{ 470, 201, 0 }, 0, { 12, 40 }, { 74, 102, 10, 255}}},
{{{ 551, 106, 0 }, 0, { -58, 818 }, { 91, 87, 247, 255}}},
{{{ 417, 98, -262 }, 0, { 1162, 832 }, { 43, 87, 175, 255}}},
{{{ 177, 186, -184 }, 0, { 654, 76 }, { 220, 98, 185, 255}}},
{{{ 417, 98, -262 }, 0, { -30, 742 }, { 43, 87, 175, 255}}},
{{{ 153, 41, -299 }, 0, { 1006, 786 }, { 197, 59, 161, 255}}},
{{{ 373, 203, -194 }, 0, { -52, 210 }, { 43, 103, 198, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016580[] = {
{{{ 470, 201, 0 }, 0, { 1006, 194 }, { 74, 102, 10, 255}}},
{{{ 417, 98, 263 }, 0, { -92, 386 }, { 61, 86, 69, 255}}},
{{{ 551, 106, 0 }, 0, { 920, 662 }, { 91, 87, 247, 255}}},
{{{ 37, 161, 0 }, 0, { 1384, 18 }, { 170, 92, 244, 255}}},
{{{ 177, 186, -184 }, 0, { 406, -90 }, { 220, 98, 185, 255}}},
{{{ 153, 41, -299 }, 0, { 84, 726 }, { 197, 59, 161, 255}}},
{{{ -39, 22, 0 }, 0, { 1582, 740 }, { 145, 59, 10, 255}}},
{{{ 177, 186, 185 }, 0, { 1240, -122 }, { 199, 95, 61, 255}}},
{{{ 37, 161, 0 }, 0, { 50, 0 }, { 170, 92, 244, 255}}},
{{{ -39, 22, 0 }, 0, { -102, 668 }, { 145, 59, 10, 255}}},
{{{ 153, 41, 300 }, 0, { 1742, 618 }, { 214, 61, 102, 255}}},
{{{ 373, 203, 195 }, 0, { 1746, 660 }, { 23, 104, 68, 255}}},
{{{ 177, 186, 185 }, 0, { 848, 1242 }, { 199, 95, 61, 255}}},
{{{ 153, 41, 300 }, 0, { 134, 728 }, { 214, 61, 102, 255}}},
{{{ 417, 98, 263 }, 0, { 1526, 116 }, { 61, 86, 69, 255}}},
{{{ 373, 203, 195 }, 0, { 272, -30 }, { 23, 104, 68, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016680[] = {
{{{ 153, 26, 221 }, 0, { 808, 604 }, { 2, 132, 232, 255}}},
{{{ -48, -7, 0 }, 0, { 486, -60 }, { 214, 137, 0, 255}}},
{{{ 153, 26, -220 }, 0, { 162, 604 }, { 249, 131, 18, 255}}},
{{{ 410, -50, 254 }, 0, { 858, 1440 }, { 18, 134, 26, 255}}},
{{{ 554, -47, 0 }, 0, { 486, 1912 }, { 28, 133, 2, 255}}},
{{{ 410, -50, -253 }, 0, { 114, 1440 }, { 27, 137, 225, 255}}},
};

Vtx VB_piranha_plant_geo_0x60166e0[] = {
{{{ 410, -50, -253 }, 0, { 0, 0 }, { 27, 137, 225, 255}}},
{{{ 153, 26, -220 }, 0, { 0, 0 }, { 249, 131, 18, 255}}},
{{{ 109, -3, -277 }, 0, { 0, 0 }, { 196, 177, 178, 255}}},
{{{ -48, -7, 0 }, 0, { 0, 0 }, { 214, 137, 0, 255}}},
{{{ 153, 26, 221 }, 0, { 0, 0 }, { 2, 132, 232, 255}}},
{{{ 109, -3, 278 }, 0, { 0, 0 }, { 196, 177, 78, 255}}},
{{{ 410, -50, 254 }, 0, { 0, 0 }, { 18, 134, 26, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016ae8[] = {
{{{ 10, 34, 0 }, 0, { 0, 990 }, { 5, 111, 60, 255}}},
{{{ 11, -23, 35 }, 0, { 990, 990 }, { 7, 148, 66, 255}}},
{{{ 191, -17, 26 }, 0, { 918, 0 }, { 6, 3, 126, 255}}},
{{{ 191, 26, 0 }, 0, { 142, 0 }, { 4, 109, 192, 255}}},
{{{ 11, -25, -33 }, 0, { 0, 990 }, { 5, 255, 130, 255}}},
{{{ 10, 34, 0 }, 0, { 950, 990 }, { 5, 111, 60, 255}}},
{{{ 191, 26, 0 }, 0, { 864, -26 }, { 4, 109, 192, 255}}},
{{{ 191, -18, -25 }, 0, { 118, -28 }, { 6, 145, 196, 255}}},
{{{ 11, -23, 35 }, 0, { 0, 990 }, { 7, 148, 66, 255}}},
{{{ 11, -25, -33 }, 0, { 990, 990 }, { 5, 255, 130, 255}}},
{{{ 191, -18, -25 }, 0, { 860, -30 }, { 6, 145, 196, 255}}},
{{{ 191, -17, 26 }, 0, { 84, -30 }, { 6, 3, 126, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016c70[] = {
{{{ -1, 34, 0 }, 0, { 0, 990 }, { 1, 111, 60, 255}}},
{{{ 0, -26, 37 }, 0, { 990, 990 }, { 3, 148, 66, 255}}},
{{{ 172, -22, 33 }, 0, { 938, -26 }, { 2, 3, 126, 255}}},
{{{ 172, 32, 0 }, 0, { 22, -26 }, { 1, 109, 191, 255}}},
{{{ 0, -28, -35 }, 0, { -46, 984 }, { 2, 255, 130, 255}}},
{{{ -1, 34, 0 }, 0, { 974, 986 }, { 1, 111, 60, 255}}},
{{{ 172, 32, 0 }, 0, { 942, 0 }, { 1, 109, 191, 255}}},
{{{ 172, -24, -31 }, 0, { 26, -34 }, { 4, 145, 196, 255}}},
{{{ 0, -26, 37 }, 0, { 0, 990 }, { 3, 148, 66, 255}}},
{{{ 0, -28, -35 }, 0, { 990, 990 }, { 2, 255, 130, 255}}},
{{{ 172, -24, -31 }, 0, { 954, -30 }, { 4, 145, 196, 255}}},
{{{ 172, -22, 33 }, 0, { 38, -30 }, { 2, 3, 126, 255}}},
};

Vtx VB_piranha_plant_geo_0x6016df8[] = {
{{{ -18, 36, 0 }, 0, { 0, 990 }, { 2, 111, 61, 255}}},
{{{ -18, -27, 38 }, 0, { 990, 990 }, { 2, 148, 65, 255}}},
{{{ 174, -25, 34 }, 0, { 946, -12 }, { 2, 2, 126, 255}}},
{{{ 174, 32, 0 }, 0, { 6, -12 }, { 2, 109, 192, 255}}},
{{{ -18, -28, -36 }, 0, { -48, 990 }, { 1, 255, 130, 255}}},
{{{ -18, 36, 0 }, 0, { 994, 990 }, { 2, 111, 61, 255}}},
{{{ 174, 32, 0 }, 0, { 986, -30 }, { 2, 109, 192, 255}}},
{{{ 174, -27, -33 }, 0, { 26, 0 }, { 1, 145, 195, 255}}},
{{{ -18, -27, 38 }, 0, { -36, 992 }, { 2, 148, 65, 255}}},
{{{ -18, -28, -36 }, 0, { 990, 990 }, { 1, 255, 130, 255}}},
{{{ 174, -27, -33 }, 0, { 958, 0 }, { 1, 145, 195, 255}}},
{{{ 174, -25, 34 }, 0, { 12, -28 }, { 2, 2, 126, 255}}},
};

Light_t Light_piranha_plant_geo_0x60113b8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_piranha_plant_geo_0x60113b0 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_piranha_plant_geo_0x6015850[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6015798),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015798[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_06012BF8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x60155e8, 14, 0),
gsSP2Triangles(0, 1, 2, 0,3, 1, 0, 0),
gsSP2Triangles(3, 4, 1, 0,5, 6, 7, 0),
gsSP2Triangles(5, 8, 6, 0,7, 6, 9, 0),
gsSP2Triangles(10, 11, 12, 0,10, 12, 13, 0),
gsSPVertex(VB_piranha_plant_geo_0x60156c8, 13, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,9, 7, 6, 0),
gsSP2Triangles(9, 10, 7, 0,11, 1, 0, 0),
gsSP1Triangle(11, 12, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016f20[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6016eb8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016eb8[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_06012BF8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6016df8, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,4, 6, 7, 0),
gsSP2Triangles(8, 9, 10, 0,8, 10, 11, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016d98[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6016d30),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016d30[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_06012BF8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6016c70, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,4, 6, 7, 0),
gsSP2Triangles(8, 9, 10, 0,8, 10, 11, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016c10[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6016ba8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016ba8[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_06012BF8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6016ae8, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,4, 6, 7, 0),
gsSP2Triangles(8, 9, 10, 0,8, 10, 11, 0),
gsSPEndDisplayList(),
};

Light_t Light_piranha_plant_geo_0x60113d0 = {
{ 221, 221, 221}, 0, { 43, 174, 10}, 0, { 40, 40, 40}, 0
};

Light_t Light_piranha_plant_geo_0x60113e8 = {
{ 255, 0, 0}, 0, { 255, 0, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_piranha_plant_geo_0x60113c8 = {
{51, 51, 51}, 0, {10, 43, 2}, 0
};

Ambient_t Light_piranha_plant_geo_0x60113e0 = {
{63, 0, 0}, 0, {63, 0, 0}, 0
};

Gfx DL_piranha_plant_geo_0x60160b0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6015ea8),
gsSPDisplayList(DL_piranha_plant_geo_0x6015f68),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_piranha_plant_geo_0x6016060),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015ea8[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060133F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113d0.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113c8.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6015990, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 3, 0,3, 5, 8, 0),
gsSP2Triangles(3, 8, 6, 0,9, 10, 11, 0),
gsSP2Triangles(9, 11, 12, 0,13, 14, 9, 0),
gsSP1Triangle(9, 12, 13, 0),
gsSPVertex(VB_piranha_plant_geo_0x6015a80, 12, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 5, 6, 0,6, 7, 8, 0),
gsSP2Triangles(0, 2, 9, 0,9, 10, 0, 0),
gsSP1Triangle(9, 11, 10, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015f68[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060123F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6015b40, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 6, 7, 0,3, 7, 8, 0),
gsSP2Triangles(5, 6, 3, 0,9, 10, 11, 0),
gsSP2Triangles(11, 12, 9, 0,12, 11, 13, 0),
gsSP2Triangles(0, 2, 14, 0,12, 13, 15, 0),
gsSPVertex(VB_piranha_plant_geo_0x6015c40, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 6, 4, 0,7, 8, 9, 0),
gsSP2Triangles(10, 11, 12, 0,11, 13, 12, 0),
gsSP2Triangles(14, 15, 12, 0,13, 14, 12, 0),
gsSPVertex(VB_piranha_plant_geo_0x6015d40, 8, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(4, 5, 6, 0,4, 7, 5, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016060[] = {
gsSPLight(&Light_piranha_plant_geo_0x60113e8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113e0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6015dc0, 8, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 4, 0),
gsSP2Triangles(0, 5, 3, 0,0, 4, 1, 0),
gsSP2Triangles(6, 0, 2, 0,2, 1, 7, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016120[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6015e40),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015e40[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_06013BF8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x60158b0, 14, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(4, 5, 6, 0,5, 7, 6, 0),
gsSP2Triangles(8, 9, 10, 0,11, 12, 13, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x60169e8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x60167b8),
gsSPDisplayList(DL_piranha_plant_geo_0x6016890),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 6, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_piranha_plant_geo_0x6016960),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_piranha_plant_geo_0x60169a8),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x60167b8[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060133F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113d0.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113c8.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6016270, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(5, 6, 3, 0,7, 6, 5, 0),
gsSP2Triangles(5, 8, 7, 0,9, 10, 11, 0),
gsSP2Triangles(12, 10, 9, 0,9, 13, 12, 0),
gsSP1Triangle(11, 14, 9, 0),
gsSPVertex(VB_piranha_plant_geo_0x6016360, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(5, 6, 3, 0,7, 8, 9, 0),
gsSP2Triangles(9, 10, 7, 0,11, 9, 8, 0),
gsSP2Triangles(2, 12, 0, 0,13, 14, 15, 0),
gsSPVertex(VB_piranha_plant_geo_0x6016460, 3, 0),
gsSP1Triangle(0, 1, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016890[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060123F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6016490, 15, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(0, 4, 5, 0,0, 3, 4, 0),
gsSP2Triangles(0, 6, 1, 0,0, 5, 6, 0),
gsSP2Triangles(7, 8, 9, 0,7, 9, 10, 0),
gsSP2Triangles(11, 12, 13, 0,11, 14, 12, 0),
gsSPVertex(VB_piranha_plant_geo_0x6016580, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 5, 6, 0,7, 8, 9, 0),
gsSP2Triangles(7, 9, 10, 0,11, 12, 13, 0),
gsSP2Triangles(11, 13, 14, 0,0, 15, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016960[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060113F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_piranha_plant_geo_0x6016680, 6, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 0, 0),
gsSP2Triangles(2, 4, 3, 0,2, 5, 4, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x60169a8[] = {
gsSPLight(&Light_piranha_plant_geo_0x60113d0.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113c8.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x60166e0, 7, 0),
gsSP2Triangles(0, 1, 2, 0,2, 1, 3, 0),
gsSP2Triangles(3, 4, 5, 0,5, 4, 6, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016a78[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_piranha_plant_geo_0x6016750),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6016750[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_06013BF8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x6016190, 14, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,6, 9, 7, 0),
gsSP2Triangles(10, 11, 12, 0,11, 13, 12, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015480[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_piranha_plant_geo_0x6015438),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015438[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060143F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x60153f8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015578[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_piranha_plant_geo_0x6015530),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_piranha_plant_geo_0x6015530[] = {
gsDPSetTextureImage(0, 2, 1, piranha_plant_geo__texture_060143F8),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPLight(&Light_piranha_plant_geo_0x60113b8.col, 1),
gsSPLight(&Light_piranha_plant_geo_0x60113b0.col, 2),
gsSPVertex(VB_piranha_plant_geo_0x60154f0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

