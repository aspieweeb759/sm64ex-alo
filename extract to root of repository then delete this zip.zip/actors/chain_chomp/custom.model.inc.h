#ifndef chain_chomp_chain_chomp_model_HEADER_H
#define chain_chomp_chain_chomp_model_HEADER_H
#include "types.h"
extern Vtx VB_chain_chomp_geo_0x6023bd0[];
extern Vtx VB_chain_chomp_geo_0x6023c20[];
extern Vtx VB_chain_chomp_geo_0x6023d20[];
extern Vtx VB_chain_chomp_geo_0x6023e10[];
extern Vtx VB_chain_chomp_geo_0x6023f00[];
extern Vtx VB_chain_chomp_geo_0x60242d0[];
extern Vtx VB_chain_chomp_geo_0x60243b0[];
extern Vtx VB_chain_chomp_geo_0x60244b0[];
extern Vtx VB_chain_chomp_geo_0x60245b0[];
extern Vtx VB_chain_chomp_geo_0x60246b0[];
extern Vtx VB_chain_chomp_geo_0x60249e8[];
extern Vtx VB_chain_chomp_geo_0x6024b70[];
extern Vtx VB_chain_chomp_geo_0x6024c60[];
extern Vtx VB_chain_chomp_geo_0x6024dd0[];
extern Vtx VB_chain_chomp_geo_0x6024ec0[];
extern u8 chain_chomp_geo__texture_06021BD0[];
extern u8 chain_chomp_geo__texture_060223D0[];
extern Gfx DL_chain_chomp_geo_0x6024940[];
extern Gfx DL_chain_chomp_geo_0x6024700[];
extern Gfx DL_chain_chomp_geo_0x6024900[];
extern u8 chain_chomp_geo__texture_06022BD0[];
extern Gfx DL_chain_chomp_geo_0x6024fc0[];
extern Gfx DL_chain_chomp_geo_0x6024f50[];
extern u8 chain_chomp_geo__texture_060213D0[];
extern Gfx DL_chain_chomp_geo_0x6024240[];
extern Gfx DL_chain_chomp_geo_0x6024000[];
extern Gfx DL_chain_chomp_geo_0x6024040[];
extern Gfx DL_chain_chomp_geo_0x6024d60[];
extern Gfx DL_chain_chomp_geo_0x6024cf0[];
extern u8 chain_chomp_geo__texture_060233D0[];
extern Light_t Light_chain_chomp_geo_0x60249d8;
extern Ambient_t Light_chain_chomp_geo_0x60249d0;
extern Gfx DL_chain_chomp_geo_0x6024b00[];
extern Gfx DL_chain_chomp_geo_0x6024aa8[];
#endif