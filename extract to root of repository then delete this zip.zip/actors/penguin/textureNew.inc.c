ALIGNED8 u8 penguin_geo__texture_05002DE0[] = {
#include "actors/penguin/penguin_geo_0x5002de0_custom.rgba16.inc.c"
};
ALIGNED8 u8 penguin_geo__texture_050055E0[] = {
#include "actors/penguin/penguin_geo_0x50055e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 penguin_geo__texture_050035E0[] = {
#include "actors/penguin/penguin_geo_0x50035e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 penguin_geo__texture_05003DE0[] = {
#include "actors/penguin/penguin_geo_0x5003de0_custom.rgba16.inc.c"
};
ALIGNED8 u8 penguin_geo__texture_050045E0[] = {
#include "actors/penguin/penguin_geo_0x50045e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 penguin_geo__texture_05004DE0[] = {
#include "actors/penguin/penguin_geo_0x5004de0_custom.rgba16.inc.c"
};
