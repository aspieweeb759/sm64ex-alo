ALIGNED8 u8 mist_geo__texture_03000080[] = {
#include "actors/mist/mist_geo_0x3000080_custom.ia16.inc.c"
};
