#ifndef bbh_tumbling_platform_near_model_HEADER_H
#define bbh_tumbling_platform_near_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_0005F8_0x701f870[];
extern Vtx VB_geo_bbh_0005F8_0x701f960[];
extern u8 geo_bbh_0005F8__texture_09004800[];
extern Light_t Light_geo_bbh_0005F8_0x701f860;
extern Ambient_t Light_geo_bbh_0005F8_0x701f858;
extern Gfx DL_geo_bbh_0005F8_0x701fab0[];
extern Gfx DL_geo_bbh_0005F8_0x701fa10[];
#endif