#ifndef bbh_tumbling_platform_far_model_HEADER_H
#define bbh_tumbling_platform_far_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_0005E0_0x701f6c0[];
extern u8 geo_bbh_0005E0__texture_09004800[];
extern Light_t Light_geo_bbh_0005E0_0x701f6b0;
extern Ambient_t Light_geo_bbh_0005E0_0x701f6a8;
extern Gfx DL_geo_bbh_0005E0_0x701f7e8[];
extern Gfx DL_geo_bbh_0005E0_0x701f780[];
#endif