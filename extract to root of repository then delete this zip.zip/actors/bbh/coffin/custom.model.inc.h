#ifndef bbh_coffin_model_HEADER_H
#define bbh_coffin_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_000658_0x7020380[];
extern Vtx VB_geo_bbh_000658_0x7020480[];
extern Vtx VB_geo_bbh_000658_0x7020500[];
extern Vtx VB_geo_bbh_000658_0x7020560[];
extern u8 geo_bbh_000658__texture_07004400[];
extern u8 geo_bbh_000658__texture_07003000[];
extern u8 geo_bbh_000658__texture_07003400[];
extern Light_t Light_geo_bbh_000658_0x7020370;
extern Ambient_t Light_geo_bbh_000658_0x7020368;
extern Gfx DL_geo_bbh_000658_0x70206f0[];
extern Gfx DL_geo_bbh_000658_0x70205c0[];
extern Gfx DL_geo_bbh_000658_0x7020660[];
extern Gfx DL_geo_bbh_000658_0x70206a8[];
#endif