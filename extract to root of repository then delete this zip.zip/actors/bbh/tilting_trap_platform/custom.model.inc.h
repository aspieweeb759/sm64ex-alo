#ifndef bbh_tilting_trap_platform_model_HEADER_H
#define bbh_tilting_trap_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_0005C8_0x701f390[];
extern Vtx VB_geo_bbh_0005C8_0x701f3d0[];
extern Vtx VB_geo_bbh_0005C8_0x701f4d0[];
extern u8 geo_bbh_0005C8__texture_09008800[];
extern u8 geo_bbh_0005C8__texture_09005000[];
extern u8 geo_bbh_0005C8__texture_09009000[];
extern Light_t Light_geo_bbh_0005C8_0x701f380;
extern Ambient_t Light_geo_bbh_0005C8_0x701f378;
extern Gfx DL_geo_bbh_0005C8_0x701f5f8[];
extern Gfx DL_geo_bbh_0005C8_0x701f510[];
extern Gfx DL_geo_bbh_0005C8_0x701f558[];
extern Gfx DL_geo_bbh_0005C8_0x701f5c0[];
#endif