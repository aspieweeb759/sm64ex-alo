#ifndef bbh_merry_go_round_model_HEADER_H
#define bbh_merry_go_round_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_000640_0x7020070[];
extern Vtx VB_geo_bbh_000640_0x7020130[];
extern u8 geo_bbh_000640__texture_09005000[];
extern u8 geo_bbh_000640__texture_07000000[];
extern Light_t Light_geo_bbh_000640_0x7020060;
extern Ambient_t Light_geo_bbh_000640_0x7020058;
extern Gfx DL_geo_bbh_000640_0x70202f0[];
extern Gfx DL_geo_bbh_000640_0x7020230[];
extern Gfx DL_geo_bbh_000640_0x7020288[];
#endif