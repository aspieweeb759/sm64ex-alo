ALIGNED8 u8 eyerok_left_hand_geo__texture_05008D40[] = {
#include "actors/eyerok/eyerok_left_hand_geo_0x5008d40_custom.rgba16.inc.c"
};
ALIGNED8 u8 eyerok_left_hand_geo__texture_05009540[] = {
#include "actors/eyerok/eyerok_left_hand_geo_0x5009540_custom.rgba16.inc.c"
};
ALIGNED8 u8 eyerok_left_hand_geo__texture_05009D40[] = {
#include "actors/eyerok/eyerok_left_hand_geo_0x5009d40_custom.rgba16.inc.c"
};
ALIGNED8 u8 eyerok_left_hand_geo__texture_0500A540[] = {
#include "actors/eyerok/eyerok_left_hand_geo_0x500a540_custom.rgba16.inc.c"
};
ALIGNED8 u8 eyerok_left_hand_geo__texture_0500AD40[] = {
#include "actors/eyerok/eyerok_left_hand_geo_0x500ad40_custom.rgba16.inc.c"
};
