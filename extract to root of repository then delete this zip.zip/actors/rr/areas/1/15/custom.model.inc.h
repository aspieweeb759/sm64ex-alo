#ifndef rr_15_model_HEADER_H
#define rr_15_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0007A0_0x70127e8[];
extern Vtx VB_rr_geo_0007A0_0x70128d8[];
extern Vtx VB_rr_geo_0007A0_0x70129b8[];
extern Vtx VB_rr_geo_0007A0_0x7012aa8[];
extern Vtx VB_rr_geo_0007A0_0x7012b98[];
extern Vtx VB_rr_geo_0007A0_0x7012c98[];
extern Vtx VB_rr_geo_0007A0_0x7012d78[];
extern Vtx VB_rr_geo_0007A0_0x7012e68[];
extern Vtx VB_rr_geo_0007A0_0x7012f58[];
extern Vtx VB_rr_geo_0007A0_0x7013038[];
extern Vtx VB_rr_geo_0007A0_0x7013128[];
extern Vtx VB_rr_geo_0007A0_0x7013208[];
extern Vtx VB_rr_geo_0007A0_0x70132f8[];
extern Vtx VB_rr_geo_0007A0_0x70133e8[];
extern Vtx VB_rr_geo_0007A0_0x70134c8[];
extern Vtx VB_rr_geo_0007A0_0x70135c8[];
extern Vtx VB_rr_geo_0007A0_0x70136a8[];
extern Vtx VB_rr_geo_0007A0_0x7013728[];
extern Vtx VB_rr_geo_0007A0_0x7013828[];
extern Vtx VB_rr_geo_0007A0_0x70138a8[];
extern Vtx VB_rr_geo_0007A0_0x7013998[];
extern Vtx VB_rr_geo_0007A0_0x7013a88[];
extern Vtx VB_rr_geo_0007A0_0x7013b88[];
extern Vtx VB_rr_geo_0007A0_0x7013c88[];
extern u8 rr_geo_0007A0__texture_09007000[];
extern u8 rr_geo_0007A0__texture_09000800[];
extern u8 rr_geo_0007A0__texture_09008000[];
extern Gfx DL_rr_geo_0007A0_0x7014340[];
extern Gfx DL_rr_geo_0007A0_0x7013ce8[];
extern Gfx DL_rr_geo_0007A0_0x7014140[];
extern Gfx DL_rr_geo_0007A0_0x70141d0[];
extern Gfx DL_rr_geo_0007A0_0x7014310[];
#endif