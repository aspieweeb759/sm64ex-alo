#ifndef rr_12_model_HEADER_H
#define rr_12_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000758_0x700def8[];
extern Vtx VB_rr_geo_000758_0x700dff8[];
extern u8 rr_geo_000758__texture_09000000[];
extern u8 rr_geo_000758__texture_09004800[];
extern Gfx DL_rr_geo_000758_0x700e178[];
extern Gfx DL_rr_geo_000758_0x700e0a8[];
extern Gfx DL_rr_geo_000758_0x700e110[];
#endif