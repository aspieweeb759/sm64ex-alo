#ifndef rr_11_model_HEADER_H
#define rr_11_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000738_0x700cab8[];
extern Vtx VB_rr_geo_000738_0x700cba8[];
extern Vtx VB_rr_geo_000738_0x700cca8[];
extern Vtx VB_rr_geo_000738_0x700cd88[];
extern Vtx VB_rr_geo_000738_0x700ce88[];
extern Vtx VB_rr_geo_000738_0x700cf88[];
extern Vtx VB_rr_geo_000738_0x700d078[];
extern Vtx VB_rr_geo_000738_0x700d178[];
extern Vtx VB_rr_geo_000738_0x700d268[];
extern Vtx VB_rr_geo_000738_0x700d358[];
extern Vtx VB_rr_geo_000738_0x700d448[];
extern Vtx VB_rr_geo_000738_0x700d488[];
extern Vtx VB_rr_geo_000738_0x700d588[];
extern Vtx VB_rr_geo_000738_0x700d688[];
extern Vtx VB_rr_geo_000738_0x700d708[];
extern Vtx VB_rr_geo_000738_0x700dc58[];
extern Vtx VB_rr_geo_000738_0x700dd48[];
extern u8 rr_geo_000738__texture_09004800[];
extern u8 rr_geo_000738__texture_09000800[];
extern Gfx DL_rr_geo_000738_0x700dbd8[];
extern Gfx DL_rr_geo_000738_0x700d768[];
extern Gfx DL_rr_geo_000738_0x700dad8[];
extern Gfx DL_rr_geo_000738_0x700dba8[];
extern u8 rr_geo_000738__texture_09006800[];
extern Gfx DL_rr_geo_000738_0x700de88[];
extern Gfx DL_rr_geo_000738_0x700ddf8[];
#endif