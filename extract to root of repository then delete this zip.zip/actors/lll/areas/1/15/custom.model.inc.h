#ifndef lll_15_model_HEADER_H
#define lll_15_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000AF0_0x7017be8[];
extern Vtx VB_lll_geo_000AF0_0x7017cd8[];
extern Vtx VB_lll_geo_000AF0_0x7017dd8[];
extern u8 lll_geo_000AF0__texture_09000800[];
extern Gfx DL_lll_geo_000AF0_0x7017f40[];
extern Gfx DL_lll_geo_000AF0_0x7017e68[];
#endif