#ifndef lll_8_model_HEADER_H
#define lll_8_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000A40_0x70154f8[];
extern Vtx VB_lll_geo_000A40_0x70155e8[];
extern Vtx VB_lll_geo_000A40_0x70156e8[];
extern Vtx VB_lll_geo_000A40_0x7015758[];
extern Vtx VB_lll_geo_000A40_0x7015858[];
extern Vtx VB_lll_geo_000A40_0x7015948[];
extern Vtx VB_lll_geo_000A40_0x7015a38[];
extern u8 lll_geo_000A40__texture_09006800[];
extern u8 lll_geo_000A40__texture_09006000[];
extern Light_t Light_lll_geo_000A40_0x700fc08;
extern Ambient_t Light_lll_geo_000A40_0x700fc00;
extern Gfx DL_lll_geo_000A40_0x7015c88[];
extern Gfx DL_lll_geo_000A40_0x7015b38[];
extern Gfx DL_lll_geo_000A40_0x7015c20[];
extern u8 lll_geo_000A40__texture_09000800[];
extern Gfx DL_lll_geo_000A40_0x7015e20[];
extern Gfx DL_lll_geo_000A40_0x7015d18[];
#endif