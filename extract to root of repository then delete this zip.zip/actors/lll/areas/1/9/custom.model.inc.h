#ifndef lll_9_model_HEADER_H
#define lll_9_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000A60_0x7015e90[];
extern Vtx VB_lll_geo_000A60_0x7015f10[];
extern Vtx VB_lll_geo_000A60_0x7016000[];
extern Vtx VB_lll_geo_000A60_0x70160f0[];
extern u8 lll_geo_000A60__texture_09005000[];
extern u8 lll_geo_000A60__texture_09007800[];
extern Light_t Light_lll_geo_000A60_0x700fc08;
extern Ambient_t Light_lll_geo_000A60_0x700fc00;
extern Gfx DL_lll_geo_000A60_0x7016250[];
extern Gfx DL_lll_geo_000A60_0x7016130[];
extern Gfx DL_lll_geo_000A60_0x7016198[];
#endif