#ifndef lll_drawbridge_part_model_HEADER_H
#define lll_drawbridge_part_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000B20_0x70183f0[];
extern Vtx VB_lll_geo_000B20_0x7018470[];
extern Vtx VB_lll_geo_000B20_0x70184b0[];
extern Vtx VB_lll_geo_000B20_0x70184f0[];
extern u8 lll_geo_000B20__texture_07005000[];
extern u8 lll_geo_000B20__texture_0900A000[];
extern u8 lll_geo_000B20__texture_09001800[];
extern u8 lll_geo_000B20__texture_07000800[];
extern Light_t Light_lll_geo_000B20_0x700fc08;
extern Ambient_t Light_lll_geo_000B20_0x700fc00;
extern Gfx DL_lll_geo_000B20_0x7018680[];
extern Gfx DL_lll_geo_000B20_0x7018570[];
extern Gfx DL_lll_geo_000B20_0x70185c8[];
extern Gfx DL_lll_geo_000B20_0x7018600[];
extern Gfx DL_lll_geo_000B20_0x7018638[];
#endif