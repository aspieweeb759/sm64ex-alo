#ifndef lll_moving_octagonal_mesh_platform_model_HEADER_H
#define lll_moving_octagonal_mesh_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000B08_0x7017fb0[];
extern Vtx VB_lll_geo_000B08_0x7018090[];
extern Vtx VB_lll_geo_000B08_0x7018180[];
extern u8 lll_geo_000B08__texture_09000800[];
extern Light_t Light_lll_geo_000B08_0x700fc08;
extern Ambient_t Light_lll_geo_000B08_0x700fc00;
extern Gfx DL_lll_geo_000B08_0x7018380[];
extern Gfx DL_lll_geo_000B08_0x7018280[];
#endif