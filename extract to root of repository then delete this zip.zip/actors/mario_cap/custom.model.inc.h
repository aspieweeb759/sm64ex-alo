#ifndef mario_cap_mario_cap_model_HEADER_H
#define mario_cap_mario_cap_model_HEADER_H
#include "types.h"
extern Vtx VB_marios_cap_geo_0x3022750[];
extern Vtx VB_marios_cap_geo_0x30227c0[];
extern Vtx VB_marios_cap_geo_0x30228c0[];
extern Vtx VB_marios_cap_geo_0x30229b0[];
extern Vtx VB_marios_cap_geo_0x3022aa0[];
extern Vtx VB_marios_cap_geo_0x3022d38[];
extern Vtx VB_marios_cap_geo_0x3022df8[];
extern u8 marios_winged_metal_cap_geo__texture_0301CF50[];
extern Light_t Light_marios_winged_metal_cap_geo_0x301cf28;
extern Ambient_t Light_marios_winged_metal_cap_geo_0x301cf20;
extern Gfx DL_marios_winged_metal_cap_geo_0x3022ff8[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022b30[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022b68[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022cc8[];
extern u8 marios_winged_metal_cap_geo__texture_03020750[];
extern u8 marios_winged_metal_cap_geo__texture_03021750[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3023108[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022ed8[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022e78[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022ea8[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3022f20[];
extern Gfx DL_marios_winged_metal_cap_geo_0x3023298[];
extern u8 marios_wing_cap_geo__texture_0301DF50[];
extern Light_t Light_marios_wing_cap_geo_0x301cf40;
extern Light_t Light_marios_wing_cap_geo_0x301cf10;
extern Ambient_t Light_marios_wing_cap_geo_0x301cf38;
extern Ambient_t Light_marios_wing_cap_geo_0x301cf08;
extern Gfx DL_marios_wing_cap_geo_0x3022f48[];
extern Gfx DL_marios_wing_cap_geo_0x3022d10[];
extern u8 marios_wing_cap_geo__texture_0301E750[];
extern u8 marios_wing_cap_geo__texture_0301F750[];
extern Gfx DL_marios_wing_cap_geo_0x30230b0[];
extern Gfx DL_marios_wing_cap_geo_0x3023160[];
#endif