ALIGNED8 u8 cyan_fish_geo__texture_0600D468[] = {
#include "actors/cyan_fish/cyan_fish_geo_0x600d468_custom.rgba16.inc.c"
};
