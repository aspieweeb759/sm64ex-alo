ALIGNED8 u8 haunted_chair_geo__texture_05004060[] = {
#include "actors/haunted_chair/haunted_chair_geo_0x5004060_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_chair_geo__texture_05003860[] = {
#include "actors/haunted_chair/haunted_chair_geo_0x5003860_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_chair_geo__texture_05003060[] = {
#include "actors/haunted_chair/haunted_chair_geo_0x5003060_custom.rgba16.inc.c"
};
