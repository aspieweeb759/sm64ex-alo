ALIGNED8 u8 goomba_geo__texture_08019530[] = {
#include "actors/goomba/goomba_geo_0x8019530_custom.rgba16.inc.c"
};
ALIGNED8 u8 goomba_geo__texture_08019D40[] = {
#include "actors/goomba/goomba_geo_0x8019d40_custom.rgba16.inc.c"
};
