ALIGNED8 u8 FlipBlock_MOP__texture_005F0010[] = {
#include "actors/FlipBlock_MOP/FlipBlock_MOP_0x5f0010_custom.rgba16.inc.c"
};
