ALIGNED8 u8 heave_ho_geo__texture_0500E9C8[] = {
#include "actors/heave_ho/heave_ho_geo_0x500e9c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 heave_ho_geo__texture_050109C8[] = {
#include "actors/heave_ho/heave_ho_geo_0x50109c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 heave_ho_geo__texture_0500F9C8[] = {
#include "actors/heave_ho/heave_ho_geo_0x500f9c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 heave_ho_geo__texture_050113C8[] = {
#include "actors/heave_ho/heave_ho_geo_0x50113c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 heave_ho_geo__texture_050111C8[] = {
#include "actors/heave_ho/heave_ho_geo_0x50111c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 heave_ho_geo__texture_0500F1C8[] = {
#include "actors/heave_ho/heave_ho_geo_0x500f1c8_custom.rgba16.inc.c"
};
