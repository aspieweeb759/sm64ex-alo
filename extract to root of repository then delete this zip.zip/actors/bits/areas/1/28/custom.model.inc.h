#ifndef bits_28_model_HEADER_H
#define bits_28_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0006A0_0x7014c98[];
extern Vtx VB_bits_geo_0006A0_0x7014cd8[];
extern Vtx VB_bits_geo_0006A0_0x7014dd8[];
extern Vtx VB_bits_geo_0006A0_0x7014ec8[];
extern Vtx VB_bits_geo_0006A0_0x7014fa8[];
extern Vtx VB_bits_geo_0006A0_0x7015088[];
extern Vtx VB_bits_geo_0006A0_0x7015168[];
extern u8 bits_geo_0006A0__texture_09007000[];
extern u8 bits_geo_0006A0__texture_09008000[];
extern Gfx DL_bits_geo_0006A0_0x70153c0[];
extern Gfx DL_bits_geo_0006A0_0x7015218[];
extern Gfx DL_bits_geo_0006A0_0x7015250[];
#endif