#ifndef bits_26_model_HEADER_H
#define bits_26_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000670_0x7013f68[];
extern Vtx VB_bits_geo_000670_0x7014068[];
extern u8 bits_geo_000670__texture_09000800[];
extern Gfx DL_bits_geo_000670_0x7014178[];
extern Gfx DL_bits_geo_000670_0x70140e8[];
#endif