#ifndef bits_31_model_HEADER_H
#define bits_31_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0006E8_0x7016378[];
extern Vtx VB_bits_geo_0006E8_0x70163b8[];
extern Vtx VB_bits_geo_0006E8_0x70164b8[];
extern Vtx VB_bits_geo_0006E8_0x70165a8[];
extern Vtx VB_bits_geo_0006E8_0x7016688[];
extern Vtx VB_bits_geo_0006E8_0x7016768[];
extern Vtx VB_bits_geo_0006E8_0x7016848[];
extern u8 bits_geo_0006E8__texture_09007000[];
extern u8 bits_geo_0006E8__texture_09008000[];
extern Gfx DL_bits_geo_0006E8_0x7016aa0[];
extern Gfx DL_bits_geo_0006E8_0x70168f8[];
extern Gfx DL_bits_geo_0006E8_0x7016930[];
#endif