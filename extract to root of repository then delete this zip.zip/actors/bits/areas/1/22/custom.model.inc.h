#ifndef bits_22_model_HEADER_H
#define bits_22_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000610_0x7012df8[];
extern Vtx VB_bits_geo_000610_0x7012e78[];
extern Vtx VB_bits_geo_000610_0x7012f58[];
extern Vtx VB_bits_geo_000610_0x7013058[];
extern Vtx VB_bits_geo_000610_0x70130f8[];
extern Vtx VB_bits_geo_000610_0x70131e8[];
extern Vtx VB_bits_geo_000610_0x70132d8[];
extern u8 bits_geo_000610__texture_09001800[];
extern Light_t Light_bits_geo_000610_0x7012db8;
extern Light_t Light_bits_geo_000610_0x7012dd0;
extern Light_t Light_bits_geo_000610_0x7012de8;
extern Ambient_t Light_bits_geo_000610_0x7012db0;
extern Ambient_t Light_bits_geo_000610_0x7012dc8;
extern Ambient_t Light_bits_geo_000610_0x7012de0;
extern Gfx DL_bits_geo_000610_0x70135a0[];
extern Gfx DL_bits_geo_000610_0x70133b8[];
#endif