#ifndef bits_3_model_HEADER_H
#define bits_3_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000448_0x70036f8[];
extern Vtx VB_bits_geo_000448_0x70037f8[];
extern Vtx VB_bits_geo_000448_0x70038f8[];
extern Vtx VB_bits_geo_000448_0x70039d8[];
extern Vtx VB_bits_geo_000448_0x7003ac8[];
extern Vtx VB_bits_geo_000448_0x7003bc8[];
extern Vtx VB_bits_geo_000448_0x7003c88[];
extern Vtx VB_bits_geo_000448_0x7003d88[];
extern Vtx VB_bits_geo_000448_0x7003e68[];
extern Vtx VB_bits_geo_000448_0x7003f68[];
extern Vtx VB_bits_geo_000448_0x7004048[];
extern Vtx VB_bits_geo_000448_0x7004138[];
extern Vtx VB_bits_geo_000448_0x70041a8[];
extern Vtx VB_bits_geo_000448_0x70042a8[];
extern Vtx VB_bits_geo_000448_0x70043a8[];
extern u8 bits_geo_000448__texture_09001800[];
extern u8 bits_geo_000448__texture_09008000[];
extern u8 bits_geo_000448__texture_09007000[];
extern u8 bits_geo_000448__texture_09001000[];
extern Gfx DL_bits_geo_000448_0x70047f0[];
extern Gfx DL_bits_geo_000448_0x70043e8[];
extern Gfx DL_bits_geo_000448_0x7004590[];
extern Gfx DL_bits_geo_000448_0x70045f8[];
extern Gfx DL_bits_geo_000448_0x7004720[];
extern Gfx DL_bits_geo_000448_0x70047d0[];
#endif