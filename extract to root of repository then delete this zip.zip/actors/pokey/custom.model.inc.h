#ifndef pokey_pokey_model_HEADER_H
#define pokey_pokey_model_HEADER_H
#include "types.h"
extern Vtx VB_pokey_body_part_geo_0x5011710[];
extern Vtx VB_pokey_body_part_geo_0x5012838[];
extern u8 pokey_head_geo__texture_05011750[];
extern Gfx DL_pokey_head_geo_0x50127d8[];
extern Gfx DL_pokey_head_geo_0x5012750[];
extern Gfx DL_pokey_head_geo_0x5012798[];
extern u8 pokey_head_geo__texture_05011F50[];
extern Gfx DL_pokey_head_geo_0x5012808[];
extern u8 pokey_body_part_geo__texture_05012878[];
extern Gfx DL_pokey_body_part_geo_0x50130b0[];
extern Gfx DL_pokey_body_part_geo_0x5013078[];
#endif