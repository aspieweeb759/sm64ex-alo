#ifndef ccm_6_model_HEADER_H
#define ccm_6_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_00042C_0x700dec8[];
extern Vtx VB_ccm_geo_00042C_0x700df88[];
extern Vtx VB_ccm_geo_00042C_0x700e068[];
extern Vtx VB_ccm_geo_00042C_0x700e168[];
extern Vtx VB_ccm_geo_00042C_0x700e268[];
extern Vtx VB_ccm_geo_00042C_0x700e2c8[];
extern Vtx VB_ccm_geo_00042C_0x700e3a8[];
extern Vtx VB_ccm_geo_00042C_0x700e428[];
extern Vtx VB_ccm_geo_00042C_0x700e468[];
extern Vtx VB_ccm_geo_00042C_0x700e790[];
extern Vtx VB_ccm_geo_00042C_0x700e850[];
extern u8 ccm_geo_00042C__texture_09008800[];
extern u8 ccm_geo_00042C__texture_09005000[];
extern u8 ccm_geo_00042C__texture_09008000[];
extern Light_t Light_ccm_geo_00042C_0x700de70;
extern Light_t Light_ccm_geo_00042C_0x700de88;
extern Light_t Light_ccm_geo_00042C_0x700dea0;
extern Light_t Light_ccm_geo_00042C_0x700deb8;
extern Ambient_t Light_ccm_geo_00042C_0x700de68;
extern Ambient_t Light_ccm_geo_00042C_0x700de80;
extern Ambient_t Light_ccm_geo_00042C_0x700de98;
extern Ambient_t Light_ccm_geo_00042C_0x700deb0;
extern Gfx DL_ccm_geo_00042C_0x700e708[];
extern Gfx DL_ccm_geo_00042C_0x700e4a8[];
extern Gfx DL_ccm_geo_00042C_0x700e530[];
extern Gfx DL_ccm_geo_00042C_0x700e668[];
extern Gfx DL_ccm_geo_00042C_0x700e6c0[];
extern u8 ccm_geo_00042C__texture_09000000[];
extern u8 ccm_geo_00042C__texture_09007000[];
extern Gfx DL_ccm_geo_00042C_0x700e970[];
extern Gfx DL_ccm_geo_00042C_0x700e8d0[];
extern Gfx DL_ccm_geo_00042C_0x700e928[];
#endif