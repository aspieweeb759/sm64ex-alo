#ifndef ccm_10_model_HEADER_H
#define ccm_10_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_0004E4_0x700fdd0[];
extern Vtx VB_ccm_geo_0004E4_0x700fe10[];
extern Vtx VB_ccm_geo_0004E4_0x700fef0[];
extern Vtx VB_ccm_geo_0004E4_0x700ff70[];
extern Vtx VB_ccm_geo_0004E4_0x700ffb0[];
extern Vtx VB_ccm_geo_0004E4_0x7010070[];
extern Vtx VB_ccm_geo_0004E4_0x7010160[];
extern Vtx VB_ccm_geo_0004E4_0x70101a0[];
extern Vtx VB_ccm_geo_0004E4_0x7010280[];
extern Vtx VB_ccm_geo_0004E4_0x7010320[];
extern Vtx VB_ccm_geo_0004E4_0x70106d8[];
extern Vtx VB_ccm_geo_0004E4_0x7010758[];
extern Vtx VB_ccm_geo_0004E4_0x7010848[];
extern Vtx VB_ccm_geo_0004E4_0x7010a78[];
extern u8 ccm_geo_0004E4__texture_09003000[];
extern u8 ccm_geo_0004E4__texture_09006000[];
extern u8 ccm_geo_0004E4__texture_09002000[];
extern u8 ccm_geo_0004E4__texture_09002800[];
extern Light_t Light_ccm_geo_0004E4_0x700fd90;
extern Light_t Light_ccm_geo_0004E4_0x700fda8;
extern Light_t Light_ccm_geo_0004E4_0x700fdc0;
extern Ambient_t Light_ccm_geo_0004E4_0x700fd88;
extern Ambient_t Light_ccm_geo_0004E4_0x700fda0;
extern Ambient_t Light_ccm_geo_0004E4_0x700fdb8;
extern Gfx DL_ccm_geo_0004E4_0x7010660[];
extern Gfx DL_ccm_geo_0004E4_0x7010390[];
extern Gfx DL_ccm_geo_0004E4_0x7010480[];
extern Gfx DL_ccm_geo_0004E4_0x7010518[];
extern Gfx DL_ccm_geo_0004E4_0x7010610[];
extern u8 ccm_geo_0004E4__texture_09005800[];
extern u8 ccm_geo_0004E4__texture_09007000[];
extern Gfx DL_ccm_geo_0004E4_0x70109d0[];
extern Gfx DL_ccm_geo_0004E4_0x70108f8[];
extern Gfx DL_ccm_geo_0004E4_0x7010940[];
extern u8 ccm_geo_0004E4__texture_09000800[];
extern Light_t Light_ccm_geo_0004E4_0x7010a68;
extern Ambient_t Light_ccm_geo_0004E4_0x7010a60;
extern Gfx DL_ccm_geo_0004E4_0x7010b50[];
extern Gfx DL_ccm_geo_0004E4_0x7010af8[];
#endif