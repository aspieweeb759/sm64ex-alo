ALIGNED8 u8 mushroom_1up_geo__texture_03029628[] = {
#include "actors/mushroom_1up/mushroom_1up_geo_0x3029628_custom.rgba16.inc.c"
};
