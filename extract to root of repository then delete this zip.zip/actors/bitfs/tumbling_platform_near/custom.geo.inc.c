const GeoLayout bitfs_geo_0006D8[]= {
GEO_CULLING_RADIUS(400),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bitfs_geo_0006D8_0x700ff90),
GEO_CLOSE_NODE(),
GEO_END(),
};
