#ifndef bitfs_elevator_model_HEADER_H
#define bitfs_elevator_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000678_0x700f238[];
extern Vtx VB_bitfs_geo_000678_0x700f278[];
extern Vtx VB_bitfs_geo_000678_0x700f378[];
extern Vtx VB_bitfs_geo_000678_0x700f3b8[];
extern u8 bitfs_geo_000678__texture_09001800[];
extern u8 bitfs_geo_000678__texture_09001000[];
extern u8 bitfs_geo_000678__texture_09007000[];
extern u8 bitfs_geo_000678__texture_07001000[];
extern Gfx DL_bitfs_geo_000678_0x700f508[];
extern Gfx DL_bitfs_geo_000678_0x700f3f8[];
extern Gfx DL_bitfs_geo_000678_0x700f430[];
extern Gfx DL_bitfs_geo_000678_0x700f498[];
extern Gfx DL_bitfs_geo_000678_0x700f4d0[];
#endif