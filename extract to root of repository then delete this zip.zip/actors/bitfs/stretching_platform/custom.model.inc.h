#ifndef bitfs_stretching_platform_model_HEADER_H
#define bitfs_stretching_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000708_0x70101d8[];
extern Vtx VB_bitfs_geo_000708_0x70103b0[];
extern Vtx VB_bitfs_geo_000708_0x70104a0[];
extern Vtx VB_bitfs_geo_000708_0x7010590[];
extern Vtx VB_bitfs_geo_000708_0x7010680[];
extern Vtx VB_bitfs_geo_000708_0x7010770[];
extern Vtx VB_bitfs_geo_000708_0x7010850[];
extern Vtx VB_bitfs_geo_000708_0x7010940[];
extern Vtx VB_bitfs_geo_000708_0x7010a40[];
extern Vtx VB_bitfs_geo_000708_0x7010b30[];
extern Vtx VB_bitfs_geo_000708_0x7010c30[];
extern Vtx VB_bitfs_geo_000708_0x7010d20[];
extern u8 bitfs_geo_000708__texture_09003800[];
extern Gfx DL_bitfs_geo_000708_0x7010340[];
extern Gfx DL_bitfs_geo_000708_0x70102d8[];
extern u8 bitfs_geo_000708__texture_09007000[];
extern Gfx DL_bitfs_geo_000708_0x7011138[];
extern Gfx DL_bitfs_geo_000708_0x7010e20[];
#endif