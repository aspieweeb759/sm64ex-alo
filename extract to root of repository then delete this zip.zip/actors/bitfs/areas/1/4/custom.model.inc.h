#ifndef bitfs_4_model_HEADER_H
#define bitfs_4_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0004E0_0x7003700[];
extern Vtx VB_bitfs_geo_0004E0_0x7003780[];
extern Vtx VB_bitfs_geo_0004E0_0x7003870[];
extern Vtx VB_bitfs_geo_0004E0_0x7003930[];
extern Vtx VB_bitfs_geo_0004E0_0x7003a30[];
extern u8 bitfs_geo_0004E0__texture_09001800[];
extern u8 bitfs_geo_0004E0__texture_09000800[];
extern u8 bitfs_geo_0004E0__texture_07001800[];
extern Gfx DL_bitfs_geo_0004E0_0x7003c60[];
extern Gfx DL_bitfs_geo_0004E0_0x7003ab0[];
extern Gfx DL_bitfs_geo_0004E0_0x7003af8[];
extern Gfx DL_bitfs_geo_0004E0_0x7003bd0[];
#endif