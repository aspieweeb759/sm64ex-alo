#ifndef bitfs_19_model_HEADER_H
#define bitfs_19_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000648_0x700ecf0[];
extern u8 bitfs_geo_000648__texture_09000800[];
extern Gfx DL_bitfs_geo_000648_0x700ed90[];
extern Gfx DL_bitfs_geo_000648_0x700ed50[];
#endif