const GeoLayout bitfs_geo_000648[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_bitfs_geo_000648_0x700ed90),
GEO_CLOSE_NODE(),
GEO_END(),
};
