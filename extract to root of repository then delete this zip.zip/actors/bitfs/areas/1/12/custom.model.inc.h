#ifndef bitfs_12_model_HEADER_H
#define bitfs_12_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0005A0_0x7009000[];
extern Vtx VB_bitfs_geo_0005A0_0x7009040[];
extern u8 bitfs_geo_0005A0__texture_07000000[];
extern u8 bitfs_geo_0005A0__texture_09003800[];
extern Gfx DL_bitfs_geo_0005A0_0x70091e0[];
extern Gfx DL_bitfs_geo_0005A0_0x7009140[];
extern Gfx DL_bitfs_geo_0005A0_0x7009178[];
#endif