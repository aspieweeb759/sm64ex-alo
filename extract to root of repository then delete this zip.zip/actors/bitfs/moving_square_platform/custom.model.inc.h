#ifndef bitfs_moving_square_platform_model_HEADER_H
#define bitfs_moving_square_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000728_0x70111a8[];
extern Vtx VB_bitfs_geo_000728_0x70111e8[];
extern u8 bitfs_geo_000728__texture_09007800[];
extern u8 bitfs_geo_000728__texture_09002000[];
extern Gfx DL_bitfs_geo_000728_0x7011318[];
extern Gfx DL_bitfs_geo_000728_0x7011298[];
extern Gfx DL_bitfs_geo_000728_0x70112d0[];
#endif