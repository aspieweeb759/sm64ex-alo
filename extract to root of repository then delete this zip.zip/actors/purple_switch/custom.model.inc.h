#ifndef purple_switch_purple_switch_model_HEADER_H
#define purple_switch_purple_switch_model_HEADER_H
#include "types.h"
extern Vtx VB_purple_switch_geo_0x800c528[];
extern Vtx VB_purple_switch_geo_0x800c628[];
extern u8 purple_switch_geo__texture_0800C0A8[];
extern u8 purple_switch_geo__texture_0800C128[];
extern Light_t Light_purple_switch_geo_0x800c098;
extern Ambient_t Light_purple_switch_geo_0x800c090;
extern Gfx DL_purple_switch_geo_0x800c718[];
extern Gfx DL_purple_switch_geo_0x800c668[];
extern Gfx DL_purple_switch_geo_0x800c6e0[];
#endif