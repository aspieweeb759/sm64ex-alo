#ifndef ddd_submarine_model_HEADER_H
#define ddd_submarine_model_HEADER_H
#include "types.h"
extern Vtx VB_ddd_geo_0004A0_0x7009300[];
extern Vtx VB_ddd_geo_0004A0_0x7009400[];
extern Vtx VB_ddd_geo_0004A0_0x7009490[];
extern Vtx VB_ddd_geo_0004A0_0x7009590[];
extern Vtx VB_ddd_geo_0004A0_0x70095e0[];
extern Vtx VB_ddd_geo_0004A0_0x7009660[];
extern Vtx VB_ddd_geo_0004A0_0x7009750[];
extern Vtx VB_ddd_geo_0004A0_0x7009800[];
extern Vtx VB_ddd_geo_0004A0_0x70098e0[];
extern Vtx VB_ddd_geo_0004A0_0x70099e0[];
extern Vtx VB_ddd_geo_0004A0_0x7009ad0[];
extern Vtx VB_ddd_geo_0004A0_0x7009bd0[];
extern Vtx VB_ddd_geo_0004A0_0x7009cd0[];
extern Vtx VB_ddd_geo_0004A0_0x7009dd0[];
extern Vtx VB_ddd_geo_0004A0_0x7009ed0[];
extern Vtx VB_ddd_geo_0004A0_0x7009fd0[];
extern Vtx VB_ddd_geo_0004A0_0x700a0d0[];
extern Vtx VB_ddd_geo_0004A0_0x700a1d0[];
extern Vtx VB_ddd_geo_0004A0_0x700a2d0[];
extern Vtx VB_ddd_geo_0004A0_0x700a3c0[];
extern Vtx VB_ddd_geo_0004A0_0x700a4c0[];
extern Vtx VB_ddd_geo_0004A0_0x700a580[];
extern Vtx VB_ddd_geo_0004A0_0x700af90[];
extern u8 ddd_geo_0004A0__texture_07001800[];
extern u8 ddd_geo_0004A0__texture_0900A000[];
extern Light_t Light_ddd_geo_0004A0_0x7009290;
extern Light_t Light_ddd_geo_0004A0_0x70092a8;
extern Light_t Light_ddd_geo_0004A0_0x70092c0;
extern Light_t Light_ddd_geo_0004A0_0x70092d8;
extern Light_t Light_ddd_geo_0004A0_0x70092f0;
extern Ambient_t Light_ddd_geo_0004A0_0x7009288;
extern Ambient_t Light_ddd_geo_0004A0_0x70092a0;
extern Ambient_t Light_ddd_geo_0004A0_0x70092b8;
extern Ambient_t Light_ddd_geo_0004A0_0x70092d0;
extern Ambient_t Light_ddd_geo_0004A0_0x70092e8;
extern Gfx DL_ddd_geo_0004A0_0x700af10[];
extern Gfx DL_ddd_geo_0004A0_0x700a600[];
extern Gfx DL_ddd_geo_0004A0_0x700aeb8[];
extern u8 ddd_geo_0004A0__texture_07000000[];
extern Light_t Light_ddd_geo_0004A0_0x700af80;
extern Ambient_t Light_ddd_geo_0004A0_0x700af78;
extern Gfx DL_ddd_geo_0004A0_0x700b068[];
extern Gfx DL_ddd_geo_0004A0_0x700b010[];
#endif