#include "custom.model.inc.h"
Vtx VB_klepto_geo_0x5003838[] = {
{{{ 14, -62, 52 }, 0, { 1058, -314 }, { 14, 192, 108, 255}}},
{{{ 65, -69, 0 }, 0, { 80, -454 }, { 86, 163, 0, 255}}},
{{{ 76, -43, 0 }, 0, { -36, 532 }, { 91, 169, 0, 255}}},
{{{ 26, -6, 56 }, 0, { 942, 1784 }, { 14, 6, 126, 255}}},
{{{ 14, -62, -51 }, 0, { 1058, -314 }, { 14, 192, 148, 255}}},
{{{ 26, -6, -55 }, 0, { 942, 1784 }, { 14, 6, 130, 255}}},
};

Vtx VB_klepto_geo_0x5003898[] = {
{{{ 134, -7, 32 }, 0, { 496, 1112 }, { 27, 89, 85, 255}}},
{{{ 134, -7, -31 }, 0, { 224, 1048 }, { 26, 89, 171, 255}}},
{{{ 0, 16, 0 }, 0, { 454, -308 }, { 245, 126, 0, 255}}},
{{{ 0, 16, 0 }, 0, { 480, -328 }, { 245, 126, 0, 255}}},
{{{ 134, -7, -31 }, 0, { 684, 1248 }, { 26, 89, 171, 255}}},
{{{ 26, -6, -55 }, 0, { 836, 324 }, { 14, 6, 130, 255}}},
{{{ 26, -6, 56 }, 0, { 836, 324 }, { 14, 6, 126, 255}}},
{{{ 134, -7, 32 }, 0, { 684, 1248 }, { 27, 89, 85, 255}}},
{{{ 183, 18, 0 }, 0, { -34, 1968 }, { 114, 53, 255, 255}}},
{{{ 134, -7, 32 }, 0, { 550, 1664 }, { 27, 89, 85, 255}}},
{{{ 158, -40, 0 }, 0, { -34, 1564 }, { 54, 142, 0, 255}}},
{{{ 26, -6, 56 }, 0, { 982, 280 }, { 14, 6, 126, 255}}},
{{{ 76, -43, 0 }, 0, { -34, 256 }, { 91, 169, 0, 255}}},
{{{ 26, -6, -55 }, 0, { 982, 280 }, { 14, 6, 130, 255}}},
{{{ 134, -7, -31 }, 0, { 550, 1664 }, { 26, 89, 171, 255}}},
};

Vtx VB_klepto_geo_0x5003988[] = {
{{{ 134, -7, -31 }, 0, { 558, 1256 }, { 26, 89, 171, 255}}},
{{{ 134, -7, 32 }, 0, { 318, 1032 }, { 27, 89, 85, 255}}},
{{{ 183, 18, 0 }, 0, { 326, 1572 }, { 114, 53, 255, 255}}},
};

Vtx VB_klepto_geo_0x50039b8[] = {
{{{ 14, -62, -51 }, 0, { 0, 0 }, { 14, 192, 148, 255}}},
{{{ 65, -69, 0 }, 0, { 0, 0 }, { 86, 163, 0, 255}}},
{{{ 21, -88, 0 }, 0, { 0, 0 }, { 248, 130, 0, 255}}},
{{{ 14, -62, 52 }, 0, { 0, 0 }, { 14, 192, 108, 255}}},
{{{ -42, -8, 32 }, 0, { 0, 0 }, { 168, 47, 77, 255}}},
{{{ -32, -61, 23 }, 0, { 0, 0 }, { 159, 184, 37, 255}}},
{{{ 26, -6, 56 }, 0, { 0, 0 }, { 14, 6, 126, 255}}},
{{{ -32, -61, -22 }, 0, { 0, 0 }, { 172, 174, 210, 255}}},
{{{ -42, -8, -31 }, 0, { 0, 0 }, { 153, 33, 191, 255}}},
{{{ 26, -6, -55 }, 0, { 0, 0 }, { 14, 6, 130, 255}}},
{{{ 0, 16, 0 }, 0, { 0, 0 }, { 245, 126, 0, 255}}},
};

Vtx VB_klepto_geo_0x5003c70[] = {
{{{ 65, -11, -11 }, 0, { 0, 0 }, { 13, 167, 167, 255}}},
{{{ 65, -11, 12 }, 0, { 0, 0 }, { 12, 166, 88, 255}}},
{{{ 6, -19, 0 }, 0, { 0, 0 }, { 213, 137, 255, 255}}},
{{{ 6, 1, -20 }, 0, { 0, 0 }, { 213, 0, 137, 255}}},
{{{ -10, 1, 0 }, 0, { 0, 0 }, { 130, 0, 255, 255}}},
{{{ 6, 1, 21 }, 0, { 0, 0 }, { 212, 0, 118, 255}}},
{{{ 65, 13, -11 }, 0, { 0, 0 }, { 13, 89, 167, 255}}},
{{{ 6, 21, 0 }, 0, { 0, 0 }, { 213, 119, 255, 255}}},
{{{ 65, 13, 12 }, 0, { 0, 0 }, { 12, 90, 88, 255}}},
};

Vtx VB_klepto_geo_0x5003dc8[] = {
{{{ -10, 0, 0 }, 0, { 478, 974 }, { 130, 242, 0, 255}}},
{{{ 10, 24, -20 }, 0, { 186, 654 }, { 193, 75, 177, 255}}},
{{{ 17, -23, -20 }, 0, { 186, 650 }, { 194, 181, 176, 255}}},
{{{ 44, -40, 0 }, 0, { 480, 314 }, { 41, 137, 0, 255}}},
{{{ 17, -23, 21 }, 0, { 772, 650 }, { 194, 180, 79, 255}}},
{{{ 51, 7, -33 }, 0, { -10, 134 }, { 50, 0, 140, 255}}},
{{{ 51, 35, 0 }, 0, { 478, 84 }, { 57, 113, 0, 255}}},
{{{ 72, -9, 0 }, 0, { 480, -110 }, { 126, 246, 0, 255}}},
{{{ 51, 7, 34 }, 0, { 968, 134 }, { 51, 0, 116, 255}}},
{{{ 10, 24, 21 }, 0, { 772, 654 }, { 192, 75, 78, 255}}},
};

Vtx VB_klepto_geo_0x5003f98[] = {
{{{ 54, 19, -37 }, 0, { 0, 0 }, { 56, 19, 145, 255}}},
{{{ 86, 16, 0 }, 0, { 0, 0 }, { 120, 39, 252, 255}}},
{{{ 76, -14, 0 }, 0, { 0, 0 }, { 103, 183, 253, 255}}},
{{{ 54, 19, 43 }, 0, { 0, 0 }, { 56, 18, 112, 255}}},
{{{ 42, -26, 26 }, 0, { 0, 0 }, { 5, 158, 80, 255}}},
{{{ 42, -26, -25 }, 0, { 0, 0 }, { 10, 162, 173, 255}}},
{{{ 19, 17, -33 }, 0, { 0, 0 }, { 220, 26, 138, 255}}},
{{{ -34, -10, 0 }, 0, { 0, 0 }, { 139, 207, 0, 255}}},
{{{ 47, 50, 0 }, 0, { 0, 0 }, { 4, 126, 254, 255}}},
{{{ 19, 17, 34 }, 0, { 0, 0 }, { 214, 25, 116, 255}}},
{{{ -5, 25, 20 }, 0, { 0, 0 }, { 185, 87, 58, 255}}},
{{{ -5, 25, -19 }, 0, { 0, 0 }, { 185, 87, 198, 255}}},
};

Vtx VB_klepto_geo_0x5004160[] = {
{{{ 5, -3, 0 }, 0, { 0, 992 }, { 55, 142, 0, 255}}},
{{{ -81, -45, 0 }, 0, { 0, 0 }, { 55, 142, 0, 255}}},
{{{ -77, 2, -47 }, 0, { 1700, 224 }, { 42, 170, 174, 255}}},
{{{ -77, 2, 48 }, 0, { 1700, 224 }, { 42, 169, 81, 255}}},
};

Vtx VB_klepto_geo_0x5004270[] = {
{{{ 9, 27, 3 }, 0, { 0, 0 }, { 213, 80, 87, 255}}},
{{{ 0, 0, 0 }, 0, { 0, 0 }, { 134, 224, 253, 255}}},
{{{ 14, 9, 8 }, 0, { 0, 0 }, { 1, 177, 98, 255}}},
{{{ 9, 27, -3 }, 0, { 0, 0 }, { 214, 77, 165, 255}}},
{{{ 69, 0, 0 }, 0, { 0, 0 }, { 98, 80, 253, 255}}},
{{{ 14, 9, -7 }, 0, { 0, 0 }, { 3, 176, 159, 255}}},
};

Vtx VB_klepto_geo_0x5004378[] = {
{{{ 9, 27, 3 }, 0, { 0, 0 }, { 213, 80, 87, 255}}},
{{{ 0, 0, 0 }, 0, { 0, 0 }, { 134, 224, 253, 255}}},
{{{ 14, 9, 8 }, 0, { 0, 0 }, { 1, 177, 98, 255}}},
{{{ 9, 27, -3 }, 0, { 0, 0 }, { 214, 77, 165, 255}}},
{{{ 69, 0, 0 }, 0, { 0, 0 }, { 98, 80, 253, 255}}},
{{{ 14, 9, -7 }, 0, { 0, 0 }, { 3, 176, 159, 255}}},
};

Vtx VB_klepto_geo_0x5004498[] = {
{{{ 38, 7, 24 }, 0, { 0, 0 }, { 16, 125, 0, 255}}},
{{{ 24, -12, 28 }, 0, { 0, 0 }, { 180, 36, 94, 255}}},
{{{ 43, -19, 30 }, 0, { 0, 0 }, { 80, 174, 53, 255}}},
{{{ 48, 7, 0 }, 0, { 0, 0 }, { 9, 126, 254, 255}}},
{{{ 34, -14, -7 }, 0, { 0, 0 }, { 246, 29, 133, 255}}},
{{{ 34, -14, 9 }, 0, { 0, 0 }, { 240, 28, 122, 255}}},
{{{ 51, -21, 1 }, 0, { 0, 0 }, { 85, 162, 252, 255}}},
{{{ 24, -12, -25 }, 0, { 0, 0 }, { 180, 36, 162, 255}}},
{{{ 38, 7, -23 }, 0, { 0, 0 }, { 8, 126, 10, 255}}},
{{{ 44, -19, -28 }, 0, { 0, 0 }, { 73, 170, 199, 255}}},
{{{ 33, -14, -11 }, 0, { 0, 0 }, { 52, 17, 114, 255}}},
{{{ 33, -13, 13 }, 0, { 0, 0 }, { 53, 17, 143, 255}}},
};

Vtx VB_klepto_geo_0x5004558[] = {
{{{ 7, -1, 6 }, 0, { 0, 0 }, { 172, 74, 198, 255}}},
{{{ 33, -13, 13 }, 0, { 0, 0 }, { 53, 17, 143, 255}}},
{{{ 20, -24, 16 }, 0, { 0, 0 }, { 221, 135, 243, 255}}},
{{{ 34, -14, 9 }, 0, { 0, 0 }, { 240, 28, 122, 255}}},
{{{ 24, -25, 0 }, 0, { 0, 0 }, { 217, 136, 250, 255}}},
{{{ 51, -21, 1 }, 0, { 0, 0 }, { 85, 162, 252, 255}}},
{{{ 34, -14, -7 }, 0, { 0, 0 }, { 246, 29, 133, 255}}},
{{{ 8, -2, 0 }, 0, { 0, 0 }, { 166, 87, 244, 255}}},
{{{ 33, -14, -11 }, 0, { 0, 0 }, { 52, 17, 114, 255}}},
{{{ 20, -24, -14 }, 0, { 0, 0 }, { 218, 136, 9, 255}}},
{{{ 44, -19, -28 }, 0, { 0, 0 }, { 73, 170, 199, 255}}},
{{{ 24, -12, -25 }, 0, { 0, 0 }, { 180, 36, 162, 255}}},
{{{ 7, -1, -4 }, 0, { 0, 0 }, { 175, 75, 61, 255}}},
{{{ 24, -12, 28 }, 0, { 0, 0 }, { 180, 36, 94, 255}}},
{{{ 43, -19, 30 }, 0, { 0, 0 }, { 80, 174, 53, 255}}},
};

Vtx VB_klepto_geo_0x5004648[] = {
{{{ -22, 7, 0 }, 0, { 0, 0 }, { 154, 74, 244, 255}}},
{{{ 2, -10, 0 }, 0, { 0, 0 }, { 232, 132, 254, 255}}},
{{{ 15, -3, 17 }, 0, { 0, 0 }, { 75, 13, 101, 255}}},
{{{ 15, -3, -15 }, 0, { 0, 0 }, { 72, 14, 153, 255}}},
{{{ 6, 5, 0 }, 0, { 0, 0 }, { 37, 121, 254, 255}}},
};

Vtx VB_klepto_geo_0x5004828[] = {
{{{ 38, 7, 24 }, 0, { 0, 0 }, { 16, 125, 0, 255}}},
{{{ 24, -12, 28 }, 0, { 0, 0 }, { 180, 36, 94, 255}}},
{{{ 43, -19, 30 }, 0, { 0, 0 }, { 80, 174, 53, 255}}},
{{{ 48, 7, 0 }, 0, { 0, 0 }, { 9, 126, 254, 255}}},
{{{ 34, -14, -7 }, 0, { 0, 0 }, { 246, 29, 133, 255}}},
{{{ 34, -14, 9 }, 0, { 0, 0 }, { 240, 28, 122, 255}}},
{{{ 51, -21, 1 }, 0, { 0, 0 }, { 85, 162, 252, 255}}},
{{{ 24, -12, -25 }, 0, { 0, 0 }, { 180, 36, 162, 255}}},
{{{ 38, 7, -23 }, 0, { 0, 0 }, { 8, 126, 10, 255}}},
{{{ 44, -19, -28 }, 0, { 0, 0 }, { 73, 170, 199, 255}}},
{{{ 33, -14, -11 }, 0, { 0, 0 }, { 52, 17, 114, 255}}},
{{{ 33, -13, 13 }, 0, { 0, 0 }, { 53, 17, 143, 255}}},
};

Vtx VB_klepto_geo_0x50048e8[] = {
{{{ 7, -1, 6 }, 0, { 0, 0 }, { 172, 74, 198, 255}}},
{{{ 33, -13, 13 }, 0, { 0, 0 }, { 53, 17, 143, 255}}},
{{{ 20, -24, 16 }, 0, { 0, 0 }, { 221, 135, 243, 255}}},
{{{ 34, -14, 9 }, 0, { 0, 0 }, { 240, 28, 122, 255}}},
{{{ 24, -25, 0 }, 0, { 0, 0 }, { 217, 136, 250, 255}}},
{{{ 51, -21, 1 }, 0, { 0, 0 }, { 85, 162, 252, 255}}},
{{{ 34, -14, -7 }, 0, { 0, 0 }, { 246, 29, 133, 255}}},
{{{ 8, -2, 0 }, 0, { 0, 0 }, { 166, 87, 244, 255}}},
{{{ 33, -14, -11 }, 0, { 0, 0 }, { 52, 17, 114, 255}}},
{{{ 20, -24, -14 }, 0, { 0, 0 }, { 218, 136, 9, 255}}},
{{{ 44, -19, -28 }, 0, { 0, 0 }, { 73, 170, 199, 255}}},
{{{ 24, -12, -25 }, 0, { 0, 0 }, { 180, 36, 162, 255}}},
{{{ 7, -1, -4 }, 0, { 0, 0 }, { 175, 75, 61, 255}}},
{{{ 24, -12, 28 }, 0, { 0, 0 }, { 180, 36, 94, 255}}},
{{{ 43, -19, 30 }, 0, { 0, 0 }, { 80, 174, 53, 255}}},
};

Vtx VB_klepto_geo_0x50049d8[] = {
{{{ -22, 7, 0 }, 0, { 0, 0 }, { 154, 74, 244, 255}}},
{{{ 2, -10, 0 }, 0, { 0, 0 }, { 232, 132, 254, 255}}},
{{{ 15, -3, 17 }, 0, { 0, 0 }, { 75, 13, 101, 255}}},
{{{ 15, -3, -15 }, 0, { 0, 0 }, { 72, 14, 153, 255}}},
{{{ 6, 5, 0 }, 0, { 0, 0 }, { 37, 121, 254, 255}}},
};

Vtx VB_klepto_geo_0x5004ba0[] = {
{{{ -2, -13, 0 }, 0, { 1992, 528 }, { 0, 0, 129, 255}}},
{{{ -2, 14, 0 }, 0, { 1992, 272 }, { 0, 0, 129, 255}}},
{{{ 34, 24, 0 }, 0, { 1640, 176 }, { 0, 0, 129, 255}}},
{{{ 34, -33, 0 }, 0, { 1640, 722 }, { 0, 0, 129, 255}}},
};

Vtx VB_klepto_geo_0x5004cb0[] = {
{{{ 34, -33, 0 }, 0, { 1640, 722 }, { 0, 0, 127, 255}}},
{{{ 34, 24, 0 }, 0, { 1640, 176 }, { 0, 0, 127, 255}}},
{{{ -2, -13, 0 }, 0, { 1992, 528 }, { 0, 0, 127, 255}}},
{{{ -2, 14, 0 }, 0, { 1992, 272 }, { 0, 0, 127, 255}}},
};

Vtx VB_klepto_geo_0x5004dc0[] = {
{{{ 0, -33, 0 }, 0, { 1640, 716 }, { 0, 0, 129, 255}}},
{{{ 0, 24, 0 }, 0, { 1640, 172 }, { 0, 0, 129, 255}}},
{{{ 79, 34, 0 }, 0, { 904, 76 }, { 0, 0, 129, 255}}},
{{{ 79, -58, 0 }, 0, { 904, 940 }, { 0, 0, 129, 255}}},
};

Vtx VB_klepto_geo_0x5004ed0[] = {
{{{ 79, -58, 0 }, 0, { 904, 940 }, { 0, 0, 127, 255}}},
{{{ 79, 34, 0 }, 0, { 904, 76 }, { 0, 0, 127, 255}}},
{{{ 0, -33, 0 }, 0, { 1640, 716 }, { 0, 0, 127, 255}}},
{{{ 0, 24, 0 }, 0, { 1640, 172 }, { 0, 0, 127, 255}}},
};

Vtx VB_klepto_geo_0x5004fe0[] = {
{{{ 0, -58, 0 }, 0, { 904, 942 }, { 0, 0, 129, 255}}},
{{{ 0, 34, 0 }, 0, { 904, 78 }, { 0, 0, 129, 255}}},
{{{ 108, 52, 0 }, 0, { -96, -86 }, { 0, 0, 129, 255}}},
{{{ 65, -68, 0 }, 0, { 296, 1036 }, { 0, 0, 129, 255}}},
};

Vtx VB_klepto_geo_0x50050f0[] = {
{{{ 65, -68, 0 }, 0, { 296, 1036 }, { 0, 0, 127, 255}}},
{{{ 108, 52, 0 }, 0, { -96, -86 }, { 0, 0, 127, 255}}},
{{{ 0, -58, 0 }, 0, { 904, 942 }, { 0, 0, 127, 255}}},
{{{ 0, 34, 0 }, 0, { 904, 78 }, { 0, 0, 127, 255}}},
};

Light_t Light_klepto_geo_0x5004150 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004148 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x50041e8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_klepto_geo_0x50041a0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x50041a0[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05003008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_klepto_geo_0x5004150.col, 1),
gsSPLight(&Light_klepto_geo_0x5004148.col, 2),
gsSPVertex(VB_klepto_geo_0x5004160, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 1, 0, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5003db8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5003db0 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5003f20[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_klepto_geo_0x5003e68),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5003e68[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05000008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_klepto_geo_0x5003db8.col, 1),
gsSPLight(&Light_klepto_geo_0x5003db0.col, 2),
gsSPVertex(VB_klepto_geo_0x5003dc8, 10, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 2, 0),
gsSP2Triangles(5, 2, 1, 0,2, 5, 3, 0),
gsSP2Triangles(4, 0, 2, 0,6, 7, 5, 0),
gsSP2Triangles(1, 6, 5, 0,7, 3, 5, 0),
gsSP2Triangles(4, 3, 8, 0,3, 7, 8, 0),
gsSP2Triangles(1, 0, 9, 0,6, 1, 9, 0),
gsSP2Triangles(9, 8, 6, 0,7, 6, 8, 0),
gsSP2Triangles(8, 9, 4, 0,0, 4, 9, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5003c60 = {
{ 255, 117, 33}, 0, { 255, 117, 33}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5003c58 = {
{63, 29, 8}, 0, {63, 29, 8}, 0
};

Gfx DL_klepto_geo_0x5003d80[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x5003d00),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5003d00[] = {
gsSPLight(&Light_klepto_geo_0x5003c60.col, 1),
gsSPLight(&Light_klepto_geo_0x5003c58.col, 2),
gsSPVertex(VB_klepto_geo_0x5003c70, 9, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 0, 0),
gsSP2Triangles(4, 2, 5, 0,2, 4, 3, 0),
gsSP2Triangles(5, 2, 1, 0,6, 0, 3, 0),
gsSP2Triangles(3, 7, 6, 0,4, 7, 3, 0),
gsSP2Triangles(7, 4, 5, 0,1, 8, 5, 0),
gsSP2Triangles(7, 5, 8, 0,8, 6, 7, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5003810 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Light_t Light_klepto_geo_0x5003828 = {
{ 255, 117, 33}, 0, { 255, 117, 33}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5003808 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Ambient_t Light_klepto_geo_0x5003820 = {
{63, 29, 8}, 0, {63, 29, 8}, 0
};

Gfx DL_klepto_geo_0x5003bd0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_klepto_geo_0x5003a68),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_klepto_geo_0x5003ac0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x5003b40),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5003a68[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05000808),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_klepto_geo_0x5003810.col, 1),
gsSPLight(&Light_klepto_geo_0x5003808.col, 2),
gsSPVertex(VB_klepto_geo_0x5003838, 6, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 0, 0),
gsSP2Triangles(2, 1, 4, 0,4, 5, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5003ac0[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05001008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_klepto_geo_0x5003898, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 3, 0,8, 9, 10, 0),
gsSP2Triangles(10, 9, 11, 0,11, 12, 10, 0),
gsSP2Triangles(13, 14, 10, 0,10, 12, 13, 0),
gsSP1Triangle(10, 14, 8, 0),
gsSPVertex(VB_klepto_geo_0x5003988, 3, 0),
gsSP1Triangle(0, 1, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5003b40[] = {
gsSPLight(&Light_klepto_geo_0x5003828.col, 1),
gsSPLight(&Light_klepto_geo_0x5003820.col, 2),
gsSPVertex(VB_klepto_geo_0x50039b8, 11, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSP2Triangles(4, 5, 3, 0,3, 6, 4, 0),
gsSP2Triangles(3, 5, 2, 0,2, 5, 7, 0),
gsSP2Triangles(7, 0, 2, 0,0, 7, 8, 0),
gsSP2Triangles(8, 9, 0, 0,8, 7, 5, 0),
gsSP2Triangles(10, 8, 4, 0,4, 8, 5, 0),
gsSP2Triangles(10, 9, 8, 0,10, 4, 6, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004260 = {
{ 255, 117, 33}, 0, { 255, 117, 33}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004258 = {
{63, 29, 8}, 0, {63, 29, 8}, 0
};

Gfx DL_klepto_geo_0x5004330[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x50042d0),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x50042d0[] = {
gsSPLight(&Light_klepto_geo_0x5004260.col, 1),
gsSPLight(&Light_klepto_geo_0x5004258.col, 2),
gsSPVertex(VB_klepto_geo_0x5004270, 6, 0),
gsSP2Triangles(0, 1, 2, 0,1, 0, 3, 0),
gsSP2Triangles(4, 0, 2, 0,0, 4, 3, 0),
gsSP2Triangles(5, 1, 3, 0,1, 5, 2, 0),
gsSP2Triangles(5, 4, 2, 0,4, 5, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004470 = {
{ 8, 0, 0}, 0, { 8, 0, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_klepto_geo_0x5004488 = {
{ 255, 117, 33}, 0, { 255, 117, 33}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004468 = {
{2, 0, 0}, 0, {2, 0, 0}, 0
};

Ambient_t Light_klepto_geo_0x5004480 = {
{63, 29, 8}, 0, {63, 29, 8}, 0
};

Gfx DL_klepto_geo_0x50047c8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x5004698),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004698[] = {
gsSPLight(&Light_klepto_geo_0x5004470.col, 1),
gsSPLight(&Light_klepto_geo_0x5004468.col, 2),
gsSPVertex(VB_klepto_geo_0x5004498, 12, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 3, 6, 0,3, 5, 6, 0),
gsSP2Triangles(7, 8, 9, 0,8, 7, 10, 0),
gsSP2Triangles(8, 10, 9, 0,0, 11, 1, 0),
gsSP1Triangle(11, 0, 2, 0),
gsSPLight(&Light_klepto_geo_0x5004488.col, 1),
gsSPLight(&Light_klepto_geo_0x5004480.col, 2),
gsSPVertex(VB_klepto_geo_0x5004558, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 3, 0,7, 4, 3, 0),
gsSP2Triangles(5, 4, 6, 0,7, 6, 4, 0),
gsSP2Triangles(8, 9, 10, 0,11, 12, 8, 0),
gsSP2Triangles(12, 9, 8, 0,12, 11, 9, 0),
gsSP2Triangles(10, 9, 11, 0,0, 2, 13, 0),
gsSP2Triangles(1, 0, 13, 0,13, 2, 14, 0),
gsSP1Triangle(14, 2, 1, 0),
gsSPVertex(VB_klepto_geo_0x5004648, 5, 0),
gsSP2Triangles(0, 1, 2, 0,1, 0, 3, 0),
gsSP2Triangles(3, 2, 1, 0,4, 2, 3, 0),
gsSP2Triangles(2, 4, 0, 0,3, 0, 4, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004368 = {
{ 255, 117, 33}, 0, { 255, 117, 33}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004360 = {
{63, 29, 8}, 0, {63, 29, 8}, 0
};

Gfx DL_klepto_geo_0x5004438[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x50043d8),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x50043d8[] = {
gsSPLight(&Light_klepto_geo_0x5004368.col, 1),
gsSPLight(&Light_klepto_geo_0x5004360.col, 2),
gsSPVertex(VB_klepto_geo_0x5004378, 6, 0),
gsSP2Triangles(0, 1, 2, 0,1, 0, 3, 0),
gsSP2Triangles(4, 0, 2, 0,0, 4, 3, 0),
gsSP2Triangles(5, 1, 3, 0,1, 5, 2, 0),
gsSP2Triangles(5, 4, 2, 0,4, 5, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004800 = {
{ 8, 0, 0}, 0, { 8, 0, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_klepto_geo_0x5004818 = {
{ 255, 117, 33}, 0, { 255, 117, 33}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x50047f8 = {
{2, 0, 0}, 0, {2, 0, 0}, 0
};

Ambient_t Light_klepto_geo_0x5004810 = {
{63, 29, 8}, 0, {63, 29, 8}, 0
};

Gfx DL_klepto_geo_0x5004b58[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x5004a28),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004a28[] = {
gsSPLight(&Light_klepto_geo_0x5004800.col, 1),
gsSPLight(&Light_klepto_geo_0x50047f8.col, 2),
gsSPVertex(VB_klepto_geo_0x5004828, 12, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(4, 3, 6, 0,3, 5, 6, 0),
gsSP2Triangles(7, 8, 9, 0,8, 7, 10, 0),
gsSP2Triangles(8, 10, 9, 0,0, 11, 1, 0),
gsSP1Triangle(11, 0, 2, 0),
gsSPLight(&Light_klepto_geo_0x5004818.col, 1),
gsSPLight(&Light_klepto_geo_0x5004810.col, 2),
gsSPVertex(VB_klepto_geo_0x50048e8, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 3, 0,7, 4, 3, 0),
gsSP2Triangles(5, 4, 6, 0,7, 6, 4, 0),
gsSP2Triangles(8, 9, 10, 0,11, 12, 8, 0),
gsSP2Triangles(12, 9, 8, 0,12, 11, 9, 0),
gsSP2Triangles(10, 9, 11, 0,0, 2, 13, 0),
gsSP2Triangles(1, 0, 13, 0,13, 2, 14, 0),
gsSP1Triangle(14, 2, 1, 0),
gsSPVertex(VB_klepto_geo_0x50049d8, 5, 0),
gsSP2Triangles(0, 1, 2, 0,1, 0, 3, 0),
gsSP2Triangles(3, 2, 1, 0,4, 2, 3, 0),
gsSP2Triangles(2, 4, 0, 0,3, 0, 4, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004ca0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004c98 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5004d38[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_klepto_geo_0x5004cf0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004cf0[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05002008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_klepto_geo_0x5004ca0.col, 1),
gsSPLight(&Light_klepto_geo_0x5004c98.col, 2),
gsSPVertex(VB_klepto_geo_0x5004cb0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004ec0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004eb8 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5004f58[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_klepto_geo_0x5004f10),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004f10[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05002008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_klepto_geo_0x5004ec0.col, 1),
gsSPLight(&Light_klepto_geo_0x5004eb8.col, 2),
gsSPVertex(VB_klepto_geo_0x5004ed0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x50050e0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x50050d8 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5005178[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_klepto_geo_0x5005130),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5005130[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05002008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_klepto_geo_0x50050e0.col, 1),
gsSPLight(&Light_klepto_geo_0x50050d8.col, 2),
gsSPVertex(VB_klepto_geo_0x50050f0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004b90 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004b88 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5004c28[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_klepto_geo_0x5004be0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004be0[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05002008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_klepto_geo_0x5004b90.col, 1),
gsSPLight(&Light_klepto_geo_0x5004b88.col, 2),
gsSPVertex(VB_klepto_geo_0x5004ba0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004db0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004da8 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5004e48[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_klepto_geo_0x5004e00),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004e00[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05002008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_klepto_geo_0x5004db0.col, 1),
gsSPLight(&Light_klepto_geo_0x5004da8.col, 2),
gsSPVertex(VB_klepto_geo_0x5004dc0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5004fd0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5004fc8 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_klepto_geo_0x5005068[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_klepto_geo_0x5005020),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5005020[] = {
gsDPSetTextureImage(0, 2, 1, klepto_geo__texture_05002008),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_klepto_geo_0x5004fd0.col, 1),
gsSPLight(&Light_klepto_geo_0x5004fc8.col, 2),
gsSPVertex(VB_klepto_geo_0x5004fe0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_klepto_geo_0x5003f88 = {
{ 30, 5, 4}, 0, { 30, 5, 4}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_klepto_geo_0x5003f80 = {
{7, 1, 1}, 0, {7, 1, 1}, 0
};

Gfx DL_klepto_geo_0x5004118[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_klepto_geo_0x5004058),
gsSPEndDisplayList(),
};

Gfx DL_klepto_geo_0x5004058[] = {
gsSPLight(&Light_klepto_geo_0x5003f88.col, 1),
gsSPLight(&Light_klepto_geo_0x5003f80.col, 2),
gsSPVertex(VB_klepto_geo_0x5003f98, 12, 0),
gsSP2Triangles(0, 1, 2, 0,2, 1, 3, 0),
gsSP2Triangles(2, 4, 5, 0,2, 5, 0, 0),
gsSP2Triangles(3, 4, 2, 0,6, 5, 7, 0),
gsSP2Triangles(4, 7, 5, 0,0, 5, 6, 0),
gsSP2Triangles(8, 1, 0, 0,8, 0, 6, 0),
gsSP2Triangles(7, 4, 9, 0,3, 9, 4, 0),
gsSP2Triangles(3, 8, 9, 0,9, 8, 10, 0),
gsSP2Triangles(9, 10, 7, 0,8, 11, 10, 0),
gsSP2Triangles(6, 11, 8, 0,3, 1, 8, 0),
gsSP2Triangles(10, 11, 7, 0,7, 11, 6, 0),
gsSPEndDisplayList(),
};

