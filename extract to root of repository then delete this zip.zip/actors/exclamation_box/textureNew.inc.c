ALIGNED8 u8 exclamation_box_geo__texture_08015E28[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8015e28_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08016628[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8016628_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08014628[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8014628_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08014E28[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8014e28_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08012E28[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8012e28_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08013628[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8013628_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08017628[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8017628_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_geo__texture_08017E28[] = {
#include "actors/exclamation_box/exclamation_box_geo_0x8017e28_custom.rgba16.inc.c"
};
