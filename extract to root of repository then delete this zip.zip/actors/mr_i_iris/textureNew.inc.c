ALIGNED8 u8 mr_i_iris_geo__texture_06002170[] = {
#include "actors/mr_i_iris/mr_i_iris_geo_0x6002170_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_i_iris_geo__texture_06002970[] = {
#include "actors/mr_i_iris/mr_i_iris_geo_0x6002970_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_i_iris_geo__texture_06003170[] = {
#include "actors/mr_i_iris/mr_i_iris_geo_0x6003170_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_i_iris_geo__texture_06003970[] = {
#include "actors/mr_i_iris/mr_i_iris_geo_0x6003970_custom.rgba16.inc.c"
};
