ALIGNED8 u8 metal_box_geo__texture_08023998[] = {
#include "actors/metal_box/metal_box_geo_0x8023998_custom.rgba16.inc.c"
};
