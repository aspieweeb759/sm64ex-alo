ALIGNED8 u8 mips_geo__texture_0600FC70[] = {
#include "actors/mips/mips_geo_0x600fc70_custom.rgba16.inc.c"
};
