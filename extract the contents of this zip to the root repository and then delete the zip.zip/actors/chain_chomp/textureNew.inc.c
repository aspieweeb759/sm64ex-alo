ALIGNED8 u8 chain_chomp_geo__texture_06021BD0[] = {
#include "actors/chain_chomp/chain_chomp_geo_0x6021bd0_custom.rgba16.inc.c"
};
ALIGNED8 u8 chain_chomp_geo__texture_060223D0[] = {
#include "actors/chain_chomp/chain_chomp_geo_0x60223d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 chain_chomp_geo__texture_06022BD0[] = {
#include "actors/chain_chomp/chain_chomp_geo_0x6022bd0_custom.rgba16.inc.c"
};
ALIGNED8 u8 chain_chomp_geo__texture_060213D0[] = {
#include "actors/chain_chomp/chain_chomp_geo_0x60213d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 chain_chomp_geo__texture_060233D0[] = {
#include "actors/chain_chomp/chain_chomp_geo_0x60233d0_custom.rgba16.inc.c"
};
