#ifndef boo_castle_boo_castle_model_HEADER_H
#define boo_castle_boo_castle_model_HEADER_H
#include "types.h"
extern Vtx VB_boo_castle_geo_0x6016f60[];
extern Vtx VB_boo_castle_geo_0x6017020[];
extern Vtx VB_boo_castle_geo_0x60170e0[];
extern Vtx VB_boo_castle_geo_0x60171d0[];
extern Vtx VB_boo_castle_geo_0x60172c0[];
extern Vtx VB_boo_castle_geo_0x60173b0[];
extern Vtx VB_boo_castle_geo_0x60174a0[];
extern Vtx VB_boo_castle_geo_0x6017590[];
extern Vtx VB_boo_castle_geo_0x6017680[];
extern Vtx VB_boo_castle_geo_0x6017770[];
extern Vtx VB_boo_castle_geo_0x6017860[];
extern Vtx VB_boo_castle_geo_0x6017950[];
extern Vtx VB_boo_castle_geo_0x6017a40[];
extern u8 boo_castle_geo__texture_06016760[];
extern u8 boo_castle_geo__texture_06015760[];
extern Light_t Light_boo_castle_geo_0x6015750;
extern Ambient_t Light_boo_castle_geo_0x6015748;
extern Gfx DL_boo_castle_geo_0x6017dd0[];
extern Gfx DL_boo_castle_geo_0x6017b00[];
extern Gfx DL_boo_castle_geo_0x6017b68[];
extern Gfx DL_boo_castle_geo_0x6017bc0[];
#endif