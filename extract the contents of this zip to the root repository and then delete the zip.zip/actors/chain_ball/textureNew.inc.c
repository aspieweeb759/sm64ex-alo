ALIGNED8 u8 metallic_ball_geo__texture_06020AE8[] = {
#include "actors/chain_ball/metallic_ball_geo_0x6020ae8_custom.rgba16.inc.c"
};
