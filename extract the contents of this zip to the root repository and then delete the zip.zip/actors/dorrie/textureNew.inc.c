ALIGNED8 u8 dorrie_geo__texture_06009DA0[] = {
#include "actors/dorrie/dorrie_geo_0x6009da0_custom.rgba16.inc.c"
};
ALIGNED8 u8 dorrie_geo__texture_0600ADA0[] = {
#include "actors/dorrie/dorrie_geo_0x600ada0_custom.rgba16.inc.c"
};
ALIGNED8 u8 dorrie_geo__texture_06009BA0[] = {
#include "actors/dorrie/dorrie_geo_0x6009ba0_custom.rgba16.inc.c"
};
