#ifndef bits_5_model_HEADER_H
#define bits_5_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000478_0x7005e58[];
extern Vtx VB_bits_geo_000478_0x7005f58[];
extern Vtx VB_bits_geo_000478_0x7006058[];
extern Vtx VB_bits_geo_000478_0x7006158[];
extern Vtx VB_bits_geo_000478_0x7006248[];
extern Vtx VB_bits_geo_000478_0x7006328[];
extern Vtx VB_bits_geo_000478_0x7006418[];
extern Vtx VB_bits_geo_000478_0x70064f8[];
extern Vtx VB_bits_geo_000478_0x70065d8[];
extern Vtx VB_bits_geo_000478_0x70066d8[];
extern Vtx VB_bits_geo_000478_0x70067c8[];
extern Vtx VB_bits_geo_000478_0x70068b8[];
extern Vtx VB_bits_geo_000478_0x70069a8[];
extern Vtx VB_bits_geo_000478_0x7006a98[];
extern Vtx VB_bits_geo_000478_0x7006b78[];
extern Vtx VB_bits_geo_000478_0x7006c68[];
extern Vtx VB_bits_geo_000478_0x7006d68[];
extern Vtx VB_bits_geo_000478_0x7006e58[];
extern Vtx VB_bits_geo_000478_0x7006f58[];
extern Vtx VB_bits_geo_000478_0x7007058[];
extern Vtx VB_bits_geo_000478_0x7007138[];
extern Vtx VB_bits_geo_000478_0x7007218[];
extern Vtx VB_bits_geo_000478_0x7007308[];
extern Vtx VB_bits_geo_000478_0x70073f8[];
extern u8 bits_geo_000478__texture_09001800[];
extern Gfx DL_bits_geo_000478_0x7007af0[];
extern Gfx DL_bits_geo_000478_0x7007448[];
#endif