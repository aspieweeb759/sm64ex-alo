#ifndef bits_30_model_HEADER_H
#define bits_30_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0006D0_0x7015bd8[];
extern Vtx VB_bits_geo_0006D0_0x7015c18[];
extern Vtx VB_bits_geo_0006D0_0x7015d18[];
extern Vtx VB_bits_geo_0006D0_0x7015e08[];
extern Vtx VB_bits_geo_0006D0_0x7015ee8[];
extern Vtx VB_bits_geo_0006D0_0x7015fc8[];
extern Vtx VB_bits_geo_0006D0_0x70160a8[];
extern u8 bits_geo_0006D0__texture_09007000[];
extern u8 bits_geo_0006D0__texture_09008000[];
extern Gfx DL_bits_geo_0006D0_0x7016300[];
extern Gfx DL_bits_geo_0006D0_0x7016158[];
extern Gfx DL_bits_geo_0006D0_0x7016190[];
#endif