#ifndef bits_10_model_HEADER_H
#define bits_10_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0004F0_0x7009058[];
extern Vtx VB_bits_geo_0004F0_0x7009158[];
extern Vtx VB_bits_geo_0004F0_0x7009258[];
extern Vtx VB_bits_geo_0004F0_0x7009338[];
extern Vtx VB_bits_geo_0004F0_0x7009438[];
extern u8 bits_geo_0004F0__texture_09001800[];
extern Gfx DL_bits_geo_0004F0_0x7009690[];
extern Gfx DL_bits_geo_0004F0_0x70094f8[];
#endif