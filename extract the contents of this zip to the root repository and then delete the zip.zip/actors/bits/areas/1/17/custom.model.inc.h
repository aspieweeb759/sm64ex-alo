#ifndef bits_17_model_HEADER_H
#define bits_17_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000598_0x700d620[];
extern Vtx VB_bits_geo_000598_0x700d720[];
extern Vtx VB_bits_geo_000598_0x700d820[];
extern Vtx VB_bits_geo_000598_0x700d8a0[];
extern Vtx VB_bits_geo_000598_0x700d980[];
extern Vtx VB_bits_geo_000598_0x700da80[];
extern u8 bits_geo_000598__texture_09007000[];
extern u8 bits_geo_000598__texture_09008000[];
extern u8 bits_geo_000598__texture_09002000[];
extern Gfx DL_bits_geo_000598_0x700dd00[];
extern Gfx DL_bits_geo_000598_0x700db20[];
extern Gfx DL_bits_geo_000598_0x700dc08[];
extern Gfx DL_bits_geo_000598_0x700dcb8[];
#endif