#ifndef bits_14_model_HEADER_H
#define bits_14_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000550_0x700ba88[];
extern Vtx VB_bits_geo_000550_0x700bb88[];
extern Vtx VB_bits_geo_000550_0x700bc08[];
extern Vtx VB_bits_geo_000550_0x700bd08[];
extern Vtx VB_bits_geo_000550_0x700be08[];
extern Vtx VB_bits_geo_000550_0x700be48[];
extern Vtx VB_bits_geo_000550_0x700bf48[];
extern Vtx VB_bits_geo_000550_0x700bf88[];
extern Vtx VB_bits_geo_000550_0x700c088[];
extern Vtx VB_bits_geo_000550_0x700c188[];
extern Vtx VB_bits_geo_000550_0x700c288[];
extern Vtx VB_bits_geo_000550_0x700c378[];
extern Vtx VB_bits_geo_000550_0x700c468[];
extern Vtx VB_bits_geo_000550_0x700c558[];
extern Vtx VB_bits_geo_000550_0x700c648[];
extern Vtx VB_bits_geo_000550_0x700c738[];
extern Vtx VB_bits_geo_000550_0x700c828[];
extern Vtx VB_bits_geo_000550_0x700c8c8[];
extern u8 bits_geo_000550__texture_09001800[];
extern u8 bits_geo_000550__texture_09008000[];
extern u8 bits_geo_000550__texture_09007000[];
extern u8 bits_geo_000550__texture_09000800[];
extern Gfx DL_bits_geo_000550_0x700cdc0[];
extern Gfx DL_bits_geo_000550_0x700c908[];
extern Gfx DL_bits_geo_000550_0x700c998[];
extern Gfx DL_bits_geo_000550_0x700ca70[];
extern Gfx DL_bits_geo_000550_0x700caf0[];
extern Gfx DL_bits_geo_000550_0x700cda0[];
#endif