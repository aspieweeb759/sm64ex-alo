#ifndef bits_20_model_HEADER_H
#define bits_20_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0005E0_0x70129a8[];
extern u8 bits_geo_0005E0__texture_09007000[];
extern Gfx DL_bits_geo_0005E0_0x7012b10[];
extern Gfx DL_bits_geo_0005E0_0x7012aa8[];
#endif