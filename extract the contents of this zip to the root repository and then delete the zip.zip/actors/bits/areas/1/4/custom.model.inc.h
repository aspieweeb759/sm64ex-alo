#ifndef bits_4_model_HEADER_H
#define bits_4_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000460_0x7004880[];
extern Vtx VB_bits_geo_000460_0x7004980[];
extern Vtx VB_bits_geo_000460_0x7004a00[];
extern Vtx VB_bits_geo_000460_0x7004b00[];
extern Vtx VB_bits_geo_000460_0x7004c00[];
extern Vtx VB_bits_geo_000460_0x7004d00[];
extern Vtx VB_bits_geo_000460_0x7004df0[];
extern Vtx VB_bits_geo_000460_0x7004ee0[];
extern Vtx VB_bits_geo_000460_0x7004fd0[];
extern Vtx VB_bits_geo_000460_0x70050d0[];
extern Vtx VB_bits_geo_000460_0x70051d0[];
extern Vtx VB_bits_geo_000460_0x70052b0[];
extern Vtx VB_bits_geo_000460_0x70053b0[];
extern Vtx VB_bits_geo_000460_0x70054a0[];
extern Vtx VB_bits_geo_000460_0x70054f0[];
extern Vtx VB_bits_geo_000460_0x70055f0[];
extern Vtx VB_bits_geo_000460_0x70056e0[];
extern Vtx VB_bits_geo_000460_0x7005760[];
extern Vtx VB_bits_geo_000460_0x7005860[];
extern u8 bits_geo_000460__texture_09000800[];
extern u8 bits_geo_000460__texture_09001800[];
extern u8 bits_geo_000460__texture_09003000[];
extern u8 bits_geo_000460__texture_07002000[];
extern Gfx DL_bits_geo_000460_0x7005db8[];
extern Gfx DL_bits_geo_000460_0x70058a0[];
extern Gfx DL_bits_geo_000460_0x7005930[];
extern Gfx DL_bits_geo_000460_0x7005c50[];
extern Gfx DL_bits_geo_000460_0x7005d38[];
#endif