#ifndef bits_12_model_HEADER_H
#define bits_12_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000520_0x700b528[];
extern Vtx VB_bits_geo_000520_0x700b5a8[];
extern Vtx VB_bits_geo_000520_0x700b698[];
extern u8 bits_geo_000520__texture_09007000[];
extern u8 bits_geo_000520__texture_07001000[];
extern Gfx DL_bits_geo_000520_0x700b820[];
extern Gfx DL_bits_geo_000520_0x700b748[];
extern Gfx DL_bits_geo_000520_0x700b790[];
#endif