#ifndef bits_11_model_HEADER_H
#define bits_11_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000508_0x7009700[];
extern Vtx VB_bits_geo_000508_0x70097e0[];
extern Vtx VB_bits_geo_000508_0x70098e0[];
extern Vtx VB_bits_geo_000508_0x70099c0[];
extern Vtx VB_bits_geo_000508_0x7009aa0[];
extern Vtx VB_bits_geo_000508_0x7009ae0[];
extern Vtx VB_bits_geo_000508_0x7009bd0[];
extern Vtx VB_bits_geo_000508_0x7009cd0[];
extern Vtx VB_bits_geo_000508_0x7009dc0[];
extern Vtx VB_bits_geo_000508_0x7009ec0[];
extern Vtx VB_bits_geo_000508_0x7009fb0[];
extern Vtx VB_bits_geo_000508_0x700a090[];
extern Vtx VB_bits_geo_000508_0x700a170[];
extern Vtx VB_bits_geo_000508_0x700a250[];
extern Vtx VB_bits_geo_000508_0x700a2c0[];
extern Vtx VB_bits_geo_000508_0x700a3a0[];
extern Vtx VB_bits_geo_000508_0x700a4a0[];
extern Vtx VB_bits_geo_000508_0x700a580[];
extern Vtx VB_bits_geo_000508_0x700a680[];
extern Vtx VB_bits_geo_000508_0x700a780[];
extern Vtx VB_bits_geo_000508_0x700a880[];
extern Vtx VB_bits_geo_000508_0x700a970[];
extern Vtx VB_bits_geo_000508_0x700aa70[];
extern Vtx VB_bits_geo_000508_0x700ab70[];
extern Vtx VB_bits_geo_000508_0x700ac20[];
extern Vtx VB_bits_geo_000508_0x700ad20[];
extern u8 bits_geo_000508__texture_09007800[];
extern u8 bits_geo_000508__texture_09001800[];
extern u8 bits_geo_000508__texture_09007000[];
extern u8 bits_geo_000508__texture_09008000[];
extern Gfx DL_bits_geo_000508_0x700b4a0[];
extern Gfx DL_bits_geo_000508_0x700ad60[];
extern Gfx DL_bits_geo_000508_0x700ae98[];
extern Gfx DL_bits_geo_000508_0x700b0e0[];
extern Gfx DL_bits_geo_000508_0x700b420[];
#endif