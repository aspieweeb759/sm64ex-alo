#ifndef bits_16_model_HEADER_H
#define bits_16_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000580_0x700d2f0[];
extern Vtx VB_bits_geo_000580_0x700d3f0[];
extern u8 bits_geo_000580__texture_09008000[];
extern Gfx DL_bits_geo_000580_0x700d5a0[];
extern Gfx DL_bits_geo_000580_0x700d4d0[];
#endif