#ifndef bits_9_model_HEADER_H
#define bits_9_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0004D8_0x7008db8[];
extern Vtx VB_bits_geo_0004D8_0x7008ea8[];
extern u8 bits_geo_0004D8__texture_09005000[];
extern Gfx DL_bits_geo_0004D8_0x7008fe8[];
extern Gfx DL_bits_geo_0004D8_0x7008f58[];
#endif