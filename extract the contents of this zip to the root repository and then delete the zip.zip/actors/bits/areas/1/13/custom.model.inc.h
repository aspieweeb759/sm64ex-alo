#ifndef bits_13_model_HEADER_H
#define bits_13_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000538_0x700b8b0[];
extern u8 bits_geo_000538__texture_09003800[];
extern Gfx DL_bits_geo_000538_0x700ba18[];
extern Gfx DL_bits_geo_000538_0x700b9b0[];
#endif