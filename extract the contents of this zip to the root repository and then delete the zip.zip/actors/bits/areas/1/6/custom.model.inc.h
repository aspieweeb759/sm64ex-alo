#ifndef bits_6_model_HEADER_H
#define bits_6_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000490_0x7007b60[];
extern u8 bits_geo_000490__texture_09005000[];
extern Gfx DL_bits_geo_000490_0x7007c28[];
extern Gfx DL_bits_geo_000490_0x7007be0[];
#endif