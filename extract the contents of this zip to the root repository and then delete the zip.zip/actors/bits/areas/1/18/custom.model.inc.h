#ifndef bits_18_model_HEADER_H
#define bits_18_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_0005B0_0x700dd98[];
extern Vtx VB_bits_geo_0005B0_0x700de98[];
extern Vtx VB_bits_geo_0005B0_0x700df98[];
extern Vtx VB_bits_geo_0005B0_0x700e078[];
extern Vtx VB_bits_geo_0005B0_0x700e178[];
extern Vtx VB_bits_geo_0005B0_0x700e268[];
extern Vtx VB_bits_geo_0005B0_0x700e358[];
extern Vtx VB_bits_geo_0005B0_0x700e458[];
extern Vtx VB_bits_geo_0005B0_0x700e548[];
extern Vtx VB_bits_geo_0005B0_0x700e628[];
extern Vtx VB_bits_geo_0005B0_0x700e718[];
extern Vtx VB_bits_geo_0005B0_0x700e808[];
extern Vtx VB_bits_geo_0005B0_0x700e908[];
extern Vtx VB_bits_geo_0005B0_0x700ea08[];
extern Vtx VB_bits_geo_0005B0_0x700eb08[];
extern Vtx VB_bits_geo_0005B0_0x700ebf8[];
extern Vtx VB_bits_geo_0005B0_0x700ecd8[];
extern Vtx VB_bits_geo_0005B0_0x700edc8[];
extern Vtx VB_bits_geo_0005B0_0x700eec8[];
extern Vtx VB_bits_geo_0005B0_0x700efc8[];
extern Vtx VB_bits_geo_0005B0_0x700f0b8[];
extern Vtx VB_bits_geo_0005B0_0x700f198[];
extern Vtx VB_bits_geo_0005B0_0x700f298[];
extern Vtx VB_bits_geo_0005B0_0x700f398[];
extern Vtx VB_bits_geo_0005B0_0x700f478[];
extern u8 bits_geo_0005B0__texture_09007000[];
extern u8 bits_geo_0005B0__texture_09001800[];
extern Gfx DL_bits_geo_0005B0_0x700fc70[];
extern Gfx DL_bits_geo_0005B0_0x700f568[];
extern Gfx DL_bits_geo_0005B0_0x700f790[];
#endif