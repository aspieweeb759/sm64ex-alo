const GeoLayout bullet_bill_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_SHADOW(10,150,400),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bullet_bill_geo_0x500e8a8),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
