const GeoLayout cap_switch_geo[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(6,DL_cap_switch_geo_0x5002e00),
GEO_SWITCH_CASE(4, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_cap_switch_geo_0x5003350),
GEO_DISPLAY_LIST(1,DL_cap_switch_geo_0x5003370),
GEO_DISPLAY_LIST(1,DL_cap_switch_geo_0x5003390),
GEO_DISPLAY_LIST(1,DL_cap_switch_geo_0x50033b0),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
