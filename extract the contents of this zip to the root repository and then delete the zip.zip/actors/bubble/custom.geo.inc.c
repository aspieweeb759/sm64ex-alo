const GeoLayout bubble_geo[]= {
GEO_SWITCH_CASE(1, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_bubble_geo_0x401dd60),
GEO_CLOSE_NODE(),
GEO_END(),
};
const GeoLayout purple_marble_geo[]= {
GEO_SWITCH_CASE(1, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_purple_marble_geo_0x401dde0),
GEO_CLOSE_NODE(),
GEO_END(),
};
