const GeoLayout bitfs_geo_0006A8[]= {
GEO_CULLING_RADIUS(900),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bitfs_geo_0006A8_0x700fb38),
GEO_CLOSE_NODE(),
GEO_END(),
};
