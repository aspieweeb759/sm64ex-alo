#ifndef bitfs_5_model_HEADER_H
#define bitfs_5_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0004F8_0x7003cf8[];
extern Vtx VB_bitfs_geo_0004F8_0x7003df8[];
extern Vtx VB_bitfs_geo_0004F8_0x7003ed8[];
extern u8 bitfs_geo_0004F8__texture_09001000[];
extern Gfx DL_bitfs_geo_0004F8_0x70040b0[];
extern Gfx DL_bitfs_geo_0004F8_0x7003fc8[];
#endif