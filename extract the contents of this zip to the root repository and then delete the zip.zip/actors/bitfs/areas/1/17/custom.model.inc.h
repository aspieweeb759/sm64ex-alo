#ifndef bitfs_17_model_HEADER_H
#define bitfs_17_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000618_0x700bf90[];
extern Vtx VB_bitfs_geo_000618_0x700c090[];
extern Vtx VB_bitfs_geo_000618_0x700c190[];
extern Vtx VB_bitfs_geo_000618_0x700c270[];
extern u8 bitfs_geo_000618__texture_09003800[];
extern Gfx DL_bitfs_geo_000618_0x700c3c0[];
extern Gfx DL_bitfs_geo_000618_0x700c2b0[];
#endif