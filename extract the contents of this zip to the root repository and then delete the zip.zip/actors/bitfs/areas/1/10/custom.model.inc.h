#ifndef bitfs_10_model_HEADER_H
#define bitfs_10_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000570_0x7007798[];
extern Vtx VB_bitfs_geo_000570_0x7007898[];
extern u8 bitfs_geo_000570__texture_09001800[];
extern Gfx DL_bitfs_geo_000570_0x7007958[];
extern Gfx DL_bitfs_geo_000570_0x70078d8[];
#endif