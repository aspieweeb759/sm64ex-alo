#ifndef bitfs_3_model_HEADER_H
#define bitfs_3_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0004C8_0x7002b30[];
extern Vtx VB_bitfs_geo_0004C8_0x7002c30[];
extern Vtx VB_bitfs_geo_0004C8_0x7002d20[];
extern Vtx VB_bitfs_geo_0004C8_0x7002e10[];
extern Vtx VB_bitfs_geo_0004C8_0x7002f00[];
extern Vtx VB_bitfs_geo_0004C8_0x7002f70[];
extern Vtx VB_bitfs_geo_0004C8_0x7003070[];
extern Vtx VB_bitfs_geo_0004C8_0x7003160[];
extern Vtx VB_bitfs_geo_0004C8_0x7003250[];
extern Vtx VB_bitfs_geo_0004C8_0x7003340[];
extern u8 bitfs_geo_0004C8__texture_07001800[];
extern u8 bitfs_geo_0004C8__texture_09001000[];
extern Gfx DL_bitfs_geo_0004C8_0x7003670[];
extern Gfx DL_bitfs_geo_0004C8_0x70033e0[];
extern Gfx DL_bitfs_geo_0004C8_0x7003528[];
#endif