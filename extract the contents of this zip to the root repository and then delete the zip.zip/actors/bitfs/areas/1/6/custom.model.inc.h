#ifndef bitfs_6_model_HEADER_H
#define bitfs_6_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000510_0x7004120[];
extern Vtx VB_bitfs_geo_000510_0x7004210[];
extern Vtx VB_bitfs_geo_000510_0x7004300[];
extern Vtx VB_bitfs_geo_000510_0x7004400[];
extern u8 bitfs_geo_000510__texture_09003800[];
extern Gfx DL_bitfs_geo_000510_0x7004630[];
extern Gfx DL_bitfs_geo_000510_0x7004500[];
#endif