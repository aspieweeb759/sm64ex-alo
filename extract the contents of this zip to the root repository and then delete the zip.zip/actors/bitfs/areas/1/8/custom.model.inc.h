#ifndef bitfs_8_model_HEADER_H
#define bitfs_8_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000540_0x7006c58[];
extern Vtx VB_bitfs_geo_000540_0x7006d58[];
extern Vtx VB_bitfs_geo_000540_0x7006e58[];
extern u8 bitfs_geo_000540__texture_07000000[];
extern u8 bitfs_geo_000540__texture_09003800[];
extern Gfx DL_bitfs_geo_000540_0x7007070[];
extern Gfx DL_bitfs_geo_000540_0x7006f58[];
extern Gfx DL_bitfs_geo_000540_0x7007008[];
#endif