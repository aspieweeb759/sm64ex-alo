const GeoLayout bitfs_geo_000690[]= {
GEO_CULLING_RADIUS(550),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_bitfs_geo_000690_0x700f6a8),
GEO_CLOSE_NODE(),
GEO_END(),
};
