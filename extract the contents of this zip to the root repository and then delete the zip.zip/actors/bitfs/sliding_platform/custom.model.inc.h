#ifndef bitfs_sliding_platform_model_HEADER_H
#define bitfs_sliding_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000740_0x70113a8[];
extern Vtx VB_bitfs_geo_000740_0x70114a8[];
extern u8 bitfs_geo_000740__texture_09003000[];
extern Gfx DL_bitfs_geo_000740_0x7011568[];
extern Gfx DL_bitfs_geo_000740_0x70114e8[];
#endif