#ifndef bitfs_tumbling_platform_near_model_HEADER_H
#define bitfs_tumbling_platform_near_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0006D8_0x700fd80[];
extern Vtx VB_bitfs_geo_0006D8_0x700fe80[];
extern u8 bitfs_geo_0006D8__texture_07001000[];
extern Gfx DL_bitfs_geo_0006D8_0x700ff90[];
extern Gfx DL_bitfs_geo_0006D8_0x700ff00[];
#endif