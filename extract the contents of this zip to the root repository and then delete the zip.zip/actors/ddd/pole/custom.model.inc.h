#ifndef ddd_pole_model_HEADER_H
#define ddd_pole_model_HEADER_H
#include "types.h"
extern Vtx VB_ddd_geo_000450_0x700cef8[];
extern Vtx VB_ddd_geo_000450_0x700cfe8[];
extern Vtx VB_ddd_geo_000450_0x700d0c8[];
extern u8 ddd_geo_000450__texture_07003000[];
extern Light_t Light_ddd_geo_000450_0x700cee8;
extern Ambient_t Light_ddd_geo_000450_0x700cee0;
extern Gfx DL_ddd_geo_000450_0x700d2a0[];
extern Gfx DL_ddd_geo_000450_0x700d1b8[];
#endif