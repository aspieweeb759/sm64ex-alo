ALIGNED8 u8 fwoosh_geo__texture_05015808[] = {
#include "actors/fwoosh/fwoosh_geo_0x5015808_custom.ia16.inc.c"
};
