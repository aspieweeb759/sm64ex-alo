#ifndef explosion_explosion_model_HEADER_H
#define explosion_explosion_model_HEADER_H
#include "types.h"
extern Vtx VB_explosion_geo_0x30009c8[];
extern u8 explosion_geo__texture_03000A08[];
extern Gfx DL_explosion_geo_0x3004298[];
extern Gfx DL_explosion_geo_0x3004208[];
extern u8 explosion_geo__texture_03001208[];
extern Gfx DL_explosion_geo_0x30042b0[];
extern u8 explosion_geo__texture_03001A08[];
extern Gfx DL_explosion_geo_0x30042c8[];
extern u8 explosion_geo__texture_03002208[];
extern Gfx DL_explosion_geo_0x30042e0[];
extern u8 explosion_geo__texture_03002A08[];
extern Gfx DL_explosion_geo_0x30042f8[];
extern u8 explosion_geo__texture_03003208[];
extern Gfx DL_explosion_geo_0x3004310[];
extern u8 explosion_geo__texture_03003A08[];
extern Gfx DL_explosion_geo_0x3004328[];
#endif