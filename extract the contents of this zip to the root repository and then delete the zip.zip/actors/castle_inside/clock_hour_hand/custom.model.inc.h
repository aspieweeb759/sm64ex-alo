#ifndef castle_inside_clock_hour_hand_model_HEADER_H
#define castle_inside_clock_hour_hand_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_geo_001548_0x70589f0[];
extern Vtx VB_castle_geo_001548_0x7058af0[];
extern Vtx VB_castle_geo_001548_0x7058bd0[];
extern Vtx VB_castle_geo_001548_0x7058cd0[];
extern Vtx VB_castle_geo_001548_0x7058db0[];
extern Vtx VB_castle_geo_001548_0x7058e50[];
extern Vtx VB_castle_geo_001548_0x7058f50[];
extern u8 castle_geo_001548__texture_09004800[];
extern Light_t Light_castle_geo_001548_0x70589c8;
extern Light_t Light_castle_geo_001548_0x70589e0;
extern Ambient_t Light_castle_geo_001548_0x70589c0;
extern Ambient_t Light_castle_geo_001548_0x70589d8;
extern Gfx DL_castle_geo_001548_0x7059190[];
extern Gfx DL_castle_geo_001548_0x7058fc0[];
#endif