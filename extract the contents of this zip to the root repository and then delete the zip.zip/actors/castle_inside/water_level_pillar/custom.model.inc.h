#ifndef castle_inside_water_level_pillar_model_HEADER_H
#define castle_inside_water_level_pillar_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_geo_001940_0x7068920[];
extern Vtx VB_castle_geo_001940_0x7068960[];
extern u8 castle_geo_001940__texture_0900B000[];
extern u8 castle_geo_001940__texture_09003000[];
extern Light_t Light_castle_geo_001940_0x7068910;
extern Ambient_t Light_castle_geo_001940_0x7068908;
extern Gfx DL_castle_geo_001940_0x7068b10[];
extern Gfx DL_castle_geo_001940_0x7068a60[];
extern Gfx DL_castle_geo_001940_0x7068aa8[];
#endif