ALIGNED8 u8 castle_geo_000F18__texture_09005000[] = {
#include "actors/castle_inside/trap_door/castle_geo_000F18_0x9005000_custom.rgba16.inc.c"
};
