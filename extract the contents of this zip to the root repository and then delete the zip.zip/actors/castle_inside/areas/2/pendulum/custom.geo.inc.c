const GeoLayout castle_geo_001518[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_geo_001518_0x70512f8),
GEO_CLOSE_NODE(),
GEO_END(),
};
