ALIGNED8 u8 butterfly_geo__texture_030043A8[] = {
#include "actors/butterfly/butterfly_geo_0x30043a8_custom.rgba16.inc.c"
};
