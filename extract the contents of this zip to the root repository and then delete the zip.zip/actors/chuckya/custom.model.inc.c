#include "custom.model.inc.h"
Vtx VB_chuckya_geo_0x8009f78[] = {
{{{ 0, 56, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -56, -56, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -56, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -56, 56, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x8009fb8[] = {
{{{ 56, 56, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -56, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 56, -56, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 56, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a0e0[] = {
{{{ 0, 13, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -13, -13, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -13, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -13, 13, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a120[] = {
{{{ 13, 13, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -13, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 13, -13, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 13, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a248[] = {
{{{ 0, 13, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -13, -13, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -13, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -13, 13, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a288[] = {
{{{ 13, 13, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -13, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 13, -13, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 13, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a3b0[] = {
{{{ 23, 23, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -22, 23, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -22, -22, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 23, -22, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a498[] = {
{{{ 23, 23, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -22, 23, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -22, -22, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 23, -22, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a580[] = {
{{{ 25, 25, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -25, 25, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -25, -25, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 25, -25, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_chuckya_geo_0x800a680[] = {
{{{ 33, 237, 0 }, 0, { 480, 1016 }, { 64, 101, 40, 255}}},
{{{ 27, 198, 107 }, 0, { 1012, 932 }, { 64, 101, 40, 255}}},
{{{ 196, 134, 0 }, 0, { 480, -66 }, { 64, 101, 40, 255}}},
{{{ 163, 112, 107 }, 0, { 1012, 22 }, { 64, 101, 40, 255}}},
{{{ 196, 134, 0 }, 0, { 480, -66 }, { 64, 101, 215, 255}}},
{{{ 27, 198, -106 }, 0, { -52, 928 }, { 64, 101, 215, 255}}},
{{{ 33, 237, 0 }, 0, { 480, 1016 }, { 64, 101, 215, 255}}},
{{{ 163, 112, -106 }, 0, { -52, 20 }, { 64, 101, 215, 255}}},
};

Vtx VB_chuckya_geo_0x800a7e0[] = {
{{{ 87, 41, -41 }, 0, { 0, 0 }, { 184, 73, 183, 255}}},
{{{ 87, 0, -58 }, 0, { 0, 0 }, { 184, 0, 152, 255}}},
{{{ 3, -1, 0 }, 0, { 0, 0 }, { 130, 0, 0, 255}}},
{{{ 87, 58, 0 }, 0, { 0, 0 }, { 184, 103, 0, 255}}},
{{{ 87, -42, -41 }, 0, { 0, 0 }, { 184, 182, 183, 255}}},
{{{ 87, -42, 42 }, 0, { 0, 0 }, { 184, 182, 73, 255}}},
{{{ 87, 0, 59 }, 0, { 0, 0 }, { 184, 0, 103, 255}}},
{{{ 87, 41, 42 }, 0, { 0, 0 }, { 183, 73, 72, 255}}},
{{{ 88, -59, 0 }, 0, { 0, 0 }, { 185, 152, 0, 255}}},
};

Vtx VB_chuckya_geo_0x800a908[] = {
{{{ -9, 2, 0 }, 0, { 0, 0 }, { 130, 253, 0, 255}}},
{{{ 79, 26, 0 }, 0, { 0, 0 }, { 223, 122, 0, 255}}},
{{{ 79, 1, -33 }, 0, { 0, 0 }, { 212, 255, 138, 255}}},
{{{ 80, -23, 0 }, 0, { 0, 0 }, { 222, 134, 0, 255}}},
{{{ 79, 1, 33 }, 0, { 0, 0 }, { 212, 255, 118, 255}}},
};

Vtx VB_chuckya_geo_0x800a9d0[] = {
{{{ -99, -129, 130 }, 0, { 0, 0 }, { 36, 169, 84, 255}}},
{{{ -135, -173, 100 }, 0, { 0, 0 }, { 36, 169, 84, 255}}},
{{{ -55, -236, 0 }, 0, { 0, 0 }, { 36, 169, 84, 255}}},
{{{ -135, -173, 100 }, 0, { 0, 0 }, { 163, 17, 84, 255}}},
{{{ -202, -49, 0 }, 0, { 0, 0 }, { 163, 17, 84, 255}}},
{{{ -213, -113, 1 }, 0, { 0, 0 }, { 163, 17, 84, 255}}},
{{{ -135, -173, 100 }, 0, { 0, 0 }, { 164, 18, 84, 255}}},
{{{ -99, -129, 130 }, 0, { 0, 0 }, { 164, 18, 84, 255}}},
{{{ -202, -49, 0 }, 0, { 0, 0 }, { 164, 18, 84, 255}}},
{{{ -135, -173, 100 }, 0, { 0, 0 }, { 178, 157, 0, 255}}},
{{{ -132, -175, -100 }, 0, { 0, 0 }, { 178, 157, 0, 255}}},
{{{ -55, -236, 0 }, 0, { 0, 0 }, { 178, 157, 0, 255}}},
{{{ -135, -173, 100 }, 0, { 0, 0 }, { 179, 156, 0, 255}}},
{{{ -213, -113, 1 }, 0, { 0, 0 }, { 179, 156, 0, 255}}},
{{{ -132, -175, -100 }, 0, { 0, 0 }, { 179, 156, 0, 255}}},
};

Vtx VB_chuckya_geo_0x800aac0[] = {
{{{ -213, -113, 1 }, 0, { 0, 0 }, { 163, 14, 172, 255}}},
{{{ -202, -49, 0 }, 0, { 0, 0 }, { 163, 14, 172, 255}}},
{{{ -98, -130, -130 }, 0, { 0, 0 }, { 163, 14, 172, 255}}},
{{{ -132, -175, -100 }, 0, { 0, 0 }, { 163, 14, 172, 255}}},
{{{ -99, -129, 130 }, 0, { 0, 0 }, { 37, 169, 84, 255}}},
{{{ -55, -236, 0 }, 0, { 0, 0 }, { 37, 169, 84, 255}}},
{{{ 3, -210, 1 }, 0, { 0, 0 }, { 37, 169, 84, 255}}},
{{{ -132, -175, -100 }, 0, { 0, 0 }, { 40, 170, 173, 255}}},
{{{ 3, -210, 1 }, 0, { 0, 0 }, { 40, 170, 173, 255}}},
{{{ -55, -236, 0 }, 0, { 0, 0 }, { 40, 170, 173, 255}}},
{{{ -98, -130, -130 }, 0, { 0, 0 }, { 40, 170, 173, 255}}},
};

Light_t Light_chuckya_geo_0x800a9c0 = {
{ 50, 50, 50}, 0, { 50, 50, 50}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_chuckya_geo_0x800a9b8 = {
{12, 12, 12}, 0, {12, 12, 12}, 0
};

Gfx DL_chuckya_geo_0x800abe8[] = {
gsDPPipeSync(),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsSPDisplayList(DL_chuckya_geo_0x800ab70),
gsDPPipeSync(),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800ab70[] = {
gsSPLight(&Light_chuckya_geo_0x800a9c0.col, 1),
gsSPLight(&Light_chuckya_geo_0x800a9b8.col, 2),
gsSPVertex(VB_chuckya_geo_0x800a9d0, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,9, 10, 11, 0),
gsSP1Triangle(12, 13, 14, 0),
gsSPVertex(VB_chuckya_geo_0x800aac0, 11, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,7, 8, 9, 0),
gsSP1Triangle(7, 10, 8, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a5f8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_chuckya_geo_0x800a5c0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a5c0[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08007778),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_chuckya_geo_0x800a580, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_chuckya_geo_0x800a8f8 = {
{ 255, 255, 0}, 0, { 255, 255, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_chuckya_geo_0x800a8f0 = {
{76, 76, 0}, 0, {76, 76, 0}, 0
};

Gfx DL_chuckya_geo_0x800a998[] = {
gsDPPipeSync(),
gsSPDisplayList(DL_chuckya_geo_0x800a958),
gsDPPipeSync(),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a958[] = {
gsSPLight(&Light_chuckya_geo_0x800a8f8.col, 1),
gsSPLight(&Light_chuckya_geo_0x800a8f0.col, 2),
gsSPVertex(VB_chuckya_geo_0x800a908, 5, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 4, 0),
gsSP2Triangles(0, 2, 3, 0,0, 4, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_chuckya_geo_0x800a670 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_chuckya_geo_0x800a668 = {
{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_chuckya_geo_0x800a758[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_chuckya_geo_0x800a700),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a700[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08006778),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_chuckya_geo_0x800a670.col, 1),
gsSPLight(&Light_chuckya_geo_0x800a668.col, 2),
gsSPVertex(VB_chuckya_geo_0x800a680, 8, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSP2Triangles(4, 5, 6, 0,4, 7, 5, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a068[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_chuckya_geo_0x8009ff8),
gsSPDisplayList(DL_chuckya_geo_0x800a030),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x8009ff8[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08007F78),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_chuckya_geo_0x8009f78, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a030[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08008F78),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_chuckya_geo_0x8009fb8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a1d0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_chuckya_geo_0x800a160),
gsSPDisplayList(DL_chuckya_geo_0x800a198),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a160[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08007F78),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_chuckya_geo_0x800a0e0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a198[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08008F78),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_chuckya_geo_0x800a120, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a428[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_chuckya_geo_0x800a3f0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a3f0[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08007778),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_chuckya_geo_0x800a3b0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a338[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_chuckya_geo_0x800a2c8),
gsSPDisplayList(DL_chuckya_geo_0x800a300),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a2c8[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08007F78),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_chuckya_geo_0x800a248, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a300[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08008F78),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_chuckya_geo_0x800a288, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a510[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_chuckya_geo_0x800a4d8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a4d8[] = {
gsDPSetTextureImage(0, 2, 1, chuckya_geo__texture_08007778),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_chuckya_geo_0x800a498, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_chuckya_geo_0x800a7d0 = {
{ 137, 137, 138}, 0, { 137, 137, 138}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_chuckya_geo_0x800a7c8 = {
{41, 41, 41}, 0, {41, 41, 41}, 0
};

Gfx DL_chuckya_geo_0x800a8d0[] = {
gsDPPipeSync(),
gsSPDisplayList(DL_chuckya_geo_0x800a870),
gsDPPipeSync(),
gsSPEndDisplayList(),
};

Gfx DL_chuckya_geo_0x800a870[] = {
gsSPLight(&Light_chuckya_geo_0x800a7d0.col, 1),
gsSPLight(&Light_chuckya_geo_0x800a7c8.col, 2),
gsSPVertex(VB_chuckya_geo_0x800a7e0, 9, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSP2Triangles(1, 4, 2, 0,5, 6, 2, 0),
gsSP2Triangles(6, 7, 2, 0,8, 5, 2, 0),
gsSP2Triangles(7, 3, 2, 0,4, 8, 2, 0),
gsSPEndDisplayList(),
};

