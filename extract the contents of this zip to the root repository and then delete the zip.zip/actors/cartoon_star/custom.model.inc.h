#ifndef cartoon_star_cartoon_star_model_HEADER_H
#define cartoon_star_cartoon_star_model_HEADER_H
#include "types.h"
extern Vtx VB_cartoon_star_geo_0x302c0f8[];
extern Vtx VB_cartoon_star_geo_0x302c198[];
extern Light_t Light_cartoon_star_geo_0x302bd70;
extern Ambient_t Light_cartoon_star_geo_0x302bd68;
extern Gfx DL_cartoon_star_geo_0x302c298[];
extern Gfx DL_cartoon_star_geo_0x302c238[];
extern Light_t Light_cartoon_star_geo_0x302bd88;
extern Ambient_t Light_cartoon_star_geo_0x302bd80;
extern Gfx DL_cartoon_star_geo_0x302c2b8[];
extern Light_t Light_cartoon_star_geo_0x302bda0;
extern Ambient_t Light_cartoon_star_geo_0x302bd98;
extern Gfx DL_cartoon_star_geo_0x302c2d8[];
extern Light_t Light_cartoon_star_geo_0x302bdb8;
extern Ambient_t Light_cartoon_star_geo_0x302bdb0;
extern Gfx DL_cartoon_star_geo_0x302c2f8[];
extern Gfx DL_cartoon_star_geo_0x302c318[];
#endif