const GeoLayout blue_coin_switch_geo[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_blue_coin_switch_geo_0x8000e08),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
