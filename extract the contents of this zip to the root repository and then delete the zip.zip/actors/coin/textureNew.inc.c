ALIGNED8 u8 yellow_coin_geo__texture_03005780[] = {
#include "actors/coin/yellow_coin_geo_0x3005780_custom.ia16.inc.c"
};
ALIGNED8 u8 yellow_coin_geo__texture_03005F80[] = {
#include "actors/coin/yellow_coin_geo_0x3005f80_custom.ia16.inc.c"
};
ALIGNED8 u8 yellow_coin_geo__texture_03006780[] = {
#include "actors/coin/yellow_coin_geo_0x3006780_custom.ia16.inc.c"
};
ALIGNED8 u8 yellow_coin_geo__texture_03006F80[] = {
#include "actors/coin/yellow_coin_geo_0x3006f80_custom.ia16.inc.c"
};
