#ifndef bitdw_square_platform_model_HEADER_H
#define bitdw_square_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000558_0x700b290[];
extern Vtx VB_geo_bitdw_000558_0x700b380[];
extern u8 geo_bitdw_000558__texture_09002000[];
extern Gfx DL_geo_bitdw_000558_0x700b480[];
extern Gfx DL_geo_bitdw_000558_0x700b410[];
#endif