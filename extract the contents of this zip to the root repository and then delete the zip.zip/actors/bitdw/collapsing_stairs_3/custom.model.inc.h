#ifndef bitdw_collapsing_stairs_3_model_HEADER_H
#define bitdw_collapsing_stairs_3_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0005D0_0x700c6e8[];
extern Vtx VB_geo_bitdw_0005D0_0x700c7c8[];
extern Vtx VB_geo_bitdw_0005D0_0x700c8b8[];
extern Vtx VB_geo_bitdw_0005D0_0x700c9b8[];
extern Vtx VB_geo_bitdw_0005D0_0x700ca88[];
extern u8 geo_bitdw_0005D0__texture_09008000[];
extern u8 geo_bitdw_0005D0__texture_09007000[];
extern Gfx DL_geo_bitdw_0005D0_0x700cc00[];
extern Gfx DL_geo_bitdw_0005D0_0x700cac8[];
extern Gfx DL_geo_bitdw_0005D0_0x700cbc8[];
#endif