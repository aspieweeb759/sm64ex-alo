#ifndef bitdw_collapsing_stairs_5_model_HEADER_H
#define bitdw_collapsing_stairs_5_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000600_0x700d208[];
extern Vtx VB_geo_bitdw_000600_0x700d308[];
extern u8 geo_bitdw_000600__texture_09008000[];
extern u8 geo_bitdw_000600__texture_09007000[];
extern Gfx DL_geo_bitdw_000600_0x700d3e8[];
extern Gfx DL_geo_bitdw_000600_0x700d348[];
extern Gfx DL_geo_bitdw_000600_0x700d3b0[];
#endif