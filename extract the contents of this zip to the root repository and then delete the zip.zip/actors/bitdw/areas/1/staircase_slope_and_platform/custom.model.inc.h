#ifndef bitdw_staircase_slope_and_platform_model_HEADER_H
#define bitdw_staircase_slope_and_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0004E0_0x7009430[];
extern Vtx VB_geo_bitdw_0004E0_0x7009530[];
extern Vtx VB_geo_bitdw_0004E0_0x7009610[];
extern Vtx VB_geo_bitdw_0004E0_0x7009690[];
extern Vtx VB_geo_bitdw_0004E0_0x7009790[];
extern Vtx VB_geo_bitdw_0004E0_0x7009880[];
extern Vtx VB_geo_bitdw_0004E0_0x7009970[];
extern Vtx VB_geo_bitdw_0004E0_0x7009a70[];
extern Vtx VB_geo_bitdw_0004E0_0x7009b60[];
extern Vtx VB_geo_bitdw_0004E0_0x7009c50[];
extern Vtx VB_geo_bitdw_0004E0_0x7009d50[];
extern Vtx VB_geo_bitdw_0004E0_0x7009e30[];
extern Vtx VB_geo_bitdw_0004E0_0x7009e90[];
extern Vtx VB_geo_bitdw_0004E0_0x7009f10[];
extern u8 geo_bitdw_0004E0__texture_09007000[];
extern u8 geo_bitdw_0004E0__texture_07001000[];
extern u8 geo_bitdw_0004E0__texture_09000800[];
extern u8 geo_bitdw_0004E0__texture_09004800[];
extern u8 geo_bitdw_0004E0__texture_09001800[];
extern Gfx DL_geo_bitdw_0004E0_0x700a368[];
extern Gfx DL_geo_bitdw_0004E0_0x7009f90[];
extern Gfx DL_geo_bitdw_0004E0_0x700a058[];
extern Gfx DL_geo_bitdw_0004E0_0x700a188[];
extern Gfx DL_geo_bitdw_0004E0_0x700a2b8[];
extern Gfx DL_geo_bitdw_0004E0_0x700a310[];
#endif