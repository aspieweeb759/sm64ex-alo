#ifndef bitdw_platforms_and_tilting_model_HEADER_H
#define bitdw_platforms_and_tilting_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000498_0x7006670[];
extern Vtx VB_geo_bitdw_000498_0x7006770[];
extern Vtx VB_geo_bitdw_000498_0x7006870[];
extern Vtx VB_geo_bitdw_000498_0x7006970[];
extern Vtx VB_geo_bitdw_000498_0x7006a70[];
extern Vtx VB_geo_bitdw_000498_0x7006b70[];
extern Vtx VB_geo_bitdw_000498_0x7006c70[];
extern Vtx VB_geo_bitdw_000498_0x7006d70[];
extern Vtx VB_geo_bitdw_000498_0x7006e50[];
extern Vtx VB_geo_bitdw_000498_0x7006f50[];
extern Vtx VB_geo_bitdw_000498_0x7007050[];
extern Vtx VB_geo_bitdw_000498_0x7007150[];
extern Vtx VB_geo_bitdw_000498_0x7007210[];
extern Vtx VB_geo_bitdw_000498_0x7007300[];
extern Vtx VB_geo_bitdw_000498_0x70073f0[];
extern Vtx VB_geo_bitdw_000498_0x7007430[];
extern Vtx VB_geo_bitdw_000498_0x7007530[];
extern u8 geo_bitdw_000498__texture_07000000[];
extern u8 geo_bitdw_000498__texture_09001800[];
extern u8 geo_bitdw_000498__texture_09007000[];
extern u8 geo_bitdw_000498__texture_09007800[];
extern Gfx DL_geo_bitdw_000498_0x7007aa8[];
extern Gfx DL_geo_bitdw_000498_0x70075b0[];
extern Gfx DL_geo_bitdw_000498_0x7007810[];
extern Gfx DL_geo_bitdw_000498_0x7007940[];
extern Gfx DL_geo_bitdw_000498_0x7007a18[];
#endif