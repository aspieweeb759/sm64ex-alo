#ifndef bitdw_track_for_pyramid_platforms_model_HEADER_H
#define bitdw_track_for_pyramid_platforms_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0004F8_0x700a3f8[];
extern Vtx VB_geo_bitdw_0004F8_0x700a4f8[];
extern u8 geo_bitdw_0004F8__texture_09003800[];
extern Gfx DL_geo_bitdw_0004F8_0x700a6a8[];
extern Gfx DL_geo_bitdw_0004F8_0x700a5f8[];
#endif