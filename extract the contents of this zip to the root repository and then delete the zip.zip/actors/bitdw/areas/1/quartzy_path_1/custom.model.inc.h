#ifndef bitdw_quartzy_path_1_model_HEADER_H
#define bitdw_quartzy_path_1_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000408_0x7003688[];
extern Vtx VB_geo_bitdw_000408_0x7003778[];
extern Vtx VB_geo_bitdw_000408_0x7003868[];
extern Vtx VB_geo_bitdw_000408_0x7003968[];
extern Vtx VB_geo_bitdw_000408_0x7003a68[];
extern u8 geo_bitdw_000408__texture_07000800[];
extern Gfx DL_geo_bitdw_000408_0x7003bf0[];
extern Gfx DL_geo_bitdw_000408_0x7003a98[];
#endif