#ifndef bitdw_starting_platform_model_HEADER_H
#define bitdw_starting_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0003C0_0x7002138[];
extern Vtx VB_geo_bitdw_0003C0_0x7002238[];
extern Vtx VB_geo_bitdw_0003C0_0x70022f8[];
extern Vtx VB_geo_bitdw_0003C0_0x70023f8[];
extern Vtx VB_geo_bitdw_0003C0_0x70024f8[];
extern Vtx VB_geo_bitdw_0003C0_0x70025d8[];
extern Vtx VB_geo_bitdw_0003C0_0x7002658[];
extern u8 geo_bitdw_0003C0__texture_09001000[];
extern u8 geo_bitdw_0003C0__texture_09000800[];
extern u8 geo_bitdw_0003C0__texture_09007000[];
extern u8 geo_bitdw_0003C0__texture_09007800[];
extern Gfx DL_geo_bitdw_0003C0_0x70028a0[];
extern Gfx DL_geo_bitdw_0003C0_0x7002698[];
extern Gfx DL_geo_bitdw_0003C0_0x7002700[];
extern Gfx DL_geo_bitdw_0003C0_0x7002758[];
extern Gfx DL_geo_bitdw_0003C0_0x7002868[];
#endif