#ifndef bitdw_platforms_and_tilting2_model_HEADER_H
#define bitdw_platforms_and_tilting2_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0004B0_0x7007b30[];
extern Vtx VB_geo_bitdw_0004B0_0x7007c30[];
extern Vtx VB_geo_bitdw_0004B0_0x7007d30[];
extern Vtx VB_geo_bitdw_0004B0_0x7007e30[];
extern Vtx VB_geo_bitdw_0004B0_0x7007f30[];
extern Vtx VB_geo_bitdw_0004B0_0x7008030[];
extern Vtx VB_geo_bitdw_0004B0_0x7008120[];
extern Vtx VB_geo_bitdw_0004B0_0x7008210[];
extern Vtx VB_geo_bitdw_0004B0_0x7008310[];
extern Vtx VB_geo_bitdw_0004B0_0x7008380[];
extern Vtx VB_geo_bitdw_0004B0_0x7008480[];
extern Vtx VB_geo_bitdw_0004B0_0x7008580[];
extern Vtx VB_geo_bitdw_0004B0_0x7008680[];
extern Vtx VB_geo_bitdw_0004B0_0x7008740[];
extern Vtx VB_geo_bitdw_0004B0_0x7008830[];
extern Vtx VB_geo_bitdw_0004B0_0x7008930[];
extern Vtx VB_geo_bitdw_0004B0_0x7008970[];
extern Vtx VB_geo_bitdw_0004B0_0x7008a70[];
extern u8 geo_bitdw_0004B0__texture_07000000[];
extern u8 geo_bitdw_0004B0__texture_09001800[];
extern u8 geo_bitdw_0004B0__texture_09007000[];
extern u8 geo_bitdw_0004B0__texture_09007800[];
extern Gfx DL_geo_bitdw_0004B0_0x7008ff0[];
extern Gfx DL_geo_bitdw_0004B0_0x7008af0[];
extern Gfx DL_geo_bitdw_0004B0_0x7008d58[];
extern Gfx DL_geo_bitdw_0004B0_0x7008e88[];
extern Gfx DL_geo_bitdw_0004B0_0x7008f60[];
#endif