#ifndef bitdw_quartz_crystal_model_HEADER_H
#define bitdw_quartz_crystal_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0004C8_0x7009078[];
extern Vtx VB_geo_bitdw_0004C8_0x7009168[];
extern Vtx VB_geo_bitdw_0004C8_0x7009268[];
extern u8 geo_bitdw_0004C8__texture_07001800[];
extern Gfx DL_geo_bitdw_0004C8_0x70093b0[];
extern Gfx DL_geo_bitdw_0004C8_0x70092e8[];
#endif