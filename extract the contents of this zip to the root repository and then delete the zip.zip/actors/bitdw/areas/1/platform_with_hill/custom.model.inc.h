#ifndef bitdw_platform_with_hill_model_HEADER_H
#define bitdw_platform_with_hill_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000468_0x70050f8[];
extern Vtx VB_geo_bitdw_000468_0x70051f8[];
extern Vtx VB_geo_bitdw_000468_0x70052f8[];
extern Vtx VB_geo_bitdw_000468_0x7005378[];
extern Vtx VB_geo_bitdw_000468_0x7005478[];
extern Vtx VB_geo_bitdw_000468_0x7005568[];
extern Vtx VB_geo_bitdw_000468_0x7005668[];
extern Vtx VB_geo_bitdw_000468_0x7005748[];
extern Vtx VB_geo_bitdw_000468_0x70057f8[];
extern u8 geo_bitdw_000468__texture_09001800[];
extern u8 geo_bitdw_000468__texture_09007000[];
extern u8 geo_bitdw_000468__texture_07000000[];
extern Gfx DL_geo_bitdw_000468_0x7005bc0[];
extern Gfx DL_geo_bitdw_000468_0x70058f8[];
extern Gfx DL_geo_bitdw_000468_0x70059d0[];
extern Gfx DL_geo_bitdw_000468_0x7005b58[];
#endif