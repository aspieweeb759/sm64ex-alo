#ifndef bitdw_collapsing_stairs_4_model_HEADER_H
#define bitdw_collapsing_stairs_4_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0005E8_0x700cc78[];
extern Vtx VB_geo_bitdw_0005E8_0x700cd58[];
extern Vtx VB_geo_bitdw_0005E8_0x700ce48[];
extern Vtx VB_geo_bitdw_0005E8_0x700cf48[];
extern Vtx VB_geo_bitdw_0005E8_0x700d018[];
extern u8 geo_bitdw_0005E8__texture_09008000[];
extern u8 geo_bitdw_0005E8__texture_09007000[];
extern Gfx DL_geo_bitdw_0005E8_0x700d190[];
extern Gfx DL_geo_bitdw_0005E8_0x700d058[];
extern Gfx DL_geo_bitdw_0005E8_0x700d158[];
#endif