#ifndef bitdw_collapsing_stairs_2_model_HEADER_H
#define bitdw_collapsing_stairs_2_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0005B8_0x700c158[];
extern Vtx VB_geo_bitdw_0005B8_0x700c238[];
extern Vtx VB_geo_bitdw_0005B8_0x700c328[];
extern Vtx VB_geo_bitdw_0005B8_0x700c428[];
extern Vtx VB_geo_bitdw_0005B8_0x700c4f8[];
extern u8 geo_bitdw_0005B8__texture_09008000[];
extern u8 geo_bitdw_0005B8__texture_09007000[];
extern Gfx DL_geo_bitdw_0005B8_0x700c670[];
extern Gfx DL_geo_bitdw_0005B8_0x700c538[];
extern Gfx DL_geo_bitdw_0005B8_0x700c638[];
#endif