#ifndef bitdw_seesaw_platform_model_HEADER_H
#define bitdw_seesaw_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000540_0x700b010[];
extern Vtx VB_geo_bitdw_000540_0x700b110[];
extern u8 geo_bitdw_000540__texture_09000800[];
extern Gfx DL_geo_bitdw_000540_0x700b220[];
extern Gfx DL_geo_bitdw_000540_0x700b190[];
#endif