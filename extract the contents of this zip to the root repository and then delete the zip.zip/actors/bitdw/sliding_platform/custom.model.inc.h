#ifndef bitdw_sliding_platform_model_HEADER_H
#define bitdw_sliding_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000528_0x700ad90[];
extern Vtx VB_geo_bitdw_000528_0x700ae90[];
extern u8 geo_bitdw_000528__texture_09007000[];
extern Gfx DL_geo_bitdw_000528_0x700afa0[];
extern Gfx DL_geo_bitdw_000528_0x700af10[];
#endif