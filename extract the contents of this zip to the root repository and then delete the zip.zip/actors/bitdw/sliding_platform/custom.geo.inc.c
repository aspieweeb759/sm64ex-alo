const GeoLayout geo_bitdw_000528[]= {
GEO_CULLING_RADIUS(1500),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bitdw_000528_0x700afa0),
GEO_CLOSE_NODE(),
GEO_END(),
};
