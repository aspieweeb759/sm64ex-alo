ALIGNED8 u8 bowser_geo__texture_06023C38[] = {
#include "actors/bowser/bowser_geo_0x6023c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06025C38[] = {
#include "actors/bowser/bowser_geo_0x6025c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06025438[] = {
#include "actors/bowser/bowser_geo_0x6025438_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06022438[] = {
#include "actors/bowser/bowser_geo_0x6022438_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0601F438[] = {
#include "actors/bowser/bowser_geo_0x601f438_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0602AC38[] = {
#include "actors/bowser/bowser_geo_0x602ac38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06022C38[] = {
#include "actors/bowser/bowser_geo_0x6022c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06029C38[] = {
#include "actors/bowser/bowser_geo_0x6029c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06020C38[] = {
#include "actors/bowser/bowser_geo_0x6020c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06024438[] = {
#include "actors/bowser/bowser_geo_0x6024438_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06028438[] = {
#include "actors/bowser/bowser_geo_0x6028438_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06028C38[] = {
#include "actors/bowser/bowser_geo_0x6028c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0602BC38[] = {
#include "actors/bowser/bowser_geo_0x602bc38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0601FC38[] = {
#include "actors/bowser/bowser_geo_0x601fc38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06021438[] = {
#include "actors/bowser/bowser_geo_0x6021438_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0602CC38[] = {
#include "actors/bowser/bowser_geo_0x602cc38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06032C38[] = {
#include "actors/bowser/bowser_geo_0x6032c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0602DC38[] = {
#include "actors/bowser/bowser_geo_0x602dc38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06033C38[] = {
#include "actors/bowser/bowser_geo_0x6033c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0602EC38[] = {
#include "actors/bowser/bowser_geo_0x602ec38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06034C38[] = {
#include "actors/bowser/bowser_geo_0x6034c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06031C38[] = {
#include "actors/bowser/bowser_geo_0x6031c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06035C38[] = {
#include "actors/bowser/bowser_geo_0x6035c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06036C38[] = {
#include "actors/bowser/bowser_geo_0x6036c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_0602FC38[] = {
#include "actors/bowser/bowser_geo_0x602fc38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06037C38[] = {
#include "actors/bowser/bowser_geo_0x6037c38_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_geo__texture_06030C38[] = {
#include "actors/bowser/bowser_geo_0x6030c38_custom.rgba16.inc.c"
};
