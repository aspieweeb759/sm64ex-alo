#ifndef custom_04032a18_custom_04032a18_model_HEADER_H
#define custom_04032a18_custom_04032a18_model_HEADER_H
#include "types.h"
extern Vtx VB_custom_DL_04032a18_0x4032700[];
extern u8 custom_DL_04032a18__texture_04032780[];
extern Gfx DL_custom_DL_04032a18_0x4032a18[];
extern Gfx DL_custom_DL_04032a18_0x4032980[];
extern Gfx DL_custom_DL_04032a18_0x40329e0[];
#endif