#ifndef clam_shell_clam_shell_model_HEADER_H
#define clam_shell_clam_shell_model_HEADER_H
#include "types.h"
extern Vtx VB_clam_shell_geo_0x5001048[];
extern Vtx VB_clam_shell_geo_0x50010f8[];
extern Vtx VB_clam_shell_geo_0x5001338[];
extern Vtx VB_clam_shell_geo_0x50013d8[];
extern u8 clam_shell_geo__texture_05000030[];
extern u8 clam_shell_geo__texture_05000830[];
extern Light_t Light_clam_shell_geo_0x5001328;
extern Ambient_t Light_clam_shell_geo_0x5001320;
extern Gfx DL_clam_shell_geo_0x5001568[];
extern Gfx DL_clam_shell_geo_0x5001478[];
extern Gfx DL_clam_shell_geo_0x50014f8[];
extern Light_t Light_clam_shell_geo_0x5001038;
extern Ambient_t Light_clam_shell_geo_0x5001030;
extern Gfx DL_clam_shell_geo_0x50012b8[];
extern Gfx DL_clam_shell_geo_0x50011a8[];
extern Gfx DL_clam_shell_geo_0x5001238[];
#endif