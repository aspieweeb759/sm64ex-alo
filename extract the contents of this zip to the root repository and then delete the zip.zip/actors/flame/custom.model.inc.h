#ifndef flame_flame_model_HEADER_H
#define flame_flame_model_HEADER_H
#include "types.h"
extern Vtx VB_red_flame_shadow_geo_0x30172e0[];
extern u8 red_flame_geo__texture_03017320[];
extern Gfx DL_red_flame_geo_0x301b3b0[];
extern Gfx DL_red_flame_geo_0x301b320[];
extern u8 red_flame_geo__texture_03017B20[];
extern Gfx DL_red_flame_geo_0x301b3c8[];
extern u8 red_flame_geo__texture_03018320[];
extern Gfx DL_red_flame_geo_0x301b3e0[];
extern u8 red_flame_geo__texture_03018B20[];
extern Gfx DL_red_flame_geo_0x301b3f8[];
extern u8 red_flame_geo__texture_03019320[];
extern Gfx DL_red_flame_geo_0x301b410[];
extern u8 red_flame_geo__texture_03019B20[];
extern Gfx DL_red_flame_geo_0x301b428[];
extern u8 red_flame_geo__texture_0301A320[];
extern Gfx DL_red_flame_geo_0x301b440[];
extern u8 red_flame_geo__texture_0301AB20[];
extern Gfx DL_red_flame_geo_0x301b458[];
extern Gfx DL_blue_flame_geo_0x301b500[];
extern Gfx DL_blue_flame_geo_0x301b470[];
extern Gfx DL_blue_flame_geo_0x301b518[];
extern Gfx DL_blue_flame_geo_0x301b530[];
extern Gfx DL_blue_flame_geo_0x301b548[];
extern Gfx DL_blue_flame_geo_0x301b560[];
extern Gfx DL_blue_flame_geo_0x301b578[];
extern Gfx DL_blue_flame_geo_0x301b590[];
extern Gfx DL_blue_flame_geo_0x301b5a8[];
#endif