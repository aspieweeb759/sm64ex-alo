#ifndef bob_seesaw_platform_model_HEADER_H
#define bob_seesaw_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_bob_geo_000458_0x700e528[];
extern Vtx VB_bob_geo_000458_0x700e628[];
extern u8 bob_geo_000458__texture_09006000[];
extern Light_t Light_bob_geo_000458_0x700e518;
extern Ambient_t Light_bob_geo_000458_0x700e510;
extern Gfx DL_bob_geo_000458_0x700e768[];
extern Gfx DL_bob_geo_000458_0x700e6c8[];
#endif