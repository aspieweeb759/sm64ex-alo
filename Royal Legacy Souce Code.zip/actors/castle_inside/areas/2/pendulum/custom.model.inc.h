#ifndef castle_inside_pendulum_model_HEADER_H
#define castle_inside_pendulum_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_geo_001518_0x7050aa8[];
extern Vtx VB_castle_geo_001518_0x7050b68[];
extern Vtx VB_castle_geo_001518_0x7050c58[];
extern Vtx VB_castle_geo_001518_0x7050d58[];
extern Vtx VB_castle_geo_001518_0x7050e58[];
extern Vtx VB_castle_geo_001518_0x7050f58[];
extern Vtx VB_castle_geo_001518_0x7051048[];
extern u8 castle_geo_001518__texture_09007000[];
extern Light_t Light_castle_geo_001518_0x7050a80;
extern Light_t Light_castle_geo_001518_0x7050a98;
extern Ambient_t Light_castle_geo_001518_0x7050a78;
extern Ambient_t Light_castle_geo_001518_0x7050a90;
extern Gfx DL_castle_geo_001518_0x70512f8[];
extern Gfx DL_castle_geo_001518_0x7051108[];
extern Gfx DL_castle_geo_001518_0x7051170[];
#endif