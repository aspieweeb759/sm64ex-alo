const GeoLayout castle_geo_000F18[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_geo_000F18_0x703bcb8),
GEO_CLOSE_NODE(),
GEO_END(),
};
