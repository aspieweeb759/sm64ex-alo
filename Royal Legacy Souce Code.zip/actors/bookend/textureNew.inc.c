ALIGNED8 u8 bookend_part_geo__texture_05000860[] = {
#include "actors/bookend/bookend_part_geo_0x5000860_custom.rgba16.inc.c"
};
ALIGNED8 u8 bookend_part_geo__texture_05000C60[] = {
#include "actors/bookend/bookend_part_geo_0x5000c60_custom.rgba16.inc.c"
};
ALIGNED8 u8 bookend_part_geo__texture_05000060[] = {
#include "actors/bookend/bookend_part_geo_0x5000060_custom.rgba16.inc.c"
};
ALIGNED8 u8 bookend_part_geo__texture_05001060[] = {
#include "actors/bookend/bookend_part_geo_0x5001060_custom.rgba16.inc.c"
};
ALIGNED8 u8 bookend_part_geo__texture_05000460[] = {
#include "actors/bookend/bookend_part_geo_0x5000460_custom.rgba16.inc.c"
};
