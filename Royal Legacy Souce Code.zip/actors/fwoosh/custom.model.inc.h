#ifndef fwoosh_fwoosh_model_HEADER_H
#define fwoosh_fwoosh_model_HEADER_H
#include "types.h"
extern Vtx VB_fwoosh_geo_0x50157c8[];
extern u8 fwoosh_geo__texture_05015808[];
extern Gfx DL_fwoosh_geo_0x5016040[];
extern Gfx DL_fwoosh_geo_0x5016008[];
#endif