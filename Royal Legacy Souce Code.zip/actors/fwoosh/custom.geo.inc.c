const GeoLayout fwoosh_geo[]= {
GEO_CULLING_RADIUS(200),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_fwoosh_geo_0x5016040),
GEO_CLOSE_NODE(),
GEO_END(),
};
