#ifndef bits_24_model_HEADER_H
#define bits_24_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000640_0x70138a8[];
extern Vtx VB_bits_geo_000640_0x7013998[];
extern Vtx VB_bits_geo_000640_0x7013a88[];
extern Vtx VB_bits_geo_000640_0x7013b78[];
extern u8 bits_geo_000640__texture_09007000[];
extern Light_t Light_bits_geo_000640_0x7013898;
extern Ambient_t Light_bits_geo_000640_0x7013890;
extern Gfx DL_bits_geo_000640_0x7013c78[];
extern Gfx DL_bits_geo_000640_0x7013ba8[];
#endif