#ifndef bits_32_model_HEADER_H
#define bits_32_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000700_0x7016b18[];
extern Vtx VB_bits_geo_000700_0x7016b58[];
extern Vtx VB_bits_geo_000700_0x7016c58[];
extern u8 bits_geo_000700__texture_09007000[];
extern u8 bits_geo_000700__texture_09008000[];
extern Gfx DL_bits_geo_000700_0x7016da0[];
extern Gfx DL_bits_geo_000700_0x7016cd8[];
extern Gfx DL_bits_geo_000700_0x7016d10[];
#endif