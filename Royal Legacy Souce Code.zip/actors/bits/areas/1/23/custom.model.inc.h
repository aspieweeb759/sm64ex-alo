#ifndef bits_23_model_HEADER_H
#define bits_23_model_HEADER_H
#include "types.h"
extern Vtx VB_bits_geo_000628_0x7013610[];
extern Vtx VB_bits_geo_000628_0x7013710[];
extern u8 bits_geo_000628__texture_09008000[];
extern Gfx DL_bits_geo_000628_0x7013820[];
extern Gfx DL_bits_geo_000628_0x7013790[];
#endif