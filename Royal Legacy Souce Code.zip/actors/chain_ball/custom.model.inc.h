#ifndef chain_ball_chain_ball_model_HEADER_H
#define chain_ball_chain_ball_model_HEADER_H
#include "types.h"
extern Vtx VB_metallic_ball_geo_0x6020aa0[];
extern u8 metallic_ball_geo__texture_06020AE8[];
extern Gfx DL_metallic_ball_geo_0x60212e8[];
#endif