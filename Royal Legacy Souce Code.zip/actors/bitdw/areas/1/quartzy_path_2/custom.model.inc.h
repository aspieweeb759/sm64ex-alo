#ifndef bitdw_quartzy_path_2_model_HEADER_H
#define bitdw_quartzy_path_2_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000420_0x7003c60[];
extern Vtx VB_geo_bitdw_000420_0x7003d60[];
extern Vtx VB_geo_bitdw_000420_0x7003e60[];
extern Vtx VB_geo_bitdw_000420_0x7003f60[];
extern Vtx VB_geo_bitdw_000420_0x7004060[];
extern u8 geo_bitdw_000420__texture_07000800[];
extern u8 geo_bitdw_000420__texture_09007000[];
extern Gfx DL_geo_bitdw_000420_0x7004318[];
extern Gfx DL_geo_bitdw_000420_0x7004160[];
extern Gfx DL_geo_bitdw_000420_0x7004220[];
#endif