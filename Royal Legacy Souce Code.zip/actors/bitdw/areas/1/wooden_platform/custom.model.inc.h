#ifndef bitdw_wooden_platform_model_HEADER_H
#define bitdw_wooden_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000480_0x7005c40[];
extern Vtx VB_geo_bitdw_000480_0x7005d40[];
extern Vtx VB_geo_bitdw_000480_0x7005e40[];
extern Vtx VB_geo_bitdw_000480_0x7005f20[];
extern Vtx VB_geo_bitdw_000480_0x7006010[];
extern Vtx VB_geo_bitdw_000480_0x70060f0[];
extern Vtx VB_geo_bitdw_000480_0x70061e0[];
extern Vtx VB_geo_bitdw_000480_0x70062e0[];
extern u8 geo_bitdw_000480__texture_09004800[];
extern u8 geo_bitdw_000480__texture_09007000[];
extern u8 geo_bitdw_000480__texture_07001000[];
extern Gfx DL_geo_bitdw_000480_0x70065f0[];
extern Gfx DL_geo_bitdw_000480_0x7006360[];
extern Gfx DL_geo_bitdw_000480_0x70063e8[];
extern Gfx DL_geo_bitdw_000480_0x70064a8[];
#endif