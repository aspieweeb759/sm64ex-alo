#ifndef bitdw_large_platform_model_HEADER_H
#define bitdw_large_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0003D8_0x7002928[];
extern Vtx VB_geo_bitdw_0003D8_0x7002a28[];
extern Vtx VB_geo_bitdw_0003D8_0x7002b28[];
extern Vtx VB_geo_bitdw_0003D8_0x7002ba8[];
extern Vtx VB_geo_bitdw_0003D8_0x7002ca8[];
extern Vtx VB_geo_bitdw_0003D8_0x7002d98[];
extern Vtx VB_geo_bitdw_0003D8_0x7002e88[];
extern Vtx VB_geo_bitdw_0003D8_0x7002f88[];
extern u8 geo_bitdw_0003D8__texture_09001800[];
extern u8 geo_bitdw_0003D8__texture_09007000[];
extern Gfx DL_geo_bitdw_0003D8_0x70032f8[];
extern Gfx DL_geo_bitdw_0003D8_0x7003088[];
extern Gfx DL_geo_bitdw_0003D8_0x7003160[];
#endif