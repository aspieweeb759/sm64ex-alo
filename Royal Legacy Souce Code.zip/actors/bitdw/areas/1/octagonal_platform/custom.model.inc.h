#ifndef bitdw_octagonal_platform_model_HEADER_H
#define bitdw_octagonal_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000450_0x7004630[];
extern Vtx VB_geo_bitdw_000450_0x7004720[];
extern Vtx VB_geo_bitdw_000450_0x7004810[];
extern Vtx VB_geo_bitdw_000450_0x7004910[];
extern Vtx VB_geo_bitdw_000450_0x7004a00[];
extern Vtx VB_geo_bitdw_000450_0x7004b00[];
extern Vtx VB_geo_bitdw_000450_0x7004b80[];
extern Vtx VB_geo_bitdw_000450_0x7004c80[];
extern Vtx VB_geo_bitdw_000450_0x7004d80[];
extern u8 geo_bitdw_000450__texture_07000000[];
extern u8 geo_bitdw_000450__texture_09004800[];
extern u8 geo_bitdw_000450__texture_09007000[];
extern Gfx DL_geo_bitdw_000450_0x7005078[];
extern Gfx DL_geo_bitdw_000450_0x7004dc0[];
extern Gfx DL_geo_bitdw_000450_0x7004f70[];
extern Gfx DL_geo_bitdw_000450_0x7004ff8[];
#endif