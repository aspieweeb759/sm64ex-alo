#ifndef bitdw_narrow_path_platform_model_HEADER_H
#define bitdw_narrow_path_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000510_0x700a718[];
extern Vtx VB_geo_bitdw_000510_0x700a818[];
extern Vtx VB_geo_bitdw_000510_0x700a918[];
extern Vtx VB_geo_bitdw_000510_0x700aa18[];
extern Vtx VB_geo_bitdw_000510_0x700aaf8[];
extern u8 geo_bitdw_000510__texture_09000800[];
extern u8 geo_bitdw_000510__texture_09001800[];
extern u8 geo_bitdw_000510__texture_09007000[];
extern Gfx DL_geo_bitdw_000510_0x700ad10[];
extern Gfx DL_geo_bitdw_000510_0x700ab78[];
extern Gfx DL_geo_bitdw_000510_0x700ac70[];
extern Gfx DL_geo_bitdw_000510_0x700acc8[];
#endif