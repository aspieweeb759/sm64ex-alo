#ifndef bitdw_quartzy_path_fences_model_HEADER_H
#define bitdw_quartzy_path_fences_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000438_0x7004390[];
extern Vtx VB_geo_bitdw_000438_0x7004480[];
extern u8 geo_bitdw_000438__texture_09005000[];
extern Gfx DL_geo_bitdw_000438_0x70045c0[];
extern Gfx DL_geo_bitdw_000438_0x7004530[];
#endif