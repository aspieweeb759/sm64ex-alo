#ifndef bitdw_wooden_bridge_and_fences_model_HEADER_H
#define bitdw_wooden_bridge_and_fences_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0003F0_0x7003370[];
extern Vtx VB_geo_bitdw_0003F0_0x7003460[];
extern Vtx VB_geo_bitdw_0003F0_0x70034e0[];
extern u8 geo_bitdw_0003F0__texture_09005000[];
extern u8 geo_bitdw_0003F0__texture_09006000[];
extern u8 geo_bitdw_0003F0__texture_09000000[];
extern Gfx DL_geo_bitdw_0003F0_0x7003608[];
extern Gfx DL_geo_bitdw_0003F0_0x7003520[];
extern Gfx DL_geo_bitdw_0003F0_0x7003588[];
extern Gfx DL_geo_bitdw_0003F0_0x70035d0[];
#endif