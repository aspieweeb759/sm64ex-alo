#ifndef bitdw_ferris_platform_axle_model_HEADER_H
#define bitdw_ferris_platform_axle_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000570_0x700b508[];
extern Vtx VB_geo_bitdw_000570_0x700b5f8[];
extern Vtx VB_geo_bitdw_000570_0x700b6e8[];
extern Vtx VB_geo_bitdw_000570_0x700b7d8[];
extern u8 geo_bitdw_000570__texture_09000800[];
extern Light_t Light_geo_bitdw_000570_0x700b4f8;
extern Ambient_t Light_geo_bitdw_000570_0x700b4f0;
extern Gfx DL_geo_bitdw_000570_0x700b8d8[];
extern Gfx DL_geo_bitdw_000570_0x700b808[];
#endif