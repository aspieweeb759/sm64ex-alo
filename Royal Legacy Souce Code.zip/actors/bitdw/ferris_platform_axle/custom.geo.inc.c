const GeoLayout geo_bitdw_000570[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bitdw_000570_0x700b8d8),
GEO_CLOSE_NODE(),
GEO_END(),
};
