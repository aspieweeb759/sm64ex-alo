#ifndef bitdw_collapsing_stairs_1_model_HEADER_H
#define bitdw_collapsing_stairs_1_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_0005A0_0x700bbc8[];
extern Vtx VB_geo_bitdw_0005A0_0x700bca8[];
extern Vtx VB_geo_bitdw_0005A0_0x700bd98[];
extern Vtx VB_geo_bitdw_0005A0_0x700be98[];
extern Vtx VB_geo_bitdw_0005A0_0x700bf68[];
extern u8 geo_bitdw_0005A0__texture_09008000[];
extern u8 geo_bitdw_0005A0__texture_09007000[];
extern Gfx DL_geo_bitdw_0005A0_0x700c0e0[];
extern Gfx DL_geo_bitdw_0005A0_0x700bfa8[];
extern Gfx DL_geo_bitdw_0005A0_0x700c0a8[];
#endif