#ifndef bitdw_ferris_platform_model_HEADER_H
#define bitdw_ferris_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bitdw_000588_0x700b948[];
extern Vtx VB_geo_bitdw_000588_0x700ba48[];
extern u8 geo_bitdw_000588__texture_07000000[];
extern Gfx DL_geo_bitdw_000588_0x700bb58[];
extern Gfx DL_geo_bitdw_000588_0x700bac8[];
#endif