const GeoLayout bowser_2_geo_000170[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bowser_2_geo_000170_0x7000fe0),
GEO_CLOSE_NODE(),
GEO_END(),
};
