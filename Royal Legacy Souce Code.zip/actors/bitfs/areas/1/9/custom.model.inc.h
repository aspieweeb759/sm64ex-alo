#ifndef bitfs_9_model_HEADER_H
#define bitfs_9_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000558_0x70070e8[];
extern Vtx VB_bitfs_geo_000558_0x70071c8[];
extern Vtx VB_bitfs_geo_000558_0x70072a8[];
extern Vtx VB_bitfs_geo_000558_0x70073a8[];
extern Vtx VB_bitfs_geo_000558_0x7007488[];
extern Vtx VB_bitfs_geo_000558_0x7007538[];
extern u8 bitfs_geo_000558__texture_09001000[];
extern Gfx DL_bitfs_geo_000558_0x7007720[];
extern Gfx DL_bitfs_geo_000558_0x7007578[];
extern Gfx DL_bitfs_geo_000558_0x7007700[];
#endif