const GeoLayout bitfs_geo_0005E8[]= {
GEO_CULLING_RADIUS(900),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_bitfs_geo_0005E8_0x700ab90),
GEO_CLOSE_NODE(),
GEO_END(),
};
