#ifndef bitfs_2_model_HEADER_H
#define bitfs_2_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0004B0_0x7002188[];
extern Vtx VB_bitfs_geo_0004B0_0x7002288[];
extern Vtx VB_bitfs_geo_0004B0_0x7002308[];
extern Vtx VB_bitfs_geo_0004B0_0x7002408[];
extern Vtx VB_bitfs_geo_0004B0_0x7002488[];
extern Vtx VB_bitfs_geo_0004B0_0x7002588[];
extern Vtx VB_bitfs_geo_0004B0_0x7002688[];
extern Vtx VB_bitfs_geo_0004B0_0x7002788[];
extern u8 bitfs_geo_0004B0__texture_09007000[];
extern u8 bitfs_geo_0004B0__texture_09001800[];
extern u8 bitfs_geo_0004B0__texture_07001800[];
extern u8 bitfs_geo_0004B0__texture_09000800[];
extern Gfx DL_bitfs_geo_0004B0_0x7002a78[];
extern Gfx DL_bitfs_geo_0004B0_0x70027e8[];
extern Gfx DL_bitfs_geo_0004B0_0x7002878[];
extern Gfx DL_bitfs_geo_0004B0_0x7002908[];
extern Gfx DL_bitfs_geo_0004B0_0x70029c8[];
#endif