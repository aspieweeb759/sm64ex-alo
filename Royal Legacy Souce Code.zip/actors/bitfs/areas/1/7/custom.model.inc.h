#ifndef bitfs_7_model_HEADER_H
#define bitfs_7_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000528_0x70046a0[];
extern Vtx VB_bitfs_geo_000528_0x7004790[];
extern Vtx VB_bitfs_geo_000528_0x7004890[];
extern Vtx VB_bitfs_geo_000528_0x7004990[];
extern Vtx VB_bitfs_geo_000528_0x7004a90[];
extern Vtx VB_bitfs_geo_000528_0x7004b90[];
extern Vtx VB_bitfs_geo_000528_0x7004c90[];
extern Vtx VB_bitfs_geo_000528_0x7004d90[];
extern Vtx VB_bitfs_geo_000528_0x7004e10[];
extern Vtx VB_bitfs_geo_000528_0x7004f10[];
extern Vtx VB_bitfs_geo_000528_0x7005010[];
extern Vtx VB_bitfs_geo_000528_0x70050f0[];
extern Vtx VB_bitfs_geo_000528_0x70051f0[];
extern Vtx VB_bitfs_geo_000528_0x70052d0[];
extern Vtx VB_bitfs_geo_000528_0x70053c0[];
extern Vtx VB_bitfs_geo_000528_0x70054a0[];
extern Vtx VB_bitfs_geo_000528_0x7005590[];
extern Vtx VB_bitfs_geo_000528_0x7005600[];
extern Vtx VB_bitfs_geo_000528_0x7005700[];
extern Vtx VB_bitfs_geo_000528_0x7005800[];
extern Vtx VB_bitfs_geo_000528_0x70058f0[];
extern Vtx VB_bitfs_geo_000528_0x70059b0[];
extern Vtx VB_bitfs_geo_000528_0x7005aa0[];
extern Vtx VB_bitfs_geo_000528_0x7005b90[];
extern Vtx VB_bitfs_geo_000528_0x7005c90[];
extern Vtx VB_bitfs_geo_000528_0x7005d80[];
extern Vtx VB_bitfs_geo_000528_0x7005e60[];
extern Vtx VB_bitfs_geo_000528_0x7005f40[];
extern Vtx VB_bitfs_geo_000528_0x7006000[];
extern Vtx VB_bitfs_geo_000528_0x70060f0[];
extern Vtx VB_bitfs_geo_000528_0x70061e0[];
extern u8 bitfs_geo_000528__texture_07001000[];
extern u8 bitfs_geo_000528__texture_09000800[];
extern u8 bitfs_geo_000528__texture_09007000[];
extern u8 bitfs_geo_000528__texture_09001800[];
extern u8 bitfs_geo_000528__texture_07001800[];
extern u8 bitfs_geo_000528__texture_09001000[];
extern Gfx DL_bitfs_geo_000528_0x7006b90[];
extern Gfx DL_bitfs_geo_000528_0x7006220[];
extern Gfx DL_bitfs_geo_000528_0x70064a8[];
extern Gfx DL_bitfs_geo_000528_0x7006790[];
extern Gfx DL_bitfs_geo_000528_0x70067f8[];
extern Gfx DL_bitfs_geo_000528_0x7006900[];
extern Gfx DL_bitfs_geo_000528_0x7006ad8[];
#endif