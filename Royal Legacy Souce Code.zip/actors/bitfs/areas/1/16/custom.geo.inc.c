const GeoLayout bitfs_geo_000600[]= {
GEO_CULLING_RADIUS(2800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bitfs_geo_000600_0x700bed8),
GEO_CLOSE_NODE(),
GEO_END(),
};
