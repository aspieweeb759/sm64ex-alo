#ifndef bitfs_16_model_HEADER_H
#define bitfs_16_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000600_0x700ac00[];
extern Vtx VB_bitfs_geo_000600_0x700ad00[];
extern Vtx VB_bitfs_geo_000600_0x700ae00[];
extern Vtx VB_bitfs_geo_000600_0x700aee0[];
extern Vtx VB_bitfs_geo_000600_0x700afd0[];
extern Vtx VB_bitfs_geo_000600_0x700b0c0[];
extern Vtx VB_bitfs_geo_000600_0x700b1b0[];
extern Vtx VB_bitfs_geo_000600_0x700b260[];
extern Vtx VB_bitfs_geo_000600_0x700b360[];
extern Vtx VB_bitfs_geo_000600_0x700b450[];
extern Vtx VB_bitfs_geo_000600_0x700b4d0[];
extern Vtx VB_bitfs_geo_000600_0x700b5d0[];
extern Vtx VB_bitfs_geo_000600_0x700b6c0[];
extern Vtx VB_bitfs_geo_000600_0x700b7b0[];
extern Vtx VB_bitfs_geo_000600_0x700b8a0[];
extern Vtx VB_bitfs_geo_000600_0x700b910[];
extern Vtx VB_bitfs_geo_000600_0x700ba10[];
extern u8 bitfs_geo_000600__texture_09001000[];
extern u8 bitfs_geo_000600__texture_09007000[];
extern u8 bitfs_geo_000600__texture_07001800[];
extern u8 bitfs_geo_000600__texture_09001800[];
extern Gfx DL_bitfs_geo_000600_0x700bed8[];
extern Gfx DL_bitfs_geo_000600_0x700ba50[];
extern Gfx DL_bitfs_geo_000600_0x700bc38[];
extern Gfx DL_bitfs_geo_000600_0x700bd10[];
extern Gfx DL_bitfs_geo_000600_0x700be58[];
#endif