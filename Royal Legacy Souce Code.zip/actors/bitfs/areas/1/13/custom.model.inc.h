#ifndef bitfs_13_model_HEADER_H
#define bitfs_13_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0005B8_0x7009258[];
extern Vtx VB_bitfs_geo_0005B8_0x7009358[];
extern Vtx VB_bitfs_geo_0005B8_0x7009458[];
extern u8 bitfs_geo_0005B8__texture_07001800[];
extern u8 bitfs_geo_0005B8__texture_09001800[];
extern Gfx DL_bitfs_geo_0005B8_0x70095e0[];
extern Gfx DL_bitfs_geo_0005B8_0x70094d8[];
extern Gfx DL_bitfs_geo_0005B8_0x7009588[];
#endif