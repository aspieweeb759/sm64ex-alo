#ifndef bitfs_tumbling_platform_far_model_HEADER_H
#define bitfs_tumbling_platform_far_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0006F0_0x7010000[];
extern u8 bitfs_geo_0006F0__texture_07001000[];
extern Gfx DL_bitfs_geo_0006F0_0x7010168[];
extern Gfx DL_bitfs_geo_0006F0_0x7010100[];
#endif