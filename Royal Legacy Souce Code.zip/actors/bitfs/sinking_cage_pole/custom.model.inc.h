#ifndef bitfs_sinking_cage_pole_model_HEADER_H
#define bitfs_sinking_cage_pole_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_0006A8_0x700f718[];
extern Vtx VB_bitfs_geo_0006A8_0x700f818[];
extern Vtx VB_bitfs_geo_0006A8_0x700f8f8[];
extern Vtx VB_bitfs_geo_0006A8_0x700f9f8[];
extern u8 bitfs_geo_0006A8__texture_07001000[];
extern Gfx DL_bitfs_geo_0006A8_0x700fb38[];
extern Gfx DL_bitfs_geo_0006A8_0x700fa38[];
#endif