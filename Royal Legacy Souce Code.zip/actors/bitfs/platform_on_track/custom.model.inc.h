#ifndef bitfs_platform_on_track_model_HEADER_H
#define bitfs_platform_on_track_model_HEADER_H
#include "types.h"
extern Vtx VB_bitfs_geo_000758_0x70115d8[];
extern Vtx VB_bitfs_geo_000758_0x70116d8[];
extern u8 bitfs_geo_000758__texture_07000000[];
extern Gfx DL_bitfs_geo_000758_0x7011798[];
extern Gfx DL_bitfs_geo_000758_0x7011718[];
#endif