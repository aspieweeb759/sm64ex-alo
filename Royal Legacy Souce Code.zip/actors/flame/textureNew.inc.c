ALIGNED8 u8 red_flame_geo__texture_03017320[] = {
#include "actors/flame/red_flame_geo_0x3017320_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_03017B20[] = {
#include "actors/flame/red_flame_geo_0x3017b20_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_03018320[] = {
#include "actors/flame/red_flame_geo_0x3018320_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_03018B20[] = {
#include "actors/flame/red_flame_geo_0x3018b20_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_03019320[] = {
#include "actors/flame/red_flame_geo_0x3019320_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_03019B20[] = {
#include "actors/flame/red_flame_geo_0x3019b20_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_0301A320[] = {
#include "actors/flame/red_flame_geo_0x301a320_custom.ia16.inc.c"
};
ALIGNED8 u8 red_flame_geo__texture_0301AB20[] = {
#include "actors/flame/red_flame_geo_0x301ab20_custom.ia16.inc.c"
};
