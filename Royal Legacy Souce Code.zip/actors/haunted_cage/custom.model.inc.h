#ifndef haunted_cage_haunted_cage_model_HEADER_H
#define haunted_cage_haunted_cage_model_HEADER_H
#include "types.h"
extern Vtx VB_haunted_cage_geo_0x500ea88[];
extern Vtx VB_haunted_cage_geo_0x500eb78[];
extern Vtx VB_haunted_cage_geo_0x500ec68[];
extern Vtx VB_haunted_cage_geo_0x500ecc8[];
extern Vtx VB_haunted_cage_geo_0x500edb8[];
extern Vtx VB_haunted_cage_geo_0x500ee98[];
extern Vtx VB_haunted_cage_geo_0x500ef88[];
extern Vtx VB_haunted_cage_geo_0x500f008[];
extern Vtx VB_haunted_cage_geo_0x500f108[];
extern Vtx VB_haunted_cage_geo_0x500f208[];
extern Vtx VB_haunted_cage_geo_0x500f308[];
extern Vtx VB_haunted_cage_geo_0x500f408[];
extern Vtx VB_haunted_cage_geo_0x500f8a0[];
extern Vtx VB_haunted_cage_geo_0x500f990[];
extern Vtx VB_haunted_cage_geo_0x500fa80[];
extern Vtx VB_haunted_cage_geo_0x500fcb0[];
extern Vtx VB_haunted_cage_geo_0x500fda0[];
extern Vtx VB_haunted_cage_geo_0x500fe80[];
extern Vtx VB_haunted_cage_geo_0x500ff80[];
extern u8 haunted_cage_geo__texture_0500D288[];
extern u8 haunted_cage_geo__texture_0500CA88[];
extern u8 haunted_cage_geo__texture_0500C288[];
extern Light_t Light_haunted_cage_geo_0x500c260;
extern Light_t Light_haunted_cage_geo_0x500c278;
extern Ambient_t Light_haunted_cage_geo_0x500c258;
extern Ambient_t Light_haunted_cage_geo_0x500c270;
extern Gfx DL_haunted_cage_geo_0x500f7d8[];
extern Gfx DL_haunted_cage_geo_0x500f4c8[];
extern Gfx DL_haunted_cage_geo_0x500f660[];
extern Gfx DL_haunted_cage_geo_0x500f760[];
extern u8 haunted_cage_geo__texture_0500D688[];
extern Light_t Light_haunted_cage_geo_0x500f890;
extern Ambient_t Light_haunted_cage_geo_0x500f888;
extern Gfx DL_haunted_cage_geo_0x500fc28[];
extern Gfx DL_haunted_cage_geo_0x500fb40[];
extern u8 haunted_cage_geo__texture_0500DA88[];
extern Light_t Light_haunted_cage_geo_0x500fca0;
extern Ambient_t Light_haunted_cage_geo_0x500fc98;
extern Gfx DL_haunted_cage_geo_0x5010100[];
extern Gfx DL_haunted_cage_geo_0x500fff0[];
#endif