#ifndef castle_courtyard_spire_model_HEADER_H
#define castle_courtyard_spire_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_courtyard_geo_000200_0x70049e8[];
extern Vtx VB_castle_courtyard_geo_000200_0x7004ac8[];
extern Vtx VB_castle_courtyard_geo_000200_0x7004bb8[];
extern Vtx VB_castle_courtyard_geo_000200_0x7004ca8[];
extern Vtx VB_castle_courtyard_geo_000200_0x7004da8[];
extern Vtx VB_castle_courtyard_geo_000200_0x7004ea8[];
extern u8 castle_courtyard_geo_000200__texture_09007800[];
extern u8 castle_courtyard_geo_000200__texture_09001000[];
extern Gfx DL_castle_courtyard_geo_000200_0x7005078[];
extern Gfx DL_castle_courtyard_geo_000200_0x7004ed8[];
extern Gfx DL_castle_courtyard_geo_000200_0x7004fb0[];
extern Gfx DL_castle_courtyard_geo_000200_0x7005060[];
#endif