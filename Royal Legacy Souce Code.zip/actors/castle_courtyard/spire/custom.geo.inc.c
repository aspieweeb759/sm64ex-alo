const GeoLayout castle_courtyard_geo_000200[]= {
GEO_CULLING_RADIUS(2600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_courtyard_geo_000200_0x7005078),
GEO_CLOSE_NODE(),
GEO_END(),
};
