#ifndef bob_chain_chomp_gate_model_HEADER_H
#define bob_chain_chomp_gate_model_HEADER_H
#include "types.h"
extern Vtx VB_bob_geo_000440_0x700e3e0[];
extern u8 bob_geo_000440__texture_09008800[];
extern Gfx DL_bob_geo_000440_0x700e458[];
extern Gfx DL_bob_geo_000440_0x700e420[];
#endif