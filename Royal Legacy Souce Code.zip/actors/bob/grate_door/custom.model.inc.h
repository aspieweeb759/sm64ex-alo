#ifndef bob_grate_door_model_HEADER_H
#define bob_grate_door_model_HEADER_H
#include "types.h"
extern Vtx VB_bob_geo_000470_0x700e810[];
extern u8 bob_geo_000470__texture_09008800[];
extern Gfx DL_bob_geo_000470_0x700e8a0[];
extern Gfx DL_bob_geo_000470_0x700e860[];
#endif