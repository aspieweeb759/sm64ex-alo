#ifndef book_book_model_HEADER_H
#define book_book_model_HEADER_H
#include "types.h"
extern Vtx VB_bookend_geo_0x5002d70[];
extern Vtx VB_bookend_geo_0x5002e30[];
extern u8 bookend_geo__texture_05000C60[];
extern u8 bookend_geo__texture_05002570[];
extern Light_t Light_bookend_geo_0x5002560;
extern Ambient_t Light_bookend_geo_0x5002558;
extern Gfx DL_bookend_geo_0x5002fb0[];
extern Gfx DL_bookend_geo_0x5002ef0[];
extern Gfx DL_bookend_geo_0x5002f58[];
#endif