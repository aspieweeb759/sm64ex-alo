ALIGNED8 u8 breakable_box_small_geo__texture_08011A90[] = {
#include "actors/breakable_box_small/breakable_box_small_geo_0x8011a90_custom.rgba16.inc.c"
};
ALIGNED8 u8 breakable_box_small_geo__texture_08012290[] = {
#include "actors/breakable_box_small/breakable_box_small_geo_0x8012290_custom.rgba16.inc.c"
};
