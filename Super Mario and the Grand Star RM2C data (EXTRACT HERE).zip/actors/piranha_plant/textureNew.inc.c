ALIGNED8 u8 piranha_plant_geo__texture_06012BF8[] = {
#include "actors/piranha_plant/piranha_plant_geo_0x6012bf8_custom.rgba16.inc.c"
};
ALIGNED8 u8 piranha_plant_geo__texture_060133F8[] = {
#include "actors/piranha_plant/piranha_plant_geo_0x60133f8_custom.rgba16.inc.c"
};
ALIGNED8 u8 piranha_plant_geo__texture_060123F8[] = {
#include "actors/piranha_plant/piranha_plant_geo_0x60123f8_custom.rgba16.inc.c"
};
ALIGNED8 u8 piranha_plant_geo__texture_06013BF8[] = {
#include "actors/piranha_plant/piranha_plant_geo_0x6013bf8_custom.rgba16.inc.c"
};
ALIGNED8 u8 piranha_plant_geo__texture_060113F8[] = {
#include "actors/piranha_plant/piranha_plant_geo_0x60113f8_custom.rgba16.inc.c"
};
ALIGNED8 u8 piranha_plant_geo__texture_060143F8[] = {
#include "actors/piranha_plant/piranha_plant_geo_0x60143f8_custom.rgba16.inc.c"
};
