ALIGNED8 u8 invisible_bowser_accessory_geo__texture_0601CA50[] = {
#include "actors/impact_ring/invisible_bowser_accessory_geo_0x601ca50_custom.ia16.inc.c"
};
ALIGNED8 u8 invisible_bowser_accessory_geo__texture_0601DA50[] = {
#include "actors/impact_ring/invisible_bowser_accessory_geo_0x601da50_custom.ia16.inc.c"
};
