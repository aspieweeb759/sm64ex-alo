#ifndef impact_ring_impact_ring_model_HEADER_H
#define impact_ring_impact_ring_model_HEADER_H
#include "types.h"
extern Vtx VB_invisible_bowser_accessory_geo_0x601c9d0[];
extern Vtx VB_invisible_bowser_accessory_geo_0x601ca10[];
extern u8 invisible_bowser_accessory_geo__texture_0601CA50[];
extern u8 invisible_bowser_accessory_geo__texture_0601DA50[];
extern Gfx DL_invisible_bowser_accessory_geo_0x601eac0[];
extern Gfx DL_invisible_bowser_accessory_geo_0x601ea50[];
extern Gfx DL_invisible_bowser_accessory_geo_0x601ea88[];
#endif