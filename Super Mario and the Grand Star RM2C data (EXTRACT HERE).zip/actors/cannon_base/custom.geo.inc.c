#include "custom.model.inc.h"
const GeoLayout cannon_base_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_cannon_base_geo_0x80057f8),
GEO_CLOSE_NODE(),
GEO_END(),
};
