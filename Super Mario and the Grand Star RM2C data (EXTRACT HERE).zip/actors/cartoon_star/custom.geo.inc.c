#include "custom.model.inc.h"
const GeoLayout cartoon_star_geo[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(5, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_cartoon_star_geo_0x302c298),
GEO_DISPLAY_LIST(1,DL_cartoon_star_geo_0x302c2b8),
GEO_DISPLAY_LIST(1,DL_cartoon_star_geo_0x302c2d8),
GEO_DISPLAY_LIST(1,DL_cartoon_star_geo_0x302c2f8),
GEO_DISPLAY_LIST(1,DL_cartoon_star_geo_0x302c318),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
