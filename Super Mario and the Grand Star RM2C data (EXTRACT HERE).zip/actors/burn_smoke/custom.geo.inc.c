#include "custom.model.inc.h"
const GeoLayout burn_smoke_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_burn_smoke_geo_0x4022070),
GEO_CLOSE_NODE(),
GEO_END(),
};
