ALIGNED8 u8 wooden_post_geo__texture_06001050[] = {
#include "actors/poundable_pole/wooden_post_geo_0x6001050_custom.rgba16.inc.c"
};
ALIGNED8 u8 wooden_post_geo__texture_06001850[] = {
#include "actors/poundable_pole/wooden_post_geo_0x6001850_custom.rgba16.inc.c"
};
