ALIGNED8 u8 koopa_flag_geo__texture_06000048[] = {
#include "actors/koopa_flag/koopa_flag_geo_0x6000048_custom.rgba16.inc.c"
};
