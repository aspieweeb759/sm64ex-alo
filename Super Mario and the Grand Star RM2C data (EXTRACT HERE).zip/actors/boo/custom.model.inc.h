#ifndef boo_boo_model_HEADER_H
#define boo_boo_model_HEADER_H
#include "types.h"
extern Vtx VB_boo_geo_0x500b340[];
extern Vtx VB_boo_geo_0x500b400[];
extern Vtx VB_boo_geo_0x500b4c0[];
extern Vtx VB_boo_geo_0x500b5b0[];
extern Vtx VB_boo_geo_0x500b6a0[];
extern Vtx VB_boo_geo_0x500b790[];
extern Vtx VB_boo_geo_0x500b880[];
extern Vtx VB_boo_geo_0x500b970[];
extern Vtx VB_boo_geo_0x500ba60[];
extern Vtx VB_boo_geo_0x500bb50[];
extern Vtx VB_boo_geo_0x500bc40[];
extern Vtx VB_boo_geo_0x500bd30[];
extern Vtx VB_boo_geo_0x500be20[];
extern u8 boo_geo__texture_0500AB40[];
extern u8 boo_geo__texture_05009B40[];
extern Light_t Light_boo_geo_0x5009b30;
extern Ambient_t Light_boo_geo_0x5009b28;
extern Gfx DL_boo_geo_0x500c1b0[];
extern Gfx DL_boo_geo_0x500bee0[];
extern Gfx DL_boo_geo_0x500bf48[];
extern Gfx DL_boo_geo_0x500bfa0[];
#endif