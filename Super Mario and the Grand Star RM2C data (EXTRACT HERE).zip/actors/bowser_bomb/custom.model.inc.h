#ifndef bowser_bomb_bowser_bomb_model_HEADER_H
#define bowser_bomb_bowser_bomb_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_bomb_geo_0x605a410[];
extern Vtx VB_bowser_bomb_geo_0x605a450[];
extern Vtx VB_bowser_bomb_geo_0x605a490[];
extern Vtx VB_bowser_bomb_geo_0x605a580[];
extern Vtx VB_bowser_bomb_geo_0x605a670[];
extern Vtx VB_bowser_bomb_geo_0x605a760[];
extern Vtx VB_bowser_bomb_geo_0x605a850[];
extern u8 bowser_bomb_geo__texture_06059C10[];
extern Light_t Light_bowser_bomb_geo_0x6057c00;
extern Ambient_t Light_bowser_bomb_geo_0x6057bf8;
extern Gfx DL_bowser_bomb_geo_0x605ab10[];
extern Gfx DL_bowser_bomb_geo_0x605a9f8[];
extern u8 bowser_bomb_geo__texture_06057C10[];
extern u8 bowser_bomb_geo__texture_06058C10[];
extern Gfx DL_bowser_bomb_geo_0x605a980[];
extern Gfx DL_bowser_bomb_geo_0x605a910[];
extern Gfx DL_bowser_bomb_geo_0x605a948[];
#endif