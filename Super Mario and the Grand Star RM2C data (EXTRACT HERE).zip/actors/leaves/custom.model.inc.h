#ifndef leaves_leaves_model_HEADER_H
#define leaves_leaves_model_HEADER_H
#include "types.h"
extern Vtx VB_leaves_geo_0x301cba0[];
extern u8 leaves_geo__texture_0301CBE0[];
extern Gfx DL_leaves_geo_0x301cde0[];
#endif