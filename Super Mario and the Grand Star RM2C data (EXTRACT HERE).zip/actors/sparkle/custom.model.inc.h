#ifndef sparkle_sparkle_model_HEADER_H
#define sparkle_sparkle_model_HEADER_H
#include "types.h"
extern Vtx VB_sparkles_geo_0x4027450[];
extern u8 sparkles_geo__texture_04029C90[];
extern Gfx DL_sparkles_geo_0x402a570[];
extern Gfx DL_sparkles_geo_0x402a490[];
extern u8 sparkles_geo__texture_04029490[];
extern Gfx DL_sparkles_geo_0x402a558[];
extern u8 sparkles_geo__texture_04028C90[];
extern Gfx DL_sparkles_geo_0x402a540[];
extern u8 sparkles_geo__texture_04028490[];
extern Gfx DL_sparkles_geo_0x402a528[];
extern u8 sparkles_geo__texture_04027C90[];
extern Gfx DL_sparkles_geo_0x402a510[];
extern u8 sparkles_geo__texture_04027490[];
extern Gfx DL_sparkles_geo_0x402a4f8[];
#endif