ALIGNED8 u8 sparkles_geo__texture_04029C90[] = {
#include "actors/sparkle/sparkles_geo_0x4029c90_custom.rgba16.inc.c"
};
ALIGNED8 u8 sparkles_geo__texture_04029490[] = {
#include "actors/sparkle/sparkles_geo_0x4029490_custom.rgba16.inc.c"
};
ALIGNED8 u8 sparkles_geo__texture_04028C90[] = {
#include "actors/sparkle/sparkles_geo_0x4028c90_custom.rgba16.inc.c"
};
ALIGNED8 u8 sparkles_geo__texture_04028490[] = {
#include "actors/sparkle/sparkles_geo_0x4028490_custom.rgba16.inc.c"
};
ALIGNED8 u8 sparkles_geo__texture_04027C90[] = {
#include "actors/sparkle/sparkles_geo_0x4027c90_custom.rgba16.inc.c"
};
ALIGNED8 u8 sparkles_geo__texture_04027490[] = {
#include "actors/sparkle/sparkles_geo_0x4027490_custom.rgba16.inc.c"
};
