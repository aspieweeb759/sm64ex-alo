ALIGNED8 u8 flyguy_geo__texture_0800F088[] = {
#include "actors/flyguy/flyguy_geo_0x800f088_custom.rgba16.inc.c"
};
ALIGNED8 u8 flyguy_geo__texture_0800E088[] = {
#include "actors/flyguy/flyguy_geo_0x800e088_custom.rgba16.inc.c"
};
ALIGNED8 u8 flyguy_geo__texture_0800F888[] = {
#include "actors/flyguy/flyguy_geo_0x800f888_custom.ia16.inc.c"
};
