#ifndef number_number_model_HEADER_H
#define number_number_model_HEADER_H
#include "types.h"
extern Vtx VB_number_geo_0x2011e10[];
extern u8 number_geo__texture_02000000[];
extern Gfx DL_number_geo_0x2011ed8[];
extern Gfx DL_number_geo_0x2011e50[];
extern Gfx DL_number_geo_0x2011e98[];
extern u8 number_geo__texture_02000200[];
extern Gfx DL_number_geo_0x2011f08[];
extern u8 number_geo__texture_02000400[];
extern Gfx DL_number_geo_0x2011f38[];
extern u8 number_geo__texture_02000600[];
extern Gfx DL_number_geo_0x2011f68[];
extern u8 number_geo__texture_02000800[];
extern Gfx DL_number_geo_0x2011f98[];
extern u8 number_geo__texture_02000A00[];
extern Gfx DL_number_geo_0x2011fc8[];
extern u8 number_geo__texture_02000C00[];
extern Gfx DL_number_geo_0x2011ff8[];
extern u8 number_geo__texture_02000E00[];
extern Gfx DL_number_geo_0x2012028[];
extern u8 number_geo__texture_02001000[];
extern Gfx DL_number_geo_0x2012058[];
extern u8 number_geo__texture_02001200[];
extern Gfx DL_number_geo_0x2012088[];
#endif