#include "custom.model.inc.h"
const GeoLayout lll_geo_000B08[]= {
GEO_CULLING_RADIUS(550),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_lll_geo_000B08_0x7018380),
GEO_CLOSE_NODE(),
GEO_END(),
};
