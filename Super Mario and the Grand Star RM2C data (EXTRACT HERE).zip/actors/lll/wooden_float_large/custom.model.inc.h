#ifndef lll_wooden_float_large_model_HEADER_H
#define lll_wooden_float_large_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000B68_0x7018d08[];
extern Vtx VB_lll_geo_000B68_0x7018d88[];
extern u8 lll_geo_000B68__texture_07000000[];
extern u8 lll_geo_000B68__texture_07001000[];
extern Light_t Light_lll_geo_000B68_0x700fc08;
extern Ambient_t Light_lll_geo_000B68_0x700fc00;
extern Gfx DL_lll_geo_000B68_0x7018ef8[];
extern Gfx DL_lll_geo_000B68_0x7018e48[];
extern Gfx DL_lll_geo_000B68_0x7018ea0[];
#endif