#include "custom.model.inc.h"
const GeoLayout lll_geo_000B68[]= {
GEO_CULLING_RADIUS(1100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000B68_0x7018ef8),
GEO_CLOSE_NODE(),
GEO_END(),
};
