#ifndef lll_rotating_hexagonal_ring_model_HEADER_H
#define lll_rotating_hexagonal_ring_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000BB0_0x7019470[];
extern Vtx VB_lll_geo_000BB0_0x7019530[];
extern Vtx VB_lll_geo_000BB0_0x7019620[];
extern Vtx VB_lll_geo_000BB0_0x7019710[];
extern Vtx VB_lll_geo_000BB0_0x7019800[];
extern u8 lll_geo_000BB0__texture_07003000[];
extern u8 lll_geo_000BB0__texture_09007800[];
extern Light_t Light_lll_geo_000BB0_0x700fc08;
extern Ambient_t Light_lll_geo_000BB0_0x700fc00;
extern Gfx DL_lll_geo_000BB0_0x7019a08[];
extern Gfx DL_lll_geo_000BB0_0x7019870[];
extern Gfx DL_lll_geo_000BB0_0x7019908[];
#endif