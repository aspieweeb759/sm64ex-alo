#include "custom.model.inc.h"
const GeoLayout lll_geo_000A40[]= {
GEO_CULLING_RADIUS(1700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000A40_0x7015c88),
GEO_DISPLAY_LIST(4,DL_lll_geo_000A40_0x7015e20),
GEO_CLOSE_NODE(),
GEO_END(),
};
