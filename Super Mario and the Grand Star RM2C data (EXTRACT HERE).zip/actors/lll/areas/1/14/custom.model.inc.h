#ifndef lll_14_model_HEADER_H
#define lll_14_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000AD8_0x7017938[];
extern Vtx VB_lll_geo_000AD8_0x70179f8[];
extern Vtx VB_lll_geo_000AD8_0x7017a38[];
extern u8 lll_geo_000AD8__texture_09006800[];
extern u8 lll_geo_000AD8__texture_09006000[];
extern u8 lll_geo_000AD8__texture_09008800[];
extern Light_t Light_lll_geo_000AD8_0x700fc08;
extern Ambient_t Light_lll_geo_000AD8_0x700fc00;
extern Gfx DL_lll_geo_000AD8_0x7017b50[];
extern Gfx DL_lll_geo_000AD8_0x7017a78[];
extern Gfx DL_lll_geo_000AD8_0x7017ae0[];
extern Gfx DL_lll_geo_000AD8_0x7017b18[];
#endif