#include "custom.model.inc.h"
const GeoLayout lll_geo_0009E0[]= {
GEO_CULLING_RADIUS(1700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_0009E0_0x7013d28),
GEO_CLOSE_NODE(),
GEO_END(),
};
