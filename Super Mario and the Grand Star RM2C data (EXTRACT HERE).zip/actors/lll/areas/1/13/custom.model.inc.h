#ifndef lll_13_model_HEADER_H
#define lll_13_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000AC0_0x7017590[];
extern Vtx VB_lll_geo_000AC0_0x7017650[];
extern Vtx VB_lll_geo_000AC0_0x7017740[];
extern u8 lll_geo_000AC0__texture_0900B800[];
extern u8 lll_geo_000AC0__texture_09007800[];
extern Light_t Light_lll_geo_000AC0_0x7017580;
extern Ambient_t Light_lll_geo_000AC0_0x7017578;
extern Gfx DL_lll_geo_000AC0_0x70178a8[];
extern Gfx DL_lll_geo_000AC0_0x70177b0[];
extern Gfx DL_lll_geo_000AC0_0x7017818[];
#endif