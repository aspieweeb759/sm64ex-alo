#include "custom.model.inc.h"
const GeoLayout lll_geo_000A28[]= {
GEO_CULLING_RADIUS(2000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000A28_0x7015458),
GEO_CLOSE_NODE(),
GEO_END(),
};
