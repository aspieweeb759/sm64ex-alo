#ifndef lll_7_model_HEADER_H
#define lll_7_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000A28_0x7014c68[];
extern Vtx VB_lll_geo_000A28_0x7014ce8[];
extern Vtx VB_lll_geo_000A28_0x7014dd8[];
extern Vtx VB_lll_geo_000A28_0x7014ec8[];
extern Vtx VB_lll_geo_000A28_0x7014f08[];
extern Vtx VB_lll_geo_000A28_0x7014fe8[];
extern Vtx VB_lll_geo_000A28_0x70150c8[];
extern Vtx VB_lll_geo_000A28_0x7015108[];
extern u8 lll_geo_000A28__texture_07004800[];
extern u8 lll_geo_000A28__texture_09006800[];
extern u8 lll_geo_000A28__texture_09006000[];
extern u8 lll_geo_000A28__texture_09007800[];
extern Light_t Light_lll_geo_000A28_0x700fc08;
extern Ambient_t Light_lll_geo_000A28_0x700fc00;
extern Gfx DL_lll_geo_000A28_0x7015458[];
extern Gfx DL_lll_geo_000A28_0x7015208[];
extern Gfx DL_lll_geo_000A28_0x7015328[];
extern Gfx DL_lll_geo_000A28_0x70153f0[];
extern Gfx DL_lll_geo_000A28_0x7015270[];
#endif