#ifndef lll_sinking_rock_block_model_HEADER_H
#define lll_sinking_rock_block_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000DD0_0x701a688[];
extern Vtx VB_lll_geo_000DD0_0x701a778[];
extern u8 lll_geo_000DD0__texture_09002000[];
extern Light_t Light_lll_geo_000DD0_0x701a678;
extern Ambient_t Light_lll_geo_000DD0_0x701a670;
extern Gfx DL_lll_geo_000DD0_0x701a878[];
extern Gfx DL_lll_geo_000DD0_0x701a7e8[];
#endif