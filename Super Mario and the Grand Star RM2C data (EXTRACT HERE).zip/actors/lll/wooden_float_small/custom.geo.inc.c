#include "custom.model.inc.h"
const GeoLayout lll_geo_000B50[]= {
GEO_CULLING_RADIUS(700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000B50_0x7018c90),
GEO_CLOSE_NODE(),
GEO_END(),
};
