#ifndef lll_wooden_float_small_model_HEADER_H
#define lll_wooden_float_small_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000B50_0x7018aa0[];
extern Vtx VB_lll_geo_000B50_0x7018b20[];
extern u8 lll_geo_000B50__texture_07000000[];
extern u8 lll_geo_000B50__texture_07001000[];
extern Light_t Light_lll_geo_000B50_0x700fc08;
extern Ambient_t Light_lll_geo_000B50_0x700fc00;
extern Gfx DL_lll_geo_000B50_0x7018c90[];
extern Gfx DL_lll_geo_000B50_0x7018be0[];
extern Gfx DL_lll_geo_000B50_0x7018c38[];
#endif