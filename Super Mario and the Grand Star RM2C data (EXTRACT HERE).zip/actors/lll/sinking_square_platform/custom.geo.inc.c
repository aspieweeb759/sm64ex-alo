#include "custom.model.inc.h"
const GeoLayout lll_geo_000BE0[]= {
GEO_CULLING_RADIUS(1800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000BE0_0x701a010),
GEO_CLOSE_NODE(),
GEO_END(),
};
