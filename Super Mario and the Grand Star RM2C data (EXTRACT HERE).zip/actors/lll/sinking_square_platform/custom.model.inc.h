#ifndef lll_sinking_square_platform_model_HEADER_H
#define lll_sinking_square_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000BE0_0x7019c80[];
extern Vtx VB_lll_geo_000BE0_0x7019d20[];
extern Vtx VB_lll_geo_000BE0_0x7019e20[];
extern Vtx VB_lll_geo_000BE0_0x7019e80[];
extern u8 lll_geo_000BE0__texture_09004000[];
extern Light_t Light_lll_geo_000BE0_0x700fc50;
extern Light_t Light_lll_geo_000BE0_0x700fc68;
extern Light_t Light_lll_geo_000BE0_0x700fc08;
extern Ambient_t Light_lll_geo_000BE0_0x700fc48;
extern Ambient_t Light_lll_geo_000BE0_0x700fc60;
extern Ambient_t Light_lll_geo_000BE0_0x700fc00;
extern Gfx DL_lll_geo_000BE0_0x701a010[];
extern Gfx DL_lll_geo_000BE0_0x7019f20[];
#endif