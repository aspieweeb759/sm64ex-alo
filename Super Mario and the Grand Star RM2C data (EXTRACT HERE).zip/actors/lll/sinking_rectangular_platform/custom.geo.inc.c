#include "custom.model.inc.h"
const GeoLayout lll_geo_000BC8[]= {
GEO_CULLING_RADIUS(1400),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000BC8_0x7019c08),
GEO_CLOSE_NODE(),
GEO_END(),
};
