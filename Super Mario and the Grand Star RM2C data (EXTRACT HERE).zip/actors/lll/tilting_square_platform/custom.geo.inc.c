#include "custom.model.inc.h"
const GeoLayout lll_geo_000BF8[]= {
GEO_CULLING_RADIUS(800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000BF8_0x701a1f0),
GEO_CLOSE_NODE(),
GEO_END(),
};
