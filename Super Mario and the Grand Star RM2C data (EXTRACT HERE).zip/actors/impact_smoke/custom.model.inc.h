#ifndef impact_smoke_impact_smoke_model_HEADER_H
#define impact_smoke_impact_smoke_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_impact_smoke_geo_0x6062b78[];
extern u8 bowser_impact_smoke_geo__texture_0605AB78[];
extern u8 bowser_impact_smoke_geo__texture_0605BB78[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062c88[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062bf8[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062c28[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062c40[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062c58[];
extern u8 bowser_impact_smoke_geo__texture_0605CB78[];
extern u8 bowser_impact_smoke_geo__texture_0605DB78[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062d28[];
extern u8 bowser_impact_smoke_geo__texture_0605EB78[];
extern u8 bowser_impact_smoke_geo__texture_0605FB78[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062dc8[];
extern u8 bowser_impact_smoke_geo__texture_06060B78[];
extern u8 bowser_impact_smoke_geo__texture_06061B78[];
extern Gfx DL_bowser_impact_smoke_geo_0x6062e68[];
#endif