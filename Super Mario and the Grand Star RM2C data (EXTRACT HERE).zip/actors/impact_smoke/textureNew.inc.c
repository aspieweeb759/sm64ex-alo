ALIGNED8 u8 bowser_impact_smoke_geo__texture_0605AB78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x605ab78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_0605BB78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x605bb78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_0605CB78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x605cb78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_0605DB78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x605db78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_0605EB78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x605eb78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_0605FB78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x605fb78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_06060B78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x6060b78_custom.ia16.inc.c"
};
ALIGNED8 u8 bowser_impact_smoke_geo__texture_06061B78[] = {
#include "actors/impact_smoke/bowser_impact_smoke_geo_0x6061b78_custom.ia16.inc.c"
};
