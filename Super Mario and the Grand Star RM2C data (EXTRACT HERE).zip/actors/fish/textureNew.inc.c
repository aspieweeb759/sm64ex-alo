ALIGNED8 u8 fish_shadow_geo__texture_0301B5E0[] = {
#include "actors/fish/fish_shadow_geo_0x301b5e0_custom.rgba16.inc.c"
};
