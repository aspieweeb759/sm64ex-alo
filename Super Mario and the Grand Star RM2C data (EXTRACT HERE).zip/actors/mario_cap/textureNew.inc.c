ALIGNED8 u8 marios_winged_metal_cap_geo__texture_0301CF50[] = {
#include "actors/mario_cap/marios_winged_metal_cap_geo_0x301cf50_custom.rgba16.inc.c"
};
ALIGNED8 u8 marios_winged_metal_cap_geo__texture_03020750[] = {
#include "actors/mario_cap/marios_winged_metal_cap_geo_0x3020750_custom.rgba16.inc.c"
};
ALIGNED8 u8 marios_winged_metal_cap_geo__texture_03021750[] = {
#include "actors/mario_cap/marios_winged_metal_cap_geo_0x3021750_custom.rgba16.inc.c"
};
ALIGNED8 u8 marios_wing_cap_geo__texture_0301DF50[] = {
#include "actors/mario_cap/marios_wing_cap_geo_0x301df50_custom.rgba16.inc.c"
};
ALIGNED8 u8 marios_wing_cap_geo__texture_0301E750[] = {
#include "actors/mario_cap/marios_wing_cap_geo_0x301e750_custom.rgba16.inc.c"
};
ALIGNED8 u8 marios_wing_cap_geo__texture_0301F750[] = {
#include "actors/mario_cap/marios_wing_cap_geo_0x301f750_custom.rgba16.inc.c"
};
