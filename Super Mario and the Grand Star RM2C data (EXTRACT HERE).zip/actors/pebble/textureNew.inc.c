ALIGNED8 u8 pebble_seg3_dl_0301CB00__texture_0301C300[] = {
#include "actors/pebble/pebble_seg3_dl_0301CB00_0x301c300_custom.rgba16.inc.c"
};
