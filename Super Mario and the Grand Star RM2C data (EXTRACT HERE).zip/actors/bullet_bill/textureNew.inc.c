ALIGNED8 u8 bullet_bill_geo__texture_0500BAA8[] = {
#include "actors/bullet_bill/bullet_bill_geo_0x500baa8_custom.rgba16.inc.c"
};
ALIGNED8 u8 bullet_bill_geo__texture_0500CAA8[] = {
#include "actors/bullet_bill/bullet_bill_geo_0x500caa8_custom.rgba16.inc.c"
};
