#include "custom.model.inc.h"
const GeoLayout koopa_shell_geo[]= {
GEO_SHADOW(1,200,70),
GEO_OPEN_NODE(),
GEO_SCALE(0,65536),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_koopa_shell_geo_0x8028b78),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
