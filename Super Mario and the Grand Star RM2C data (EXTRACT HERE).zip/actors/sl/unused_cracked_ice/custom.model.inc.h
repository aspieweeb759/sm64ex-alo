#ifndef sl_unused_cracked_ice_model_HEADER_H
#define sl_unused_cracked_ice_model_HEADER_H
#include "types.h"
extern Vtx VB_sl_geo_000360_0x700a808[];
extern u8 sl_geo_000360__texture_07001000[];
extern Light_t Light_sl_geo_000360_0x700a7f8;
extern Ambient_t Light_sl_geo_000360_0x700a7f0;
extern Gfx DL_sl_geo_000360_0x700a890[];
extern Gfx DL_sl_geo_000360_0x700a848[];
#endif