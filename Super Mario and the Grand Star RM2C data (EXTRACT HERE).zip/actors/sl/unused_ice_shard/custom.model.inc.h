#ifndef sl_unused_ice_shard_model_HEADER_H
#define sl_unused_ice_shard_model_HEADER_H
#include "types.h"
extern Vtx VB_sl_geo_000378_0x700a928[];
extern Light_t Light_sl_geo_000378_0x700a918;
extern Ambient_t Light_sl_geo_000378_0x700a910;
extern Gfx DL_sl_geo_000378_0x700a980[];
extern Gfx DL_sl_geo_000378_0x700a958[];
#endif