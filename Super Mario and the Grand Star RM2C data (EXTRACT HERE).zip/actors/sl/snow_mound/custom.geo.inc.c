#include "custom.model.inc.h"
const GeoLayout sl_geo_000390[]= {
GEO_CULLING_RADIUS(350),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_sl_geo_000390_0x700a780),
GEO_CLOSE_NODE(),
GEO_END(),
};
