#ifndef sl_snow_mound_model_HEADER_H
#define sl_snow_mound_model_HEADER_H
#include "types.h"
extern Vtx VB_sl_geo_000390_0x700a638[];
extern u8 sl_geo_000390__texture_09008800[];
extern Light_t Light_sl_geo_000390_0x700a628;
extern Ambient_t Light_sl_geo_000390_0x700a620;
extern Gfx DL_sl_geo_000390_0x700a780[];
extern Gfx DL_sl_geo_000390_0x700a718[];
#endif