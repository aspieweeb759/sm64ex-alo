#include "custom.model.inc.h"
Vtx VB_mr_blizzard_geo_0x500c488[] = {
{{{ -23, 1, -6 }, 0, { 0, 0 }, { 130, 253, 253, 255}}},
{{{ 76, -17, -6 }, 0, { 0, 0 }, { 234, 132, 249, 255}}},
{{{ 75, 15, 15 }, 0, { 0, 0 }, { 225, 54, 110, 255}}},
{{{ 75, 17, -23 }, 0, { 0, 0 }, { 228, 66, 153, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500c530[] = {
{{{ 0, 76, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -76, -76, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -76, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -76, 76, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500c570[] = {
{{{ 76, 76, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -76, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 76, -76, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 76, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500c698[] = {
{{{ 69, 191, -132 }, 0, { -370, -440 }, { 255, 255, 255, 255}}},
{{{ -63, 230, 0 }, 0, { 1472, 1328 }, { 255, 255, 255, 255}}},
{{{ 69, 230, 0 }, 0, { 1472, -440 }, { 255, 255, 255, 255}}},
{{{ -63, 191, -132 }, 0, { -370, 1328 }, { 255, 255, 255, 255}}},
{{{ 69, 230, 0 }, 0, { -370, -440 }, { 255, 255, 255, 255}}},
{{{ -63, 191, 133 }, 0, { 1472, 1328 }, { 255, 255, 255, 255}}},
{{{ 69, 191, 133 }, 0, { 1472, -440 }, { 255, 255, 255, 255}}},
{{{ -63, 230, 0 }, 0, { -370, 1328 }, { 255, 255, 255, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500c7e8[] = {
{{{ 3, -44, -24 }, 0, { 672, 1148 }, { 193, 185, 173, 255}}},
{{{ 105, -63, -17 }, 0, { 720, 626 }, { 49, 202, 153, 255}}},
{{{ 116, -101, 11 }, 0, { 888, 570 }, { 45, 140, 235, 255}}},
{{{ -4, 4, -29 }, 0, { 458, 1184 }, { 173, 3, 161, 255}}},
{{{ 96, -30, -36 }, 0, { 578, 662 }, { 30, 222, 138, 255}}},
{{{ 97, 16, -36 }, 0, { 364, 654 }, { 19, 42, 138, 255}}},
{{{ 208, -42, 25 }, 0, { 588, 84 }, { 87, 168, 25, 255}}},
{{{ 128, -61, 9 }, 0, { 704, 502 }, { 105, 191, 27, 255}}},
{{{ 57, -20, 36 }, 0, { 546, 864 }, { 2, 248, 126, 255}}},
{{{ 132, 90, 32 }, 0, { 20, 460 }, { 19, 82, 94, 255}}},
{{{ 215, 42, 28 }, 0, { 206, 34 }, { 69, 64, 172, 255}}},
{{{ 69, -56, 36 }, 0, { 704, 810 }, { 4, 232, 124, 255}}},
{{{ -2, 45, -14 }, 0, { 270, 1168 }, { 161, 66, 206, 255}}},
{{{ 33, 83, 26 }, 0, { 88, 974 }, { 205, 114, 15, 255}}},
{{{ 107, 63, -2 }, 0, { 148, 596 }, { 15, 82, 161, 255}}},
{{{ 36, -86, 11 }, 0, { 850, 988 }, { 189, 168, 61, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500c8e8[] = {
{{{ 69, -56, 36 }, 0, { 704, 810 }, { 4, 232, 124, 255}}},
{{{ 57, -20, 36 }, 0, { 546, 864 }, { 2, 248, 126, 255}}},
{{{ 6, 0, 28 }, 0, { 472, 1124 }, { 163, 245, 85, 255}}},
{{{ 33, 83, 26 }, 0, { 88, 974 }, { 205, 114, 15, 255}}},
{{{ -4, 4, -29 }, 0, { 458, 1184 }, { 173, 3, 161, 255}}},
{{{ 3, -44, -24 }, 0, { 672, 1148 }, { 193, 185, 173, 255}}},
{{{ -2, 45, -14 }, 0, { 270, 1168 }, { 161, 66, 206, 255}}},
{{{ 36, -86, 11 }, 0, { 850, 988 }, { 189, 168, 61, 255}}},
{{{ 116, -101, 11 }, 0, { 888, 570 }, { 45, 140, 235, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500cb08[] = {
{{{ 0, 57, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -57, -57, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -57, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -57, 57, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500cb48[] = {
{{{ 57, 57, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -57, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 57, -57, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 57, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_mr_blizzard_geo_0x500cc70[] = {
{{{ -90, 210, -56 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -134, 182, -56 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ -134, 182, 57 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ -90, 210, 57 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
};

Gfx DL_mr_blizzard_hidden_geo_0x500c620[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500c5b0),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500c5e8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500c5b0[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_05009470),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500c530, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500c5e8[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_0500A470),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500c570, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500cbf8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500cb88),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500cbc0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500cb88[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_05009470),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500cb08, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500cbc0[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_0500A470),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500cb48, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500cce8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500ccb0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500ccb0[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_0500BC70),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500cc70, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500c760[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500c718),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500c718[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_0500B470),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500c698, 8, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(4, 5, 6, 0,4, 7, 5, 0),
gsSPEndDisplayList(),
};

Light_t Light_mr_blizzard_hidden_geo_0x500c478 = {
{ 56, 30, 14}, 0, { 56, 30, 14}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mr_blizzard_hidden_geo_0x500c470 = {
{28, 15, 7}, 0, {28, 15, 7}, 0
};

Gfx DL_mr_blizzard_hidden_geo_0x500c500[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500c4c8),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500c4c8[] = {
gsSPLight(&Light_mr_blizzard_hidden_geo_0x500c478.col, 1),
gsSPLight(&Light_mr_blizzard_hidden_geo_0x500c470.col, 2),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500c488, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP1Triangle(0, 3, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_mr_blizzard_hidden_geo_0x500c7d8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mr_blizzard_hidden_geo_0x500c7d0 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_mr_blizzard_hidden_geo_0x500caa8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_mr_blizzard_hidden_geo_0x500c978),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_mr_blizzard_hidden_geo_0x500c978[] = {
gsDPSetTextureImage(0, 2, 1, mr_blizzard_hidden_geo__texture_05008C70),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_mr_blizzard_hidden_geo_0x500c7d8.col, 1),
gsSPLight(&Light_mr_blizzard_hidden_geo_0x500c7d0.col, 2),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500c7e8, 16, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 4, 0),
gsSP2Triangles(4, 1, 0, 0,5, 4, 3, 0),
gsSP2Triangles(5, 6, 4, 0,4, 6, 7, 0),
gsSP2Triangles(7, 1, 4, 0,7, 6, 8, 0),
gsSP2Triangles(9, 8, 6, 0,9, 6, 10, 0),
gsSP2Triangles(5, 10, 6, 0,7, 2, 1, 0),
gsSP2Triangles(8, 11, 7, 0,11, 2, 7, 0),
gsSP2Triangles(5, 12, 13, 0,13, 14, 5, 0),
gsSP2Triangles(5, 3, 12, 0,5, 14, 10, 0),
gsSP2Triangles(10, 14, 9, 0,13, 9, 14, 0),
gsSP2Triangles(8, 9, 13, 0,2, 15, 0, 0),
gsSPVertex(VB_mr_blizzard_hidden_geo_0x500c8e8, 9, 0),
gsSP2Triangles(0, 1, 2, 0,3, 2, 1, 0),
gsSP2Triangles(4, 5, 2, 0,2, 6, 4, 0),
gsSP2Triangles(2, 5, 7, 0,0, 2, 7, 0),
gsSP2Triangles(3, 6, 2, 0,7, 8, 0, 0),
gsSPEndDisplayList(),
};

