#include "custom.model.inc.h"
const GeoLayout castle_geo_000F00[]= {
GEO_CULLING_RADIUS(400),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_geo_000F00_0x703bfa8),
GEO_CLOSE_NODE(),
GEO_END(),
};
