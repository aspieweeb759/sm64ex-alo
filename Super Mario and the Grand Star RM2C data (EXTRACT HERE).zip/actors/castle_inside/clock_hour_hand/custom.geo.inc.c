#include "custom.model.inc.h"
const GeoLayout castle_geo_001548[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_geo_001548_0x7059190),
GEO_CLOSE_NODE(),
GEO_END(),
};
