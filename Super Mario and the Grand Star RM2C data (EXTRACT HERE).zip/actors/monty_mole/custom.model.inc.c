#include "custom.model.inc.h"
Vtx VB_monty_mole_geo_0x5003188[] = {
{{{ 85, -12, -77 }, 0, { -6, 778 }, { 33, 151, 194, 255}}},
{{{ -13, -8, 32 }, 0, { 348, 972 }, { 160, 194, 54, 255}}},
{{{ -13, -8, -24 }, 0, { 150, 978 }, { 153, 40, 195, 255}}},
{{{ -3, 7, 23 }, 0, { 320, 950 }, { 189, 99, 40, 255}}},
{{{ -3, 7, -18 }, 0, { 176, 956 }, { 207, 114, 233, 255}}},
{{{ 78, 15, -63 }, 0, { 38, 790 }, { 35, 107, 199, 255}}},
{{{ 85, -12, 81 }, 0, { 540, 758 }, { 68, 63, 85, 255}}},
{{{ 75, 7, 58 }, 0, { 458, 782 }, { 18, 121, 30, 255}}},
};

Vtx VB_monty_mole_geo_0x5003318[] = {
{{{ 80, 10, 54 }, 0, { 3144, 202 }, { 23, 99, 74, 255}}},
{{{ 133, 10, 13 }, 0, { 1908, 982 }, { 119, 247, 41, 255}}},
{{{ 79, 10, -41 }, 0, { -148, 212 }, { 17, 97, 177, 255}}},
{{{ 133, 10, -14 }, 0, { 948, 982 }, { 95, 233, 177, 255}}},
{{{ 79, 10, -41 }, 0, { 2864, 188 }, { 17, 97, 177, 255}}},
{{{ 133, 10, -14 }, 0, { 2014, 954 }, { 95, 233, 177, 255}}},
{{{ 97, -15, -19 }, 0, { 2068, 162 }, { 31, 146, 204, 255}}},
{{{ 133, 10, 13 }, 0, { 1096, 982 }, { 119, 247, 41, 255}}},
{{{ 98, -18, 18 }, 0, { 820, 170 }, { 22, 140, 45, 255}}},
{{{ 80, 10, 54 }, 0, { -294, 274 }, { 23, 99, 74, 255}}},
};

Vtx VB_monty_mole_geo_0x50033b8[] = {
{{{ -4, 10, 36 }, 0, { 1044, 680 }, { 208, 218, 110, 255}}},
{{{ 98, -18, 18 }, 0, { 780, 984 }, { 22, 140, 45, 255}}},
{{{ 80, 10, 54 }, 0, { 896, 934 }, { 23, 99, 74, 255}}},
{{{ 79, 10, -41 }, 0, { 694, 926 }, { 17, 97, 177, 255}}},
{{{ -4, 10, -34 }, 0, { 896, 674 }, { 217, 43, 144, 255}}},
{{{ 97, -15, -19 }, 0, { 700, 980 }, { 31, 146, 204, 255}}},
{{{ -46, 10, 1 }, 0, { 1064, 552 }, { 160, 174, 254, 255}}},
{{{ -4, -9, 0 }, 0, { 970, 678 }, { 225, 133, 253, 255}}},
};

Vtx VB_monty_mole_geo_0x50035b0[] = {
{{{ 69, -15, 58 }, 0, { -562, 834 }, { 100, 3, 77, 255}}},
{{{ 48, 21, 0 }, 0, { 1416, 262 }, { 59, 110, 239, 255}}},
{{{ 38, 13, 47 }, 0, { -42, 224 }, { 30, 107, 60, 255}}},
{{{ 83, -16, 0 }, 0, { 1140, 1008 }, { 122, 30, 245, 255}}},
{{{ 69, -15, -31 }, 0, { 2066, 864 }, { 58, 157, 204, 255}}},
{{{ 4, -12, -76 }, 0, { 3424, 196 }, { 6, 224, 134, 255}}},
{{{ 69, -15, -31 }, 0, { -174, 804 }, { 58, 157, 204, 255}}},
{{{ 69, -15, 58 }, 0, { 2602, 774 }, { 100, 3, 77, 255}}},
{{{ 4, -12, 82 }, 0, { 3316, 82 }, { 205, 168, 75, 255}}},
{{{ 83, -16, 0 }, 0, { 808, 950 }, { 122, 30, 245, 255}}},
{{{ 4, -12, -76 }, 0, { -1640, 128 }, { 6, 224, 134, 255}}},
{{{ 4, -12, 82 }, 0, { -1266, 142 }, { 205, 168, 75, 255}}},
};

Vtx VB_monty_mole_geo_0x5003670[] = {
{{{ -21, -2, -55 }, 0, { 1006, 906 }, { 147, 208, 214, 255}}},
{{{ -3, 15, -63 }, 0, { 986, 942 }, { 211, 110, 213, 255}}},
{{{ 4, -12, -76 }, 0, { 1000, 962 }, { 6, 224, 134, 255}}},
{{{ 48, 21, 0 }, 0, { 762, 994 }, { 59, 110, 239, 255}}},
{{{ -5, 8, 58 }, 0, { 748, 864 }, { 211, 111, 40, 255}}},
{{{ -21, -2, 39 }, 0, { 816, 848 }, { 140, 43, 27, 255}}},
{{{ 38, 13, 47 }, 0, { 686, 950 }, { 30, 107, 60, 255}}},
{{{ 4, -12, 82 }, 0, { 682, 868 }, { 205, 168, 75, 255}}},
{{{ -21, -2, 39 }, 0, { 836, 598 }, { 140, 43, 27, 255}}},
{{{ -21, -2, -55 }, 0, { 584, 594 }, { 147, 208, 214, 255}}},
{{{ 4, -12, 82 }, 0, { 946, 700 }, { 205, 168, 75, 255}}},
{{{ 4, -12, -76 }, 0, { 524, 694 }, { 6, 224, 134, 255}}},
};

Vtx VB_monty_mole_geo_0x50038b8[] = {
{{{ -3, 7, -22 }, 0, { 234, 806 }, { 210, 115, 229, 255}}},
{{{ -3, 7, 19 }, 0, { 80, 810 }, { 178, 88, 46, 255}}},
{{{ 78, 15, 64 }, 0, { 34, 970 }, { 17, 121, 34, 255}}},
{{{ -13, -8, -31 }, 0, { 250, 786 }, { 160, 58, 199, 255}}},
{{{ -13, -8, 25 }, 0, { 40, 792 }, { 162, 191, 54, 255}}},
{{{ 85, -12, 78 }, 0, { -4, 984 }, { 64, 37, 103, 255}}},
{{{ 75, 7, -57 }, 0, { 480, 952 }, { 42, 106, 203, 255}}},
{{{ 85, -12, -80 }, 0, { 582, 968 }, { 51, 165, 185, 255}}},
};

Vtx VB_monty_mole_geo_0x5003a48[] = {
{{{ 79, 10, 42 }, 0, { -148, 212 }, { 17, 97, 79, 255}}},
{{{ 133, 10, 15 }, 0, { 948, 982 }, { 95, 233, 79, 255}}},
{{{ 133, 10, -12 }, 0, { 1908, 982 }, { 119, 247, 215, 255}}},
{{{ 80, 10, -53 }, 0, { 3144, 202 }, { 23, 99, 182, 255}}},
{{{ 80, 10, -53 }, 0, { -294, 274 }, { 23, 99, 182, 255}}},
{{{ 133, 10, -12 }, 0, { 1096, 982 }, { 119, 247, 215, 255}}},
{{{ 98, -18, -17 }, 0, { 820, 170 }, { 22, 140, 211, 255}}},
{{{ 97, -15, 20 }, 0, { 2068, 162 }, { 31, 145, 52, 255}}},
{{{ 133, 10, 15 }, 0, { 2014, 954 }, { 95, 233, 79, 255}}},
{{{ 79, 10, 42 }, 0, { 2864, 188 }, { 17, 97, 79, 255}}},
};

Vtx VB_monty_mole_geo_0x5003ae8[] = {
{{{ -4, 10, -35 }, 0, { 838, 786 }, { 208, 219, 145, 255}}},
{{{ -46, 10, 0 }, 0, { 948, 720 }, { 160, 174, 0, 255}}},
{{{ -4, 10, 35 }, 0, { 970, 808 }, { 217, 43, 112, 255}}},
{{{ -4, -9, 0 }, 0, { 904, 798 }, { 225, 133, 2, 255}}},
{{{ 79, 10, 42 }, 0, { 894, 962 }, { 17, 97, 79, 255}}},
{{{ 80, 10, -53 }, 0, { 714, 930 }, { 23, 99, 182, 255}}},
{{{ 97, -15, 20 }, 0, { 834, 986 }, { 31, 145, 52, 255}}},
{{{ 98, -18, -17 }, 0, { 764, 974 }, { 22, 140, 211, 255}}},
};

Vtx VB_monty_mole_geo_0x5003ce0[] = {
{{{ 4, -12, 77 }, 0, { 3424, 196 }, { 6, 224, 122, 255}}},
{{{ 69, -15, 32 }, 0, { 2066, 864 }, { 58, 157, 51, 255}}},
{{{ 48, 21, 0 }, 0, { 1416, 262 }, { 59, 110, 16, 255}}},
{{{ 83, -16, 0 }, 0, { 1140, 1008 }, { 122, 31, 10, 255}}},
{{{ 38, 13, -46 }, 0, { -42, 224 }, { 30, 107, 196, 255}}},
{{{ 69, -15, -57 }, 0, { -562, 834 }, { 100, 3, 179, 255}}},
{{{ 4, -12, -81 }, 0, { 3368, 64 }, { 205, 168, 181, 255}}},
{{{ 69, -15, -57 }, 0, { 2592, 812 }, { 100, 3, 179, 255}}},
{{{ 69, -15, 32 }, 0, { -302, 824 }, { 58, 157, 51, 255}}},
{{{ 4, -12, 77 }, 0, { -1800, 78 }, { 6, 224, 122, 255}}},
{{{ 83, -16, 0 }, 0, { 714, 990 }, { 122, 31, 10, 255}}},
{{{ 4, -12, -81 }, 0, { -1266, 142 }, { 205, 168, 181, 255}}},
};

Vtx VB_monty_mole_geo_0x5003da0[] = {
{{{ 48, 21, 0 }, 0, { 700, 872 }, { 59, 110, 16, 255}}},
{{{ 38, 13, -46 }, 0, { 818, 856 }, { 30, 107, 196, 255}}},
{{{ -5, 8, -57 }, 0, { 898, 758 }, { 211, 111, 216, 255}}},
{{{ -3, 15, 64 }, 0, { 620, 748 }, { 211, 110, 43, 255}}},
{{{ 4, -12, 77 }, 0, { 582, 764 }, { 6, 224, 122, 255}}},
{{{ -21, -2, 56 }, 0, { 660, 708 }, { 147, 208, 42, 255}}},
{{{ -21, -2, -38 }, 0, { 872, 720 }, { 140, 43, 229, 255}}},
{{{ 4, -12, -81 }, 0, { 938, 784 }, { 205, 168, 181, 255}}},
{{{ 4, -12, -81 }, 0, { 382, 662 }, { 205, 168, 181, 255}}},
{{{ -21, -2, 56 }, 0, { 660, 550 }, { 147, 208, 42, 255}}},
{{{ -21, -2, -38 }, 0, { 482, 580 }, { 140, 43, 229, 255}}},
{{{ 4, -12, 77 }, 0, { 680, 608 }, { 6, 224, 122, 255}}},
};

Vtx VB_monty_mole_geo_0x5003fe8[] = {
{{{ -39, 52, 94 }, 0, { 1068, 880 }, { 202, 37, 108, 255}}},
{{{ -6, 97, 52 }, 0, { 806, 668 }, { 246, 114, 53, 255}}},
{{{ -59, 66, 46 }, 0, { 756, 1006 }, { 150, 66, 19, 255}}},
{{{ -6, 97, -51 }, 0, { 132, 676 }, { 243, 120, 218, 255}}},
{{{ 58, 82, -37 }, 0, { 234, 258 }, { 66, 96, 209, 255}}},
{{{ 33, 47, -88 }, 0, { -96, 426 }, { 35, 42, 142, 255}}},
{{{ -39, 52, -93 }, 0, { -136, 894 }, { 206, 54, 153, 255}}},
{{{ 109, -4, -55 }, 0, { 122, -68 }, { 99, 254, 178, 255}}},
{{{ -59, 66, -45 }, 0, { 170, 1012 }, { 147, 51, 218, 255}}},
{{{ 58, 82, 38 }, 0, { 718, 252 }, { 61, 103, 40, 255}}},
{{{ 109, 46, 0 }, 0, { 482, -72 }, { 115, 53, 0, 255}}},
{{{ 33, 47, 89 }, 0, { 1044, 414 }, { 40, 50, 109, 255}}},
{{{ 109, -4, 56 }, 0, { 840, -76 }, { 99, 254, 78, 255}}},
};

Vtx VB_monty_mole_geo_0x50040b8[] = {
{{{ 5, -97, 36 }, 0, { 564, 746 }, { 29, 150, 63, 255}}},
{{{ 33, -45, 89 }, 0, { 514, 820 }, { 31, 209, 113, 255}}},
{{{ -38, -44, 92 }, 0, { 512, 824 }, { 204, 202, 101, 255}}},
{{{ 109, -4, -55 }, 0, { 474, 710 }, { 99, 254, 178, 255}}},
{{{ 109, -51, 0 }, 0, { 520, 736 }, { 113, 199, 0, 255}}},
{{{ 59, -84, -30 }, 0, { 552, 692 }, { 52, 155, 200, 255}}},
{{{ 59, -84, 31 }, 0, { 552, 748 }, { 57, 150, 39, 255}}},
{{{ 109, -4, 56 }, 0, { 474, 812 }, { 99, 254, 78, 255}}},
{{{ 109, 46, 0 }, 0, { 426, 786 }, { 115, 53, 0, 255}}},
{{{ 33, -45, -88 }, 0, { 514, 660 }, { 36, 207, 145, 255}}},
{{{ 33, 47, -88 }, 0, { 424, 708 }, { 35, 42, 142, 255}}},
{{{ 33, 47, 89 }, 0, { 424, 868 }, { 40, 50, 109, 255}}},
{{{ -39, 52, 94 }, 0, { 418, 874 }, { 202, 37, 108, 255}}},
{{{ -41, -98, 39 }, 0, { 564, 748 }, { 155, 198, 48, 255}}},
{{{ -46, -140, 0 }, 0, { 606, 692 }, { 242, 130, 0, 255}}},
{{{ 5, -97, -35 }, 0, { 564, 680 }, { 34, 146, 205, 255}}},
};

Vtx VB_monty_mole_geo_0x50041b8[] = {
{{{ -38, -44, -91 }, 0, { 514, 658 }, { 210, 207, 149, 255}}},
{{{ 59, -84, -30 }, 0, { 552, 692 }, { 52, 155, 200, 255}}},
{{{ 5, -97, -35 }, 0, { 564, 680 }, { 34, 146, 205, 255}}},
{{{ 33, -45, -88 }, 0, { 514, 660 }, { 36, 207, 145, 255}}},
{{{ 33, 47, -88 }, 0, { 424, 708 }, { 35, 42, 142, 255}}},
{{{ -39, 52, -93 }, 0, { 420, 706 }, { 206, 54, 153, 255}}},
{{{ -41, -98, -38 }, 0, { 566, 678 }, { 164, 194, 196, 255}}},
{{{ -67, -12, -40 }, 0, { 482, 720 }, { 132, 243, 238, 255}}},
{{{ -59, 66, -45 }, 0, { 406, 756 }, { 147, 51, 218, 255}}},
{{{ 5, -97, 36 }, 0, { 564, 746 }, { 29, 150, 63, 255}}},
{{{ -46, -140, 0 }, 0, { 606, 692 }, { 242, 130, 0, 255}}},
{{{ -41, -98, 39 }, 0, { 564, 748 }, { 155, 198, 48, 255}}},
{{{ -59, 66, 46 }, 0, { 406, 838 }, { 150, 66, 19, 255}}},
{{{ -38, -44, 92 }, 0, { 512, 824 }, { 204, 202, 101, 255}}},
{{{ -67, -12, 41 }, 0, { 482, 794 }, { 134, 245, 32, 255}}},
{{{ -39, 52, 94 }, 0, { 418, 874 }, { 202, 37, 108, 255}}},
};

Vtx VB_monty_mole_geo_0x5004530[] = {
{{{ 48, 140, 0 }, 0, { 474, 386 }, { 27, 124, 0, 255}}},
{{{ 57, 101, 0 }, 0, { 472, 156 }, { 94, 84, 0, 255}}},
{{{ 34, 99, -34 }, 0, { 96, 420 }, { 35, 86, 170, 255}}},
{{{ 2, 111, 11 }, 0, { 600, 742 }, { 201, 101, 52, 255}}},
{{{ 2, 111, -10 }, 0, { 352, 764 }, { 191, 99, 212, 255}}},
{{{ 34, 99, 35 }, 0, { 852, 352 }, { 35, 86, 85, 255}}},
};

Vtx VB_monty_mole_geo_0x5004590[] = {
{{{ 34, 99, -34 }, 0, { 404, 956 }, { 35, 86, 170, 255}}},
{{{ 57, 101, 0 }, 0, { -182, 680 }, { 94, 84, 0, 255}}},
{{{ 100, 66, -27 }, 0, { 244, -20 }, { 83, 82, 208, 255}}},
{{{ 63, 34, -76 }, 0, { 1210, 238 }, { 60, 31, 150, 255}}},
{{{ 34, 99, 35 }, 0, { 334, 944 }, { 35, 86, 85, 255}}},
{{{ 63, 34, 77 }, 0, { 1304, 266 }, { 60, 44, 102, 255}}},
{{{ 100, 66, 28 }, 0, { 306, 26 }, { 90, 78, 40, 255}}},
{{{ 57, 101, 0 }, 0, { -212, 636 }, { 94, 84, 0, 255}}},
{{{ 100, 66, 28 }, 0, { 288, 356 }, { 90, 78, 40, 255}}},
{{{ 100, 66, -27 }, 0, { 176, 356 }, { 83, 82, 208, 255}}},
{{{ 57, 101, 0 }, 0, { 206, 400 }, { 94, 84, 0, 255}}},
{{{ 118, 28, -28 }, 0, { 204, 308 }, { 119, 27, 223, 255}}},
{{{ 118, 28, 29 }, 0, { 318, 308 }, { 109, 23, 59, 255}}},
{{{ 63, 34, 77 }, 0, { 408, 316 }, { 60, 44, 102, 255}}},
{{{ 63, 34, -76 }, 0, { 102, 316 }, { 60, 31, 150, 255}}},
{{{ 118, -22, 29 }, 0, { 356, 246 }, { 113, 207, 27, 255}}},
};

Vtx VB_monty_mole_geo_0x5004690[] = {
{{{ 118, 28, -28 }, 0, { 204, 308 }, { 119, 27, 223, 255}}},
{{{ 118, -22, 29 }, 0, { 356, 246 }, { 113, 207, 27, 255}}},
{{{ 118, -22, -28 }, 0, { 240, 246 }, { 107, 220, 200, 255}}},
{{{ 63, 34, -76 }, 0, { 102, 316 }, { 60, 31, 150, 255}}},
{{{ 71, -36, 77 }, 0, { 462, 228 }, { 62, 226, 106, 255}}},
{{{ 118, 28, 29 }, 0, { 318, 308 }, { 109, 23, 59, 255}}},
{{{ 63, 34, 77 }, 0, { 408, 316 }, { 60, 44, 102, 255}}},
{{{ -4, -80, 47 }, 0, { 434, 174 }, { 214, 141, 30, 255}}},
{{{ -7, -37, 94 }, 0, { 496, 228 }, { 229, 193, 106, 255}}},
{{{ -35, -41, 55 }, 0, { 422, 222 }, { 145, 223, 50, 255}}},
{{{ 0, 44, 94 }, 0, { 436, 330 }, { 231, 48, 114, 255}}},
{{{ 69, -67, 40 }, 0, { 412, 190 }, { 51, 151, 48, 255}}},
{{{ -7, -37, -93 }, 0, { 122, 228 }, { 217, 223, 141, 255}}},
{{{ 0, 44, -93 }, 0, { 60, 330 }, { 240, 64, 148, 255}}},
{{{ 69, -67, -39 }, 0, { 252, 190 }, { 58, 147, 232, 255}}},
{{{ -4, -80, -46 }, 0, { 248, 174 }, { 230, 145, 202, 255}}},
};

Vtx VB_monty_mole_geo_0x5004790[] = {
{{{ -35, -41, -54 }, 0, { 202, 222 }, { 140, 213, 231, 255}}},
{{{ -4, -80, -46 }, 0, { 248, 174 }, { 230, 145, 202, 255}}},
{{{ -4, -80, 47 }, 0, { 434, 174 }, { 214, 141, 30, 255}}},
{{{ -35, -41, 55 }, 0, { 422, 222 }, { 145, 223, 50, 255}}},
{{{ 118, -22, 29 }, 0, { 356, 246 }, { 113, 207, 27, 255}}},
{{{ 69, -67, -39 }, 0, { 252, 190 }, { 58, 147, 232, 255}}},
{{{ 118, -22, -28 }, 0, { 240, 246 }, { 107, 220, 200, 255}}},
{{{ 71, -36, -76 }, 0, { 156, 228 }, { 55, 200, 157, 255}}},
{{{ 63, 34, -76 }, 0, { 102, 316 }, { 60, 31, 150, 255}}},
{{{ -7, -37, -93 }, 0, { 122, 228 }, { 217, 223, 141, 255}}},
};

Vtx VB_monty_mole_geo_0x5004830[] = {
{{{ 2, 111, -10 }, 0, { 898, 558 }, { 191, 99, 212, 255}}},
{{{ 0, 44, -93 }, 0, { -8, 556 }, { 240, 64, 148, 255}}},
{{{ -36, 61, -57 }, 0, { 302, 130 }, { 151, 41, 200, 255}}},
{{{ 34, 99, -34 }, 0, { 696, 928 }, { 35, 86, 170, 255}}},
{{{ 0, 44, 94 }, 0, { 940, 652 }, { 231, 48, 114, 255}}},
{{{ 2, 111, 11 }, 0, { 110, 590 }, { 201, 101, 52, 255}}},
{{{ -36, 61, 58 }, 0, { 714, 246 }, { 143, 47, 32, 255}}},
{{{ 34, 99, 35 }, 0, { 244, 938 }, { 35, 86, 85, 255}}},
{{{ 63, 34, 77 }, 0, { 764, 1264 }, { 60, 44, 102, 255}}},
{{{ 63, 34, -76 }, 0, { 82, 1240 }, { 60, 31, 150, 255}}},
{{{ -7, -37, -93 }, 0, { 60, 1826 }, { 217, 223, 141, 255}}},
{{{ -35, -41, -54 }, 0, { 244, 1890 }, { 140, 213, 231, 255}}},
{{{ -36, 61, -57 }, 0, { 186, 412 }, { 151, 41, 200, 255}}},
{{{ 0, 44, -93 }, 0, { 20, 646 }, { 240, 64, 148, 255}}},
{{{ -36, 61, 58 }, 0, { 742, 440 }, { 143, 47, 32, 255}}},
{{{ -35, -41, 55 }, 0, { 772, 1916 }, { 145, 223, 50, 255}}},
};

Vtx VB_monty_mole_geo_0x5004930[] = {
{{{ 0, 44, 94 }, 0, { 922, 692 }, { 231, 48, 114, 255}}},
{{{ -35, -41, 55 }, 0, { 772, 1916 }, { 145, 223, 50, 255}}},
{{{ -7, -37, 94 }, 0, { 952, 1870 }, { 229, 193, 106, 255}}},
{{{ -36, 61, 58 }, 0, { 742, 440 }, { 143, 47, 32, 255}}},
};

Vtx VB_monty_mole_geo_0x5004970[] = {
{{{ -36, 61, 58 }, 0, { 0, 0 }, { 143, 47, 32, 255}}},
{{{ 2, 111, 11 }, 0, { 0, 0 }, { 201, 101, 52, 255}}},
{{{ 2, 111, -10 }, 0, { 0, 0 }, { 191, 99, 212, 255}}},
{{{ -36, 61, -57 }, 0, { 0, 0 }, { 151, 41, 200, 255}}},
};

Vtx VB_monty_mole_geo_0x5004ca8[] = {
{{{ 3, 99, -25 }, 0, { -154, -14 }, { 237, 125, 0, 255}}},
{{{ -42, 92, -12 }, 0, { 160, 980 }, { 237, 125, 0, 255}}},
{{{ -42, 92, 13 }, 0, { 800, 978 }, { 237, 125, 0, 255}}},
{{{ 3, 99, 26 }, 0, { 1092, -18 }, { 237, 125, 0, 255}}},
};

Light_t Light_monty_mole_geo_0x5003fd8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5003fd0 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x50044b0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x50042b8),
gsSPDisplayList(DL_monty_mole_geo_0x5004368),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x50042b8[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05000970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5003fd8.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5003fd0.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5003fe8, 13, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(5, 6, 3, 0,7, 5, 4, 0),
gsSP2Triangles(3, 6, 8, 0,2, 1, 3, 0),
gsSP2Triangles(2, 3, 8, 0,3, 1, 9, 0),
gsSP2Triangles(3, 9, 4, 0,4, 10, 7, 0),
gsSP2Triangles(10, 4, 9, 0,9, 11, 12, 0),
gsSP2Triangles(12, 10, 9, 0,11, 9, 1, 0),
gsSP1Triangle(11, 1, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5004368[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x50040b8, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 4, 7, 0,4, 3, 8, 0),
gsSP2Triangles(8, 7, 4, 0,4, 6, 5, 0),
gsSP2Triangles(9, 10, 3, 0,5, 9, 3, 0),
gsSP2Triangles(7, 1, 6, 0,7, 11, 1, 0),
gsSP2Triangles(12, 2, 1, 0,12, 1, 11, 0),
gsSP2Triangles(0, 6, 1, 0,0, 13, 14, 0),
gsSP2Triangles(15, 6, 0, 0,15, 5, 6, 0),
gsSPVertex(VB_monty_mole_geo_0x50041b8, 16, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(0, 4, 3, 0,0, 5, 4, 0),
gsSP2Triangles(6, 7, 0, 0,0, 7, 8, 0),
gsSP2Triangles(0, 2, 6, 0,0, 8, 5, 0),
gsSP2Triangles(2, 9, 10, 0,10, 6, 2, 0),
gsSP2Triangles(6, 10, 11, 0,11, 7, 6, 0),
gsSP2Triangles(7, 12, 8, 0,13, 14, 11, 0),
gsSP2Triangles(11, 9, 13, 0,15, 14, 13, 0),
gsSP2Triangles(7, 14, 12, 0,11, 14, 7, 0),
gsSP1Triangle(15, 12, 14, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x5004520 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5004518 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x5004c00[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x50049b0),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5004a10),
gsSPDisplayList(DL_monty_mole_geo_0x5004b50),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_monty_mole_geo_0x5004be0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x50049b0[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5004520.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5004518.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5004530, 6, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 4, 0),
gsSP2Triangles(0, 3, 5, 0,5, 1, 0, 0),
gsSP1Triangle(2, 4, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5004a10[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x5004590, 16, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 0, 0),
gsSP2Triangles(4, 5, 6, 0,6, 7, 4, 0),
gsSP2Triangles(8, 9, 10, 0,11, 8, 12, 0),
gsSP2Triangles(12, 8, 13, 0,11, 9, 8, 0),
gsSP2Triangles(14, 9, 11, 0,11, 12, 15, 0),
gsSPVertex(VB_monty_mole_geo_0x5004690, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSP2Triangles(4, 1, 5, 0,4, 5, 6, 0),
gsSP2Triangles(7, 8, 9, 0,10, 8, 4, 0),
gsSP2Triangles(8, 7, 11, 0,8, 11, 4, 0),
gsSP2Triangles(4, 11, 1, 0,10, 4, 6, 0),
gsSP2Triangles(12, 13, 3, 0,7, 14, 11, 0),
gsSP2Triangles(1, 11, 14, 0,7, 15, 14, 0),
gsSPVertex(VB_monty_mole_geo_0x5004790, 10, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,6, 5, 7, 0),
gsSP2Triangles(7, 5, 1, 0,8, 6, 7, 0),
gsSP2Triangles(9, 8, 7, 0,7, 1, 9, 0),
gsSP1Triangle(9, 1, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5004b50[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05000970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x5004830, 16, 0),
gsSP2Triangles(0, 1, 2, 0,1, 0, 3, 0),
gsSP2Triangles(4, 5, 6, 0,7, 5, 4, 0),
gsSP2Triangles(4, 8, 7, 0,3, 9, 1, 0),
gsSP2Triangles(10, 11, 12, 0,10, 12, 13, 0),
gsSP2Triangles(11, 14, 12, 0,11, 15, 14, 0),
gsSPVertex(VB_monty_mole_geo_0x5004930, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5004be0[] = {
gsSPVertex(VB_monty_mole_geo_0x5004970, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x5004c98 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5004c90 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x5004d30[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_CULL_BACK|G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5004ce8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5004ce8[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05002170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5004c98.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5004c90.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5004ca8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x5003a38 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5003a30 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x5003c48[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003b68),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003bd0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003b68[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05002970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5003a38.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5003a30.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5003a48, 10, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,6, 5, 7, 0),
gsSP2Triangles(5, 8, 7, 0,7, 8, 9, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003bd0[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x5003ae8, 8, 0),
gsSP2Triangles(0, 1, 2, 0,2, 1, 3, 0),
gsSP2Triangles(2, 4, 5, 0,5, 0, 2, 0),
gsSP2Triangles(2, 3, 6, 0,6, 4, 2, 0),
gsSP2Triangles(5, 7, 0, 0,3, 1, 0, 0),
gsSP2Triangles(7, 3, 0, 0,3, 7, 6, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x5003308 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5003300 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x5003518[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003438),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x50034a0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003438[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05002970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5003308.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5003300.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5003318, 10, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSP2Triangles(4, 5, 6, 0,6, 5, 7, 0),
gsSP2Triangles(6, 7, 8, 0,8, 7, 9, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x50034a0[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x50033b8, 8, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 4, 0),
gsSP2Triangles(4, 0, 2, 0,4, 3, 5, 0),
gsSP2Triangles(4, 6, 0, 0,7, 6, 4, 0),
gsSP2Triangles(5, 7, 4, 0,0, 6, 7, 0),
gsSP2Triangles(0, 7, 1, 0,5, 1, 7, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x5003178 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5003170 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x50032a0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003208),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003208[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5003178.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5003170.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5003188, 8, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 4, 0),
gsSP2Triangles(2, 1, 3, 0,5, 2, 4, 0),
gsSP2Triangles(5, 0, 2, 0,6, 3, 1, 0),
gsSP2Triangles(6, 7, 3, 0,7, 4, 3, 0),
gsSP2Triangles(7, 5, 4, 0,0, 6, 1, 0),
gsSP2Triangles(5, 6, 0, 0,5, 7, 6, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x50035a0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5003598 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x5003820[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003730),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x50037a8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003730[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05002970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x50035a0.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5003598.col, 2),
gsSPVertex(VB_monty_mole_geo_0x50035b0, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(1, 3, 4, 0,1, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,6, 9, 7, 0),
gsSP2Triangles(8, 10, 6, 0,2, 11, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x50037a8[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x5003670, 12, 0),
gsSP2Triangles(0, 1, 2, 0,2, 1, 3, 0),
gsSP2Triangles(4, 3, 1, 0,5, 4, 1, 0),
gsSP2Triangles(5, 1, 0, 0,4, 6, 3, 0),
gsSP2Triangles(7, 4, 5, 0,6, 4, 7, 0),
gsSP2Triangles(8, 9, 10, 0,10, 9, 11, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x50038a8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x50038a0 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x50039d0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003938),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003938[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x50038a8.col, 1),
gsSPLight(&Light_monty_mole_geo_0x50038a0.col, 2),
gsSPVertex(VB_monty_mole_geo_0x50038b8, 8, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 4, 0),
gsSP2Triangles(1, 0, 3, 0,1, 5, 2, 0),
gsSP2Triangles(1, 4, 5, 0,3, 6, 7, 0),
gsSP2Triangles(3, 0, 6, 0,4, 3, 7, 0),
gsSP2Triangles(4, 7, 5, 0,0, 2, 6, 0),
gsSP2Triangles(5, 6, 2, 0,5, 7, 6, 0),
gsSPEndDisplayList(),
};

Light_t Light_monty_mole_geo_0x5003cd0 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_monty_mole_geo_0x5003cc8 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_monty_mole_geo_0x5003f50[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003e60),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_monty_mole_geo_0x5003ed8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003e60[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05002970),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_monty_mole_geo_0x5003cd0.col, 1),
gsSPLight(&Light_monty_mole_geo_0x5003cc8.col, 2),
gsSPVertex(VB_monty_mole_geo_0x5003ce0, 12, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 2, 0),
gsSP2Triangles(4, 2, 5, 0,2, 3, 5, 0),
gsSP2Triangles(6, 7, 8, 0,8, 9, 6, 0),
gsSP2Triangles(7, 10, 8, 0,5, 11, 4, 0),
gsSPEndDisplayList(),
};

Gfx DL_monty_mole_geo_0x5003ed8[] = {
gsDPSetTextureImage(0, 2, 1, monty_mole_geo__texture_05001170),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_monty_mole_geo_0x5003da0, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 4, 0),
gsSP2Triangles(3, 0, 2, 0,4, 3, 5, 0),
gsSP2Triangles(3, 2, 6, 0,5, 3, 6, 0),
gsSP2Triangles(6, 2, 7, 0,7, 2, 1, 0),
gsSP2Triangles(8, 9, 10, 0,11, 9, 8, 0),
gsSPEndDisplayList(),
};

