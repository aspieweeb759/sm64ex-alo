ALIGNED8 u8 monty_mole_geo__texture_05000970[] = {
#include "actors/monty_mole/monty_mole_geo_0x5000970_custom.rgba16.inc.c"
};
ALIGNED8 u8 monty_mole_geo__texture_05001170[] = {
#include "actors/monty_mole/monty_mole_geo_0x5001170_custom.rgba16.inc.c"
};
ALIGNED8 u8 monty_mole_geo__texture_05001970[] = {
#include "actors/monty_mole/monty_mole_geo_0x5001970_custom.rgba16.inc.c"
};
ALIGNED8 u8 monty_mole_geo__texture_05002170[] = {
#include "actors/monty_mole/monty_mole_geo_0x5002170_custom.rgba16.inc.c"
};
ALIGNED8 u8 monty_mole_geo__texture_05002970[] = {
#include "actors/monty_mole/monty_mole_geo_0x5002970_custom.rgba16.inc.c"
};
