#include "custom.model.inc.h"
const GeoLayout bowling_ball_geo[]= {
GEO_SHADOW(1,200,280),
GEO_OPEN_NODE(),
GEO_SCALE(0,170393),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_bowling_ball_geo_0x8022d08),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout bowling_ball_track_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_SCALE(0,170393),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_bowling_ball_geo_0x8022d08),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
