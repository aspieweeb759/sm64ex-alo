#ifndef sand_sand_model_HEADER_H
#define sand_sand_model_HEADER_H
#include "types.h"
extern Vtx VB_sand_seg3_dl_0302BCD0_0x302ba90[];
extern u8 sand_seg3_dl_0302BCD0__texture_0302BAD0[];
extern Gfx DL_sand_seg3_dl_0302BCD0_0x302bcd0[];
#endif