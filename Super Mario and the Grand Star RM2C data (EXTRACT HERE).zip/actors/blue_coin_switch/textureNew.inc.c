ALIGNED8 u8 blue_coin_switch_geo__texture_08000018[] = {
#include "actors/blue_coin_switch/blue_coin_switch_geo_0x8000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 blue_coin_switch_geo__texture_08000418[] = {
#include "actors/blue_coin_switch/blue_coin_switch_geo_0x8000418_custom.rgba16.inc.c"
};
