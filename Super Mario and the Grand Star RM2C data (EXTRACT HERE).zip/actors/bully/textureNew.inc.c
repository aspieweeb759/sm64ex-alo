ALIGNED8 u8 bully_geo__texture_05000468[] = {
#include "actors/bully/bully_geo_0x5000468_custom.rgba16.inc.c"
};
ALIGNED8 u8 bully_geo__texture_05001468[] = {
#include "actors/bully/bully_geo_0x5001468_custom.rgba16.inc.c"
};
ALIGNED8 u8 bully_geo__texture_050000E0[] = {
#include "actors/bully/bully_geo_0x50000e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 bully_geo__texture_05002468[] = {
#include "actors/bully/bully_geo_0x5002468_custom.rgba16.inc.c"
};
