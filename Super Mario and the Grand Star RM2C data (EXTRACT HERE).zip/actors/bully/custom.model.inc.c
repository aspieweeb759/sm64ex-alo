#include "custom.model.inc.h"
Vtx VB_bully_boss_geo_0x5000000[] = {
{{{ 196, 17, 114 }, 0, { 325, 310 }, { 255, 255, 255, 255}}},
{{{ 259, 2, 106 }, 0, { 422, 7 }, { 255, 255, 255, 255}}},
{{{ 184, -14, 137 }, 0, { 399, 416 }, { 255, 255, 255, 255}}},
{{{ 196, 17, -113 }, 0, { 105, 286 }, { 255, 255, 255, 255}}},
{{{ 259, 2, -105 }, 0, { 69, -34 }, { 255, 255, 255, 255}}},
{{{ 171, 17, -157 }, 0, { -107, 540 }, { 255, 255, 255, 255}}},
{{{ 184, -14, -136 }, 0, { -34, 392 }, { 255, 255, 255, 255}}},
{{{ 91, 42, -114 }, 0, { 236, 784 }, { 255, 255, 255, 255}}},
{{{ 140, 42, -34 }, 0, { 621, 305 }, { 255, 255, 255, 255}}},
{{{ 116, -38, -75 }, 0, { 344, 489 }, { 255, 255, 255, 255}}},
{{{ 171, 17, 158 }, 0, { 417, 557 }, { 255, 255, 255, 255}}},
{{{ 116, -38, 76 }, 0, { 111, 499 }, { 255, 255, 255, 255}}},
{{{ 91, 42, 115 }, 0, { 120, 778 }, { 255, 255, 255, 255}}},
{{{ 140, 42, 35 }, 0, { -40, 311 }, { 255, 255, 255, 255}}},
};

Vtx VB_bully_boss_geo_0x5002c68[] = {
{{{ 27, -35, 0 }, 0, { 0, 0 }, { 12, 130, 4, 0}}},
{{{ 56, -16, -27 }, 0, { 0, 0 }, { 22, 174, 163, 0}}},
{{{ 72, -16, 0 }, 0, { 0, 0 }, { 89, 167, 4, 0}}},
{{{ 56, 28, -46 }, 0, { 0, 0 }, { 101, 223, 189, 255}}},
{{{ 90, 28, 0 }, 0, { 0, 0 }, { 101, 223, 189, 255}}},
{{{ -17, -17, 0 }, 0, { 0, 0 }, { 215, 197, 152, 255}}},
{{{ -37, 27, 0 }, 0, { 0, 0 }, { 208, 222, 144, 255}}},
{{{ 56, 28, -46 }, 0, { 0, 0 }, { 208, 222, 144, 255}}},
{{{ 56, -16, 22 }, 0, { 0, 0 }, { 22, 180, 98, 255}}},
{{{ 90, 28, 0 }, 0, { 0, 0 }, { 95, 222, 75, 255}}},
{{{ 55, 28, 41 }, 0, { 0, 0 }, { 95, 222, 75, 255}}},
{{{ -17, -17, 0 }, 0, { 0, 0 }, { 220, 203, 108, 255}}},
{{{ 55, 28, 41 }, 0, { 0, 0 }, { 213, 223, 114, 255}}},
{{{ -37, 27, 0 }, 0, { 0, 0 }, { 213, 223, 114, 255}}},
};

Vtx VB_bully_boss_geo_0x5002d48[] = {
{{{ 90, 28, 0 }, 0, { 0, 0 }, { 255, 127, 0, 255}}},
{{{ 56, 28, -46 }, 0, { 0, 0 }, { 255, 127, 0, 0}}},
{{{ -37, 27, 0 }, 0, { 0, 0 }, { 255, 127, 0, 0}}},
{{{ 55, 28, 41 }, 0, { 0, 0 }, { 255, 127, 0, 255}}},
};

Vtx VB_bully_boss_geo_0x5002d88[] = {
{{{ 72, -16, 0 }, 0, { 0, 0 }, { 89, 167, 252, 0}}},
{{{ 56, -16, 27 }, 0, { 0, 0 }, { 22, 174, 93, 0}}},
{{{ 27, -35, 0 }, 0, { 0, 0 }, { 12, 130, 252, 0}}},
{{{ 90, 28, 0 }, 0, { 0, 0 }, { 101, 223, 67, 255}}},
{{{ 56, 28, 46 }, 0, { 0, 0 }, { 101, 223, 67, 255}}},
{{{ 56, 28, 46 }, 0, { 0, 0 }, { 208, 222, 112, 255}}},
{{{ -37, 27, 0 }, 0, { 0, 0 }, { 208, 222, 112, 255}}},
{{{ -17, -17, 0 }, 0, { 0, 0 }, { 215, 197, 104, 255}}},
{{{ 56, -16, -22 }, 0, { 0, 0 }, { 22, 180, 158, 255}}},
{{{ 55, 28, -41 }, 0, { 0, 0 }, { 95, 222, 181, 255}}},
{{{ 90, 28, 0 }, 0, { 0, 0 }, { 95, 222, 181, 255}}},
{{{ -37, 27, 0 }, 0, { 0, 0 }, { 213, 223, 142, 255}}},
{{{ 55, 28, -41 }, 0, { 0, 0 }, { 213, 223, 142, 255}}},
{{{ -17, -17, 0 }, 0, { 0, 0 }, { 220, 203, 148, 255}}},
};

Vtx VB_bully_boss_geo_0x5002e68[] = {
{{{ 55, 28, -41 }, 0, { 0, 0 }, { 255, 127, 0, 255}}},
{{{ -37, 27, 0 }, 0, { 0, 0 }, { 255, 127, 0, 0}}},
{{{ 56, 28, 46 }, 0, { 0, 0 }, { 255, 127, 0, 0}}},
{{{ 90, 28, 0 }, 0, { 0, 0 }, { 255, 127, 0, 255}}},
};

Vtx VB_bully_boss_geo_0x5003c50[] = {
{{{ 0, 57, 0 }, 0, { 992, 0 }, { 255, 255, 255, 255}}},
{{{ -55, -55, 0 }, 0, { 0, 2016 }, { 255, 255, 255, 255}}},
{{{ 0, -55, 0 }, 0, { 992, 2016 }, { 255, 255, 255, 255}}},
{{{ -55, 57, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_bully_boss_geo_0x5003c90[] = {
{{{ 57, 57, 0 }, 0, { 992, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -55, 0 }, 0, { 0, 2016 }, { 255, 255, 255, 255}}},
{{{ 57, -55, 0 }, 0, { 992, 2016 }, { 255, 255, 255, 255}}},
{{{ 0, 57, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_bully_boss_geo_0x5003db8[] = {
{{{ 0, 114, 0 }, 0, { 992, 0 }, { 255, 255, 255, 255}}},
{{{ -111, -111, 0 }, 0, { 0, 2016 }, { 255, 255, 255, 255}}},
{{{ 0, -111, 0 }, 0, { 992, 2016 }, { 255, 255, 255, 255}}},
{{{ -111, 114, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_bully_boss_geo_0x5003df8[] = {
{{{ 114, 114, 0 }, 0, { 992, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -111, 0 }, 0, { 0, 2016 }, { 255, 255, 255, 255}}},
{{{ 114, -111, 0 }, 0, { 992, 2016 }, { 255, 255, 255, 255}}},
{{{ 0, 114, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_bully_boss_geo_0x5003f20[] = {
{{{ -36, 152, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ -40, 136, 68 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 56, 124, 68 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 60, 140, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ 56, 124, -64 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -40, 136, -64 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Light_t Light_bully_geo_0x5000410 = {
{ 0, 227, 0}, 0, { 0, 227, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bully_geo_0x5000408 = {
{0, 56, 0}, 0, {0, 56, 0}, 0
};

Gfx DL_bully_geo_0x5003708[] = {
gsSPLight(&Light_bully_geo_0x5000410.col, 1),
gsSPLight(&Light_bully_geo_0x5000408.col, 2),
gsSPVertex(VB_bully_geo_0x5002c68, 14, 0),
gsSP2Triangles(0, 1, 2, 0,2, 1, 3, 0),
gsSP2Triangles(2, 3, 4, 0,1, 5, 6, 0),
gsSP2Triangles(1, 6, 7, 0,0, 5, 1, 0),
gsSP2Triangles(0, 2, 8, 0,8, 2, 9, 0),
gsSP2Triangles(8, 9, 10, 0,11, 8, 12, 0),
gsSP2Triangles(11, 12, 13, 0,0, 8, 11, 0),
gsSPVertex(VB_bully_geo_0x5002d48, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_bully_geo_0x5000428 = {
{ 0, 255, 0}, 0, { 0, 255, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_bully_geo_0x5000420 = {
{0, 63, 0}, 0, {0, 63, 0}, 0
};

Gfx DL_bully_geo_0x50037a0[] = {
gsSPLight(&Light_bully_geo_0x5000428.col, 1),
gsSPLight(&Light_bully_geo_0x5000420.col, 2),
gsSPVertex(VB_bully_geo_0x5002d88, 14, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 1, 0),
gsSP2Triangles(3, 1, 0, 0,5, 6, 7, 0),
gsSP2Triangles(5, 7, 1, 0,1, 7, 2, 0),
gsSP2Triangles(8, 0, 2, 0,9, 10, 0, 0),
gsSP2Triangles(9, 0, 8, 0,11, 12, 8, 0),
gsSP2Triangles(11, 8, 13, 0,13, 8, 2, 0),
gsSPVertex(VB_bully_geo_0x5002e68, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x5003d40[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_bully_geo_0x5003cd0),
gsSPDisplayList(DL_bully_geo_0x5003d08),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x5003cd0[] = {
gsDPSetTextureImage(0, 2, 1, bully_geo__texture_05000468),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_bully_geo_0x5003c50, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x5003d08[] = {
gsDPSetTextureImage(0, 2, 1, bully_geo__texture_05001468),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_bully_geo_0x5003c90, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x5000398[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, SHADE, 0, 0, 0, TEXEL0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 0, 4, 0, 0, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 60),
gsSPDisplayList(DL_bully_geo_0x50002e0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x50002e0[] = {
gsDPSetTextureImage(0, 2, 1, bully_geo__texture_050000E0),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 255, 512),
gsSPVertex(VB_bully_geo_0x5000000, 14, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(5, 4, 6, 0,6, 7, 5, 0),
gsSP2Triangles(5, 7, 8, 0,5, 8, 3, 0),
gsSP2Triangles(3, 8, 9, 0,3, 9, 6, 0),
gsSP2Triangles(6, 4, 3, 0,6, 9, 7, 0),
gsSP2Triangles(10, 11, 2, 0,0, 12, 10, 0),
gsSP2Triangles(10, 12, 11, 0,2, 1, 10, 0),
gsSP2Triangles(10, 1, 0, 0,2, 11, 13, 0),
gsSP2Triangles(0, 13, 12, 0,2, 13, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x5003fc8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_bully_geo_0x5003f80),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_bully_geo_0x5003f80[] = {
gsDPSetTextureImage(0, 2, 1, bully_geo__texture_05002468),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_bully_geo_0x5003f20, 6, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(3, 4, 5, 0,3, 5, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_bully_boss_geo_0x5003ea8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_bully_boss_geo_0x5003e38),
gsSPDisplayList(DL_bully_boss_geo_0x5003e70),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_bully_boss_geo_0x5003e38[] = {
gsDPSetTextureImage(0, 2, 1, bully_geo__texture_05000468),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_bully_boss_geo_0x5003db8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_bully_boss_geo_0x5003e70[] = {
gsDPSetTextureImage(0, 2, 1, bully_geo__texture_05001468),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_bully_boss_geo_0x5003df8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

