#include "custom.model.inc.h"
const GeoLayout ccm_geo_0003F0[]= {
GEO_SHADOW(1,200,400),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_ccm_geo_0003F0_0x7012bd8),
GEO_CLOSE_NODE(),
GEO_END(),
};
