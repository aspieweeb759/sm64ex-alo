#include "custom.model.inc.h"
const GeoLayout ccm_geo_0003D0[]= {
GEO_CULLING_RADIUS(500),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_ccm_geo_0003D0_0x7010f28),
GEO_DISPLAY_LIST(1,DL_ccm_geo_0003D0_0x70118b0),
GEO_CLOSE_NODE(),
GEO_END(),
};
