#ifndef ccm_ropeway_lift_model_HEADER_H
#define ccm_ropeway_lift_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_0003D0_0x7010bd0[];
extern Vtx VB_ccm_geo_0003D0_0x7010cc0[];
extern Vtx VB_ccm_geo_0003D0_0x7010d30[];
extern Vtx VB_ccm_geo_0003D0_0x7010fd0[];
extern Vtx VB_ccm_geo_0003D0_0x70110c0[];
extern Vtx VB_ccm_geo_0003D0_0x70111b0[];
extern Vtx VB_ccm_geo_0003D0_0x70112a0[];
extern Vtx VB_ccm_geo_0003D0_0x7011390[];
extern Vtx VB_ccm_geo_0003D0_0x7011410[];
extern Vtx VB_ccm_geo_0003D0_0x7011500[];
extern Vtx VB_ccm_geo_0003D0_0x7011600[];
extern u8 ccm_geo_0003D0__texture_09000000[];
extern u8 ccm_geo_0003D0__texture_07000900[];
extern Gfx DL_ccm_geo_0003D0_0x7010f28[];
extern Gfx DL_ccm_geo_0003D0_0x7010e30[];
extern Gfx DL_ccm_geo_0003D0_0x7010ec0[];
extern u8 ccm_geo_0003D0__texture_07000800[];
extern u8 ccm_geo_0003D0__texture_07001100[];
extern Light_t Light_ccm_geo_0003D0_0x7010fc0;
extern Ambient_t Light_ccm_geo_0003D0_0x7010fb8;
extern Gfx DL_ccm_geo_0003D0_0x70118b0[];
extern Gfx DL_ccm_geo_0003D0_0x7011660[];
extern Gfx DL_ccm_geo_0003D0_0x70117b8[];
#endif