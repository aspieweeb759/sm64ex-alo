#include "custom.model.inc.h"
const GeoLayout ccm_geo_000494[]= {
GEO_CULLING_RADIUS(400),
GEO_OPEN_NODE(),
GEO_RENDER_RANGE(65036,7000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_ccm_geo_000494_0x700fb00),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
