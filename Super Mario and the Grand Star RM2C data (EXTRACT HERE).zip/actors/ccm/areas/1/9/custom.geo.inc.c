#include "custom.model.inc.h"
const GeoLayout ccm_geo_0004BC[]= {
GEO_CULLING_RADIUS(800),
GEO_OPEN_NODE(),
GEO_RENDER_RANGE(64536,7000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_ccm_geo_0004BC_0x700fd08),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
