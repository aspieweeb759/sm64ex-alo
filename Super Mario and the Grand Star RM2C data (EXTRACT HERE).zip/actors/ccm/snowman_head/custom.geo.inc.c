#include "custom.model.inc.h"
const GeoLayout ccm_geo_00040C[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_ccm_geo_00040C_0x70136d0),
GEO_DISPLAY_LIST(4,DL_ccm_geo_00040C_0x7013870),
GEO_CLOSE_NODE(),
GEO_END(),
};
