#ifndef ccm_snowman_head_model_HEADER_H
#define ccm_snowman_head_model_HEADER_H
#include "types.h"
extern Vtx VB_ccm_geo_00040C_0x7012c50[];
extern Vtx VB_ccm_geo_00040C_0x7012d50[];
extern Vtx VB_ccm_geo_00040C_0x7012e50[];
extern Vtx VB_ccm_geo_00040C_0x7012f50[];
extern Vtx VB_ccm_geo_00040C_0x7013050[];
extern Vtx VB_ccm_geo_00040C_0x7013150[];
extern Vtx VB_ccm_geo_00040C_0x7013250[];
extern Vtx VB_ccm_geo_00040C_0x7013350[];
extern Vtx VB_ccm_geo_00040C_0x7013730[];
extern Vtx VB_ccm_geo_00040C_0x70137b0[];
extern u8 ccm_geo_00040C__texture_07011958[];
extern Light_t Light_ccm_geo_00040C_0x7012c40;
extern Ambient_t Light_ccm_geo_00040C_0x7012c38;
extern Gfx DL_ccm_geo_00040C_0x70136d0[];
extern Gfx DL_ccm_geo_00040C_0x70133e0[];
extern u8 ccm_geo_00040C__texture_07002900[];
extern u8 ccm_geo_00040C__texture_07002100[];
extern Gfx DL_ccm_geo_00040C_0x7013870[];
extern Gfx DL_ccm_geo_00040C_0x70137f0[];
extern Gfx DL_ccm_geo_00040C_0x7013838[];
#endif