#include "custom.model.inc.h"
const GeoLayout jrb_geo_000960[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_000960_0x70080f8),
GEO_CLOSE_NODE(),
GEO_END(),
};
