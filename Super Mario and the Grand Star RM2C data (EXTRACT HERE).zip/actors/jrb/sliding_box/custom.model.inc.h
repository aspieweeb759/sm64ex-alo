#ifndef jrb_sliding_box_model_HEADER_H
#define jrb_sliding_box_model_HEADER_H
#include "types.h"
extern Vtx VB_jrb_geo_000960_0x7007eb8[];
extern Vtx VB_jrb_geo_000960_0x7007fb8[];
extern u8 jrb_geo_000960__texture_07001800[];
extern u8 jrb_geo_000960__texture_07002000[];
extern Light_t Light_jrb_geo_000960_0x7007ea8;
extern Ambient_t Light_jrb_geo_000960_0x7007ea0;
extern Gfx DL_jrb_geo_000960_0x70080f8[];
extern Gfx DL_jrb_geo_000960_0x7008038[];
extern Gfx DL_jrb_geo_000960_0x70080b0[];
#endif