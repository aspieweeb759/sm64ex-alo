#ifndef jrb_rock_model_HEADER_H
#define jrb_rock_model_HEADER_H
#include "types.h"
extern Vtx VB_jrb_geo_000930_0x7007808[];
extern Vtx VB_jrb_geo_000930_0x7007908[];
extern u8 jrb_geo_000930__texture_09001800[];
extern Light_t Light_jrb_geo_000930_0x70077f8;
extern Ambient_t Light_jrb_geo_000930_0x70077f0;
extern Gfx DL_jrb_geo_000930_0x7007ac8[];
extern Gfx DL_jrb_geo_000930_0x70079e8[];
#endif