#include "custom.model.inc.h"
const GeoLayout jrb_geo_000930[]= {
GEO_CULLING_RADIUS(1100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_000930_0x7007ac8),
GEO_CLOSE_NODE(),
GEO_END(),
};
