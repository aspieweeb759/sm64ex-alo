#ifndef jrb_floating_platform_model_HEADER_H
#define jrb_floating_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_jrb_geo_000948_0x7007b88[];
extern Vtx VB_jrb_geo_000948_0x7007c88[];
extern u8 jrb_geo_000948__texture_0900A000[];
extern u8 jrb_geo_000948__texture_0900A800[];
extern Light_t Light_jrb_geo_000948_0x7007b78;
extern Ambient_t Light_jrb_geo_000948_0x7007b70;
extern Gfx DL_jrb_geo_000948_0x7007dc8[];
extern Gfx DL_jrb_geo_000948_0x7007d08[];
extern Gfx DL_jrb_geo_000948_0x7007d80[];
#endif