#include "custom.model.inc.h"
const GeoLayout jrb_geo_000948[]= {
GEO_CULLING_RADIUS(900),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_000948_0x7007dc8),
GEO_CLOSE_NODE(),
GEO_END(),
};
