#ifndef jrb_falling_pillar_base_model_HEADER_H
#define jrb_falling_pillar_base_model_HEADER_H
#include "types.h"
extern Vtx VB_jrb_geo_000918_0x700af08[];
extern u8 jrb_geo_000918__texture_09001800[];
extern Light_t Light_jrb_geo_000918_0x700aef8;
extern Ambient_t Light_jrb_geo_000918_0x700aef0;
extern Gfx DL_jrb_geo_000918_0x700afb0[];
extern Gfx DL_jrb_geo_000918_0x700af58[];
#endif