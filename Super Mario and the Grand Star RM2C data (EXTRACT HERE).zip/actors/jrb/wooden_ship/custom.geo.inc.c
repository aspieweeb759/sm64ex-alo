#include "custom.model.inc.h"
const GeoLayout jrb_geo_000978[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_000978_0x7008fd8),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout jrb_geo_0009B0[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_0009B0_0x7009a58),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout jrb_geo_0009E8[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_0009E8_0x700a608),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout jrb_geo_000A00[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_000A00_0x700ac68),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout jrb_geo_000990[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_ASM(0, geo_update_layer_transparency),
GEO_DISPLAY_LIST(5,DL_jrb_geo_000990_0x70090b0),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout jrb_geo_0009C8[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_ASM(0, geo_update_layer_transparency),
GEO_DISPLAY_LIST(5,DL_jrb_geo_0009C8_0x7009b30),
GEO_CLOSE_NODE(),
GEO_END(),
};
