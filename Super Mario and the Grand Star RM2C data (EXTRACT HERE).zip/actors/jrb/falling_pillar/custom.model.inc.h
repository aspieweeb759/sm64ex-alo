#ifndef jrb_falling_pillar_model_HEADER_H
#define jrb_falling_pillar_model_HEADER_H
#include "types.h"
extern Vtx VB_jrb_geo_000900_0x700ad50[];
extern u8 jrb_geo_000900__texture_09001800[];
extern Light_t Light_jrb_geo_000900_0x700ad40;
extern Ambient_t Light_jrb_geo_000900_0x700ad38;
extern Gfx DL_jrb_geo_000900_0x700ae48[];
extern Gfx DL_jrb_geo_000900_0x700add0[];
#endif