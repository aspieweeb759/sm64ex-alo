#include "custom.model.inc.h"
const GeoLayout jrb_geo_000900[]= {
GEO_CULLING_RADIUS(1600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_jrb_geo_000900_0x700ae48),
GEO_CLOSE_NODE(),
GEO_END(),
};
