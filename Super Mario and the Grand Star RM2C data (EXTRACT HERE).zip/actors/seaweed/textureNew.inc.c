ALIGNED8 u8 seaweed_geo__texture_06009610[] = {
#include "actors/seaweed/seaweed_geo_0x6009610_custom.rgba16.inc.c"
};
ALIGNED8 u8 seaweed_geo__texture_06008E10[] = {
#include "actors/seaweed/seaweed_geo_0x6008e10_custom.rgba16.inc.c"
};
ALIGNED8 u8 seaweed_geo__texture_06008610[] = {
#include "actors/seaweed/seaweed_geo_0x6008610_custom.rgba16.inc.c"
};
ALIGNED8 u8 seaweed_geo__texture_06007E10[] = {
#include "actors/seaweed/seaweed_geo_0x6007e10_custom.rgba16.inc.c"
};
