#ifndef scuttlebug_scuttlebug_model_HEADER_H
#define scuttlebug_scuttlebug_model_HEADER_H
#include "types.h"
extern Vtx VB_scuttlebug_geo_0x6013908[];
extern Vtx VB_scuttlebug_geo_0x6013948[];
extern Vtx VB_scuttlebug_geo_0x6013a70[];
extern Vtx VB_scuttlebug_geo_0x6013b58[];
extern Vtx VB_scuttlebug_geo_0x6013c40[];
extern Vtx VB_scuttlebug_geo_0x6013d28[];
extern Vtx VB_scuttlebug_geo_0x6013e28[];
extern Vtx VB_scuttlebug_geo_0x6013f28[];
extern Vtx VB_scuttlebug_geo_0x6014110[];
extern Vtx VB_scuttlebug_geo_0x60141f8[];
extern Vtx VB_scuttlebug_geo_0x60142f8[];
extern Light_t Light_scuttlebug_geo_0x60142e8;
extern Ambient_t Light_scuttlebug_geo_0x60142e0;
extern Gfx DL_scuttlebug_geo_0x6014378[];
extern Gfx DL_scuttlebug_geo_0x6014338[];
extern u8 scuttlebug_geo__texture_06013108[];
extern Gfx DL_scuttlebug_geo_0x6014270[];
extern Gfx DL_scuttlebug_geo_0x6014238[];
extern Gfx DL_scuttlebug_geo_0x6014188[];
extern Gfx DL_scuttlebug_geo_0x6014150[];
extern u8 scuttlebug_geo__texture_06010908[];
extern u8 scuttlebug_geo__texture_06011908[];
extern Gfx DL_scuttlebug_geo_0x60139f8[];
extern Gfx DL_scuttlebug_geo_0x6013988[];
extern Gfx DL_scuttlebug_geo_0x60139c0[];
extern u8 scuttlebug_geo__texture_06010108[];
extern Gfx DL_scuttlebug_geo_0x6013ae8[];
extern Gfx DL_scuttlebug_geo_0x6013ab0[];
extern u8 scuttlebug_geo__texture_06012908[];
extern Gfx DL_scuttlebug_geo_0x6013cb8[];
extern Gfx DL_scuttlebug_geo_0x6013c80[];
extern Gfx DL_scuttlebug_geo_0x6013bd0[];
extern Gfx DL_scuttlebug_geo_0x6013b98[];
extern Gfx DL_scuttlebug_geo_0x6013da0[];
extern Gfx DL_scuttlebug_geo_0x6013d68[];
extern Light_t Light_scuttlebug_geo_0x6013e18;
extern Ambient_t Light_scuttlebug_geo_0x6013e10;
extern Gfx DL_scuttlebug_geo_0x60140f0[];
extern Gfx DL_scuttlebug_geo_0x6013fc8[];
#endif