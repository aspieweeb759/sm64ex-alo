#include "custom.model.inc.h"
Vtx VB_scuttlebug_geo_0x6013908[] = {
{{{ -44, -44, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -44, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 44, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -44, 44, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013948[] = {
{{{ 0, -44, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 44, 44, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, 44, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ 44, -44, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013a70[] = {
{{{ 15, 15, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -15, 15, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -15, -15, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 15, -15, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013b58[] = {
{{{ 15, 15, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -15, 15, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -15, -15, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 15, -15, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013c40[] = {
{{{ 60, -30, 31 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ 60, -30, -30 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 60, 32, -30 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 60, 32, 31 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013d28[] = {
{{{ 60, -30, 31 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 60, -30, -30 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 59, 31, -30 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 59, 31, 31 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013e28[] = {
{{{ -111, 85, 293 }, 0, { 0, 0 }, { 126, 6, 11, 255}}},
{{{ -120, 127, 192 }, 0, { 0, 0 }, { 52, 100, 200, 255}}},
{{{ -120, 103, 301 }, 0, { 0, 0 }, { 201, 98, 58, 255}}},
{{{ -128, -84, 293 }, 0, { 0, 0 }, { 130, 250, 11, 255}}},
{{{ -120, -126, 192 }, 0, { 0, 0 }, { 199, 158, 200, 255}}},
{{{ -120, -102, 301 }, 0, { 0, 0 }, { 50, 156, 59, 255}}},
{{{ -103, -88, 199 }, 0, { 0, 0 }, { 126, 249, 243, 255}}},
{{{ -111, -84, 293 }, 0, { 0, 0 }, { 125, 16, 12, 255}}},
{{{ -120, -29, 351 }, 0, { 0, 0 }, { 244, 61, 110, 255}}},
{{{ -136, -88, 199 }, 0, { 0, 0 }, { 131, 16, 244, 255}}},
{{{ -120, -58, 167 }, 0, { 0, 0 }, { 254, 31, 133, 255}}},
{{{ -120, -49, 205 }, 0, { 0, 0 }, { 47, 117, 4, 255}}},
{{{ -120, -67, 284 }, 0, { 0, 0 }, { 201, 114, 249, 255}}},
{{{ -120, 68, 284 }, 0, { 0, 0 }, { 50, 140, 248, 255}}},
{{{ -103, 89, 199 }, 0, { 0, 0 }, { 124, 238, 243, 255}}},
{{{ -120, 30, 351 }, 0, { 0, 0 }, { 244, 195, 110, 255}}},
};

Vtx VB_scuttlebug_geo_0x6013f28[] = {
{{{ -103, 89, 199 }, 0, { 0, 0 }, { 124, 238, 243, 255}}},
{{{ -120, 59, 167 }, 0, { 0, 0 }, { 254, 225, 133, 255}}},
{{{ -120, 127, 192 }, 0, { 0, 0 }, { 52, 100, 200, 255}}},
{{{ -136, 89, 199 }, 0, { 0, 0 }, { 130, 6, 244, 255}}},
{{{ -120, 103, 301 }, 0, { 0, 0 }, { 201, 98, 58, 255}}},
{{{ -111, 85, 293 }, 0, { 0, 0 }, { 126, 6, 11, 255}}},
{{{ -120, 30, 351 }, 0, { 0, 0 }, { 244, 195, 110, 255}}},
{{{ -128, 85, 293 }, 0, { 0, 0 }, { 131, 241, 11, 255}}},
{{{ -120, 50, 205 }, 0, { 0, 0 }, { 205, 140, 3, 255}}},
{{{ -120, 68, 284 }, 0, { 0, 0 }, { 50, 140, 248, 255}}},
};

Vtx VB_scuttlebug_geo_0x6014110[] = {
{{{ -21, 37, 0 }, 0, { -584, -4238 }, { 255, 255, 255, 255}}},
{{{ 191, 18, 0 }, 0, { 28, 892 }, { 255, 255, 255, 255}}},
{{{ 193, -19, 0 }, 0, { 988, 958 }, { 255, 255, 255, 255}}},
{{{ -16, -25, 0 }, 0, { 982, -4136 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x60141f8[] = {
{{{ -9, 39, 4 }, 0, { -560, -4258 }, { 255, 255, 255, 255}}},
{{{ 199, 20, 2 }, 0, { 38, 948 }, { 255, 255, 255, 255}}},
{{{ 201, -17, -2 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ -5, -22, -3 }, 0, { 990, -4192 }, { 255, 255, 255, 255}}},
};

Vtx VB_scuttlebug_geo_0x60142f8[] = {
{{{ 0, -1, 0 }, 0, { 0, 0 }, { 130, 2, 0, 255}}},
{{{ 57, -106, -3 }, 0, { 0, 0 }, { 207, 140, 253, 255}}},
{{{ 57, 48, 83 }, 0, { 0, 0 }, { 208, 55, 103, 255}}},
{{{ 57, 54, -81 }, 0, { 0, 0 }, { 207, 61, 157, 255}}},
};

Light_t Light_scuttlebug_geo_0x60142e8 = {
{ 153, 22, 22}, 0, { 153, 22, 22}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_scuttlebug_geo_0x60142e0 = {
{38, 5, 5}, 0, {38, 5, 5}, 0
};

Gfx DL_scuttlebug_geo_0x6014378[] = {
gsDPPipeSync(),
gsSPDisplayList(DL_scuttlebug_geo_0x6014338),
gsDPPipeSync(),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6014338[] = {
gsSPLight(&Light_scuttlebug_geo_0x60142e8.col, 1),
gsSPLight(&Light_scuttlebug_geo_0x60142e0.col, 2),
gsSPVertex(VB_scuttlebug_geo_0x60142f8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 2, 1, 0),
gsSP2Triangles(2, 3, 0, 0,1, 0, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6014270[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_scuttlebug_geo_0x6014238),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6014238[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06013108),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_scuttlebug_geo_0x60141f8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6014188[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_scuttlebug_geo_0x6014150),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6014150[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06013108),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_scuttlebug_geo_0x6014110, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x60139f8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_scuttlebug_geo_0x6013988),
gsSPDisplayList(DL_scuttlebug_geo_0x60139c0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013988[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06010908),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_scuttlebug_geo_0x6013908, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x60139c0[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06011908),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_scuttlebug_geo_0x6013948, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013ae8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_scuttlebug_geo_0x6013ab0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013ab0[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06010108),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_scuttlebug_geo_0x6013a70, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013cb8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_scuttlebug_geo_0x6013c80),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013c80[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06012908),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_scuttlebug_geo_0x6013c40, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013bd0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_scuttlebug_geo_0x6013b98),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013b98[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06010108),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_scuttlebug_geo_0x6013b58, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013da0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_scuttlebug_geo_0x6013d68),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013d68[] = {
gsDPSetTextureImage(0, 2, 1, scuttlebug_geo__texture_06012908),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_scuttlebug_geo_0x6013d28, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_scuttlebug_geo_0x6013e18 = {
{ 207, 137, 6}, 0, { 207, 137, 6}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_scuttlebug_geo_0x6013e10 = {
{51, 34, 1}, 0, {51, 34, 1}, 0
};

Gfx DL_scuttlebug_geo_0x60140f0[] = {
gsDPPipeSync(),
gsSPDisplayList(DL_scuttlebug_geo_0x6013fc8),
gsDPPipeSync(),
gsSPEndDisplayList(),
};

Gfx DL_scuttlebug_geo_0x6013fc8[] = {
gsSPLight(&Light_scuttlebug_geo_0x6013e18.col, 1),
gsSPLight(&Light_scuttlebug_geo_0x6013e10.col, 2),
gsSPVertex(VB_scuttlebug_geo_0x6013e28, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(5, 6, 7, 0,5, 4, 6, 0),
gsSP2Triangles(8, 5, 7, 0,3, 5, 8, 0),
gsSP2Triangles(9, 10, 4, 0,3, 9, 4, 0),
gsSP2Triangles(10, 6, 4, 0,10, 11, 6, 0),
gsSP2Triangles(11, 7, 6, 0,12, 7, 11, 0),
gsSP2Triangles(12, 8, 7, 0,12, 9, 3, 0),
gsSP2Triangles(3, 8, 12, 0,11, 10, 9, 0),
gsSP2Triangles(11, 9, 12, 0,13, 14, 0, 0),
gsSP2Triangles(0, 14, 1, 0,15, 13, 0, 0),
gsSPVertex(VB_scuttlebug_geo_0x6013f28, 10, 0),
gsSP2Triangles(0, 1, 2, 0,3, 2, 1, 0),
gsSP2Triangles(4, 2, 3, 0,5, 4, 6, 0),
gsSP2Triangles(6, 4, 7, 0,4, 3, 7, 0),
gsSP2Triangles(1, 8, 3, 0,8, 7, 3, 0),
gsSP2Triangles(8, 1, 0, 0,8, 0, 9, 0),
gsSP2Triangles(9, 7, 8, 0,7, 9, 6, 0),
gsSPEndDisplayList(),
};

