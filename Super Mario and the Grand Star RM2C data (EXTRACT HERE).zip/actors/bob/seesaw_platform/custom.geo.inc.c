#include "custom.model.inc.h"
const GeoLayout bob_geo_000458[]= {
GEO_CULLING_RADIUS(1200),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bob_geo_000458_0x700e768),
GEO_CLOSE_NODE(),
GEO_END(),
};
