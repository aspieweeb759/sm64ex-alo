#include "custom.model.inc.h"
const GeoLayout bob_geo_000470[]= {
GEO_CULLING_RADIUS(800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_bob_geo_000470_0x700e8a0),
GEO_CLOSE_NODE(),
GEO_END(),
};
