#include "custom.model.inc.h"
const GeoLayout pokey_head_geo[]= {
GEO_SHADOW(1,150,50),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(2, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_pokey_head_geo_0x50127d8),
GEO_DISPLAY_LIST(4,DL_pokey_head_geo_0x5012808),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout pokey_body_part_geo[]= {
GEO_SHADOW(1,150,50),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_pokey_body_part_geo_0x50130b0),
GEO_CLOSE_NODE(),
GEO_END(),
};
