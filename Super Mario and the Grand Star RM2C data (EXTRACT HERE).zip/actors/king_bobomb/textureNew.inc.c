ALIGNED8 u8 king_bobomb_geo__texture_05008478[] = {
#include "actors/king_bobomb/king_bobomb_geo_0x5008478_custom.rgba16.inc.c"
};
ALIGNED8 u8 king_bobomb_geo__texture_05009478[] = {
#include "actors/king_bobomb/king_bobomb_geo_0x5009478_custom.rgba16.inc.c"
};
ALIGNED8 u8 king_bobomb_geo__texture_05002078[] = {
#include "actors/king_bobomb/king_bobomb_geo_0x5002078_custom.rgba16.inc.c"
};
ALIGNED8 u8 king_bobomb_geo__texture_05004878[] = {
#include "actors/king_bobomb/king_bobomb_geo_0x5004878_custom.rgba16.inc.c"
};
ALIGNED8 u8 king_bobomb_geo__texture_05006078[] = {
#include "actors/king_bobomb/king_bobomb_geo_0x5006078_custom.rgba16.inc.c"
};
ALIGNED8 u8 king_bobomb_geo__texture_05005878[] = {
#include "actors/king_bobomb/king_bobomb_geo_0x5005878_custom.rgba16.inc.c"
};
