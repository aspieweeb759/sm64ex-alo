ALIGNED8 u8 koopa_with_shell_geo__texture_06002E48[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6002e48_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06002648[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6002648_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06004648[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6004648_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06005648[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6005648_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06005E48[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6005e48_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06004E48[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6004e48_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06003648[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6003648_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_with_shell_geo__texture_06003E48[] = {
#include "actors/koopa/koopa_with_shell_geo_0x6003e48_custom.rgba16.inc.c"
};
