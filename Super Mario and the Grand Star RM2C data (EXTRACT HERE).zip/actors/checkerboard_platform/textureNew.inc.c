ALIGNED8 u8 checkerboard_platform_geo__texture_0800C840[] = {
#include "actors/checkerboard_platform/checkerboard_platform_geo_0x800c840_custom.rgba16.inc.c"
};
ALIGNED8 u8 checkerboard_platform_geo__texture_0800CC40[] = {
#include "actors/checkerboard_platform/checkerboard_platform_geo_0x800cc40_custom.rgba16.inc.c"
};
