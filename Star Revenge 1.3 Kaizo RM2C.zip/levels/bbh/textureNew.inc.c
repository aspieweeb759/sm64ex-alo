ALIGNED8 u8 bbh_1__texture_0E009010[] = {
#include "levels/bbh/bbh_1_0xe009010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E00B010[] = {
#include "levels/bbh/bbh_1_0xe00b010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E000810[] = {
#include "levels/bbh/bbh_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E004810[] = {
#include "levels/bbh/bbh_1_0xe004810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E003010[] = {
#include "levels/bbh/bbh_1_0xe003010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E006810[] = {
#include "levels/bbh/bbh_1_0xe006810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E006010[] = {
#include "levels/bbh/bbh_1_0xe006010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E002810[] = {
#include "levels/bbh/bbh_1_0xe002810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E009810[] = {
#include "levels/bbh/bbh_1_0xe009810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E007810[] = {
#include "levels/bbh/bbh_1_0xe007810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E00D810[] = {
#include "levels/bbh/bbh_1_0xe00d810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E002010[] = {
#include "levels/bbh/bbh_1_0xe002010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E007010[] = {
#include "levels/bbh/bbh_1_0xe007010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E004010[] = {
#include "levels/bbh/bbh_1_0xe004010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E005810[] = {
#include "levels/bbh/bbh_1_0xe005810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E008010[] = {
#include "levels/bbh/bbh_1_0xe008010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E00C010[] = {
#include "levels/bbh/bbh_1_0xe00c010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_09001800[] = {
#include "levels/bbh/bbh_1_0x9001800_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E00D010[] = {
#include "levels/bbh/bbh_1_0xe00d010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E000010[] = {
#include "levels/bbh/bbh_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E005010[] = {
#include "levels/bbh/bbh_1_0xe005010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E00A010[] = {
#include "levels/bbh/bbh_1_0xe00a010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E001810[] = {
#include "levels/bbh/bbh_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E001010[] = {
#include "levels/bbh/bbh_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bbh_1__texture_0E003810[] = {
#include "levels/bbh/bbh_1_0xe003810_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005B0__texture_0900A000[] = {
#include "levels/bbh/geo_bbh_0005B0_0x900a000_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005B0__texture_09005000[] = {
#include "levels/bbh/geo_bbh_0005B0_0x9005000_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005C8__texture_09008800[] = {
#include "levels/bbh/geo_bbh_0005C8_0x9008800_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005C8__texture_09005000[] = {
#include "levels/bbh/geo_bbh_0005C8_0x9005000_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005C8__texture_09009000[] = {
#include "levels/bbh/geo_bbh_0005C8_0x9009000_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005E0__texture_09004800[] = {
#include "levels/bbh/geo_bbh_0005E0_0x9004800_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_0005F8__texture_09004800[] = {
#include "levels/bbh/geo_bbh_0005F8_0x9004800_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_000610__texture_09003800[] = {
#include "levels/bbh/geo_bbh_000610_0x9003800_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_000610__texture_09002800[] = {
#include "levels/bbh/geo_bbh_000610_0x9002800_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_000628__texture_09000000[] = {
#include "levels/bbh/geo_bbh_000628_0x9000000_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_000640__texture_09005000[] = {
#include "levels/bbh/geo_bbh_000640_0x9005000_custom.rgba16.inc.c"
};
ALIGNED8 u8 geo_bbh_000640__texture_07000000[] = {
#include "levels/bbh/geo_bbh_000640_0x7000000_custom.rgba16.inc.c"
};
