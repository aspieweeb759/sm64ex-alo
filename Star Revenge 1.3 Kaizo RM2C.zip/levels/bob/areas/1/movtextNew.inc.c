static Movtex bob_1_Movtex_0_0[] = {1, 0, 15, 3, -10000, -10000, 10000, -10000, 10000, 10000, -10000, 10000, 1, 120, 0, 0};

const struct MovtexQuadCollection bob_1_Movtex_0[] = {
{0,bob_1_Movtex_0_0},
{-1, NULL},
};
