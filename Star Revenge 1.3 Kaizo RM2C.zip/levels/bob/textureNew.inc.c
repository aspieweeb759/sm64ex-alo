ALIGNED8 u8 bob_1__texture_0E002010[] = {
#include "levels/bob/bob_1_0xe002010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E003010[] = {
#include "levels/bob/bob_1_0xe003010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E009010[] = {
#include "levels/bob/bob_1_0xe009010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002810[] = {
#include "levels/bob/bob_1_0xe002810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E008010[] = {
#include "levels/bob/bob_1_0xe008010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001810[] = {
#include "levels/bob/bob_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E007010[] = {
#include "levels/bob/bob_1_0xe007010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E004810[] = {
#include "levels/bob/bob_1_0xe004810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E006810[] = {
#include "levels/bob/bob_1_0xe006810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E005810[] = {
#include "levels/bob/bob_1_0xe005810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E006010[] = {
#include "levels/bob/bob_1_0xe006010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E007810[] = {
#include "levels/bob/bob_1_0xe007810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001010[] = {
#include "levels/bob/bob_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E008810[] = {
#include "levels/bob/bob_1_0xe008810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E000010[] = {
#include "levels/bob/bob_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_09009800[] = {
#include "levels/bob/bob_1_0x9009800_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E000810[] = {
#include "levels/bob/bob_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E005010[] = {
#include "levels/bob/bob_1_0xe005010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E004010[] = {
#include "levels/bob/bob_1_0xe004010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E003810[] = {
#include "levels/bob/bob_1_0xe003810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_geo_000440__texture_09008800[] = {
#include "levels/bob/bob_geo_000440_0x9008800_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_geo_000458__texture_09006000[] = {
#include "levels/bob/bob_geo_000458_0x9006000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_geo_000470__texture_09008800[] = {
#include "levels/bob/bob_geo_000470_0x9008800_custom.rgba16.inc.c"
};
