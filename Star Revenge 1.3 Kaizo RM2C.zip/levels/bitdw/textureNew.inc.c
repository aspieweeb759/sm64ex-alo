ALIGNED8 u8 bitdw_1__texture_0E000810[] = {
#include "levels/bitdw/bitdw_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E001010[] = {
#include "levels/bitdw/bitdw_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E000010[] = {
#include "levels/bitdw/bitdw_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_09008800[] = {
#include "levels/bitdw/bitdw_1_0x9008800_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E002810[] = {
#include "levels/bitdw/bitdw_1_0xe002810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_09002000[] = {
#include "levels/bitdw/bitdw_1_0x9002000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E003810[] = {
#include "levels/bitdw/bitdw_1_0xe003810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E004010[] = {
#include "levels/bitdw/bitdw_1_0xe004010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E003010[] = {
#include "levels/bitdw/bitdw_1_0xe003010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E001810[] = {
#include "levels/bitdw/bitdw_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E002010[] = {
#include "levels/bitdw/bitdw_1_0xe002010_custom.rgba16.inc.c"
};
