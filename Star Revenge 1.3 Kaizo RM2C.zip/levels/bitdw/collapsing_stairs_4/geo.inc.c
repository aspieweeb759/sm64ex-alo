// 0x0E0005E8
const GeoLayout geo_bitdw_0005E8[] = {
   GEO_CULLING_RADIUS(2000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_0700D190),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
