// 0x0E000690
const GeoLayout bitfs_geo_000690[] = {
   GEO_CULLING_RADIUS(550),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bitfs_seg7_dl_0700F6A8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
