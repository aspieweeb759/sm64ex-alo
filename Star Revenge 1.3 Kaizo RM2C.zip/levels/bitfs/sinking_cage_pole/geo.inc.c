// 0x0E0006A8
const GeoLayout bitfs_geo_0006A8[] = {
   GEO_CULLING_RADIUS(900),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_0700FB38),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
