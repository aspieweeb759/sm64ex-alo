ALIGNED8 u8 bitfs_1__texture_0E000810[] = {
#include "levels/bitfs/bitfs_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E004010[] = {
#include "levels/bitfs/bitfs_1_0xe004010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E005810[] = {
#include "levels/bitfs/bitfs_1_0xe005810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E000010[] = {
#include "levels/bitfs/bitfs_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E007810[] = {
#include "levels/bitfs/bitfs_1_0xe007810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E002810[] = {
#include "levels/bitfs/bitfs_1_0xe002810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E006010[] = {
#include "levels/bitfs/bitfs_1_0xe006010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E001810[] = {
#include "levels/bitfs/bitfs_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E001010[] = {
#include "levels/bitfs/bitfs_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E005010[] = {
#include "levels/bitfs/bitfs_1_0xe005010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E008010[] = {
#include "levels/bitfs/bitfs_1_0xe008010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E003810[] = {
#include "levels/bitfs/bitfs_1_0xe003810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E006810[] = {
#include "levels/bitfs/bitfs_1_0xe006810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E004810[] = {
#include "levels/bitfs/bitfs_1_0xe004810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_09005000[] = {
#include "levels/bitfs/bitfs_1_0x9005000_custom.rgba16.inc.c"
};
