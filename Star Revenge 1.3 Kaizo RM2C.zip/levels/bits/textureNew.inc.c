ALIGNED8 u8 bits_1__texture_0E009810[] = {
#include "levels/bits/bits_1_0xe009810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E005010[] = {
#include "levels/bits/bits_1_0xe005010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00B810[] = {
#include "levels/bits/bits_1_0xe00b810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E002010[] = {
#include "levels/bits/bits_1_0xe002010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E004810[] = {
#include "levels/bits/bits_1_0xe004810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E007010[] = {
#include "levels/bits/bits_1_0xe007010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00C810[] = {
#include "levels/bits/bits_1_0xe00c810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00E810[] = {
#include "levels/bits/bits_1_0xe00e810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00B010[] = {
#include "levels/bits/bits_1_0xe00b010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00C010[] = {
#include "levels/bits/bits_1_0xe00c010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E004010[] = {
#include "levels/bits/bits_1_0xe004010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00E010[] = {
#include "levels/bits/bits_1_0xe00e010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E000810[] = {
#include "levels/bits/bits_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E000010[] = {
#include "levels/bits/bits_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00A810[] = {
#include "levels/bits/bits_1_0xe00a810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E009010[] = {
#include "levels/bits/bits_1_0xe009010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E003810[] = {
#include "levels/bits/bits_1_0xe003810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E001810[] = {
#include "levels/bits/bits_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E006810[] = {
#include "levels/bits/bits_1_0xe006810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00D810[] = {
#include "levels/bits/bits_1_0xe00d810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E008010[] = {
#include "levels/bits/bits_1_0xe008010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E002810[] = {
#include "levels/bits/bits_1_0xe002810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E007810[] = {
#include "levels/bits/bits_1_0xe007810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E005810[] = {
#include "levels/bits/bits_1_0xe005810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00A010[] = {
#include "levels/bits/bits_1_0xe00a010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E001010[] = {
#include "levels/bits/bits_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E00D010[] = {
#include "levels/bits/bits_1_0xe00d010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_1__texture_0E006010[] = {
#include "levels/bits/bits_1_0xe006010_custom.rgba16.inc.c"
};
