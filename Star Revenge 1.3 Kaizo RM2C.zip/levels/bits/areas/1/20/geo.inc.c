// 0x0E0005E0
const GeoLayout bits_geo_0005E0[] = {
   GEO_CULLING_RADIUS(1100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07012B10),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
