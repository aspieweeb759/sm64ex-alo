// 0x0E000568
const GeoLayout bits_geo_000568[] = {
   GEO_CULLING_RADIUS(2400),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_0700D278),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
