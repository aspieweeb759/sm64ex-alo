// 0x0E000658
const GeoLayout bits_geo_000658[] = {
   GEO_CULLING_RADIUS(700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07013EF8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
