// 0x0E0005C8
const GeoLayout bits_geo_0005C8[] = {
   GEO_CULLING_RADIUS(3300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_070128F0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
