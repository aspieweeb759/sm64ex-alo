ALIGNED8 u8 toad_geo__texture_06005920[] = {
#include "actors/toad/toad_geo_0x6005920_custom.rgba16.inc.c"
};
ALIGNED8 u8 toad_geo__texture_06006120[] = {
#include "actors/toad/toad_geo_0x6006120_custom.rgba16.inc.c"
};
