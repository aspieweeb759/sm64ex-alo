#include "custom.model.inc.h"
Vtx VB_king_bobomb_geo_0x500a478[] = {
{{{ 23, 23, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -22, 23, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -22, -22, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 23, -22, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500a560[] = {
{{{ 26, 26, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -25, 26, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -25, -25, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 26, -25, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500a648[] = {
{{{ 49, 49, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -48, 49, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -48, -48, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 49, -48, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500a730[] = {
{{{ 23, 23, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -22, 23, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -22, -22, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 23, -22, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500a818[] = {
{{{ 26, 26, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -25, 26, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -25, -25, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 26, -25, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500a900[] = {
{{{ 49, 49, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -48, 49, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -48, -48, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 49, -48, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500aa00[] = {
{{{ -40, -165, -122 }, 0, { 0, 0 }, { 204, 216, 148, 255}}},
{{{ 80, 37, -144 }, 0, { 0, 0 }, { 104, 27, 190, 255}}},
{{{ 80, -165, -144 }, 0, { 0, 0 }, { 45, 211, 147, 255}}},
{{{ -14, 37, -122 }, 0, { 0, 0 }, { 179, 41, 165, 255}}},
{{{ 80, 138, -42 }, 0, { 0, 0 }, { 55, 105, 213, 255}}},
{{{ 80, 138, 159 }, 0, { 0, 0 }, { 54, 105, 44, 255}}},
{{{ 80, 37, 261 }, 0, { 0, 0 }, { 84, 36, 87, 255}}},
{{{ 80, -266, -42 }, 0, { 0, 0 }, { 56, 152, 212, 255}}},
{{{ 80, -266, 159 }, 0, { 0, 0 }, { 91, 175, 33, 255}}},
{{{ 80, -165, 261 }, 0, { 0, 0 }, { 45, 213, 110, 255}}},
{{{ 6, 138, -31 }, 0, { 0, 0 }, { 214, 110, 211, 255}}},
{{{ -40, -266, 148 }, 0, { 0, 0 }, { 212, 148, 48, 255}}},
{{{ -40, -266, -31 }, 0, { 0, 0 }, { 181, 162, 219, 255}}},
{{{ -40, -165, 239 }, 0, { 0, 0 }, { 178, 231, 96, 255}}},
{{{ -14, 37, 239 }, 0, { 0, 0 }, { 204, 49, 104, 255}}},
{{{ 6, 138, 148 }, 0, { 0, 0 }, { 188, 101, 34, 255}}},
};

Vtx VB_king_bobomb_geo_0x500ab00[] = {
{{{ 6, 138, 148 }, 0, { 0, 0 }, { 188, 101, 34, 255}}},
{{{ 6, 138, -31 }, 0, { 0, 0 }, { 214, 110, 211, 255}}},
{{{ -75, 37, -31 }, 0, { 0, 0 }, { 142, 49, 233, 255}}},
{{{ -75, 37, 148 }, 0, { 0, 0 }, { 144, 41, 42, 255}}},
{{{ -14, 37, 239 }, 0, { 0, 0 }, { 204, 49, 104, 255}}},
{{{ -101, -165, -31 }, 0, { 0, 0 }, { 139, 239, 212, 255}}},
{{{ -101, -165, 148 }, 0, { 0, 0 }, { 135, 231, 24, 255}}},
{{{ -14, 37, -122 }, 0, { 0, 0 }, { 179, 41, 165, 255}}},
{{{ -40, -165, 239 }, 0, { 0, 0 }, { 178, 231, 96, 255}}},
{{{ -40, -266, 148 }, 0, { 0, 0 }, { 212, 148, 48, 255}}},
{{{ -40, -165, -122 }, 0, { 0, 0 }, { 204, 216, 148, 255}}},
{{{ -40, -266, -31 }, 0, { 0, 0 }, { 181, 162, 219, 255}}},
};

Vtx VB_king_bobomb_geo_0x500ad50[] = {
{{{ 6, 138, -147 }, 0, { 0, 0 }, { 214, 110, 211, 255}}},
{{{ 80, 37, -260 }, 0, { 0, 0 }, { 104, 27, 190, 255}}},
{{{ -14, 37, -238 }, 0, { 0, 0 }, { 179, 41, 165, 255}}},
{{{ 80, 138, -158 }, 0, { 0, 0 }, { 55, 105, 213, 255}}},
{{{ 80, -165, -260 }, 0, { 0, 0 }, { 45, 211, 147, 255}}},
{{{ -40, -165, -238 }, 0, { 0, 0 }, { 204, 216, 148, 255}}},
{{{ 80, 138, 43 }, 0, { 0, 0 }, { 54, 105, 44, 255}}},
{{{ 80, 37, 145 }, 0, { 0, 0 }, { 84, 36, 87, 255}}},
{{{ 80, -266, -158 }, 0, { 0, 0 }, { 56, 152, 212, 255}}},
{{{ 80, -266, 43 }, 0, { 0, 0 }, { 91, 175, 33, 255}}},
{{{ 80, -165, 145 }, 0, { 0, 0 }, { 45, 213, 110, 255}}},
{{{ -40, -266, -147 }, 0, { 0, 0 }, { 181, 162, 219, 255}}},
{{{ -40, -266, 32 }, 0, { 0, 0 }, { 212, 148, 48, 255}}},
{{{ -14, 37, 123 }, 0, { 0, 0 }, { 204, 49, 104, 255}}},
{{{ -40, -165, 123 }, 0, { 0, 0 }, { 178, 231, 96, 255}}},
{{{ 6, 138, 32 }, 0, { 0, 0 }, { 188, 101, 34, 255}}},
};

Vtx VB_king_bobomb_geo_0x500ae50[] = {
{{{ -75, 37, -147 }, 0, { 0, 0 }, { 142, 49, 233, 255}}},
{{{ -101, -165, -147 }, 0, { 0, 0 }, { 139, 239, 212, 255}}},
{{{ -101, -165, 32 }, 0, { 0, 0 }, { 135, 231, 24, 255}}},
{{{ -75, 37, 32 }, 0, { 0, 0 }, { 144, 41, 42, 255}}},
{{{ -14, 37, -238 }, 0, { 0, 0 }, { 179, 41, 165, 255}}},
{{{ 6, 138, 32 }, 0, { 0, 0 }, { 188, 101, 34, 255}}},
{{{ 6, 138, -147 }, 0, { 0, 0 }, { 214, 110, 211, 255}}},
{{{ -14, 37, 123 }, 0, { 0, 0 }, { 204, 49, 104, 255}}},
{{{ 80, 138, 43 }, 0, { 0, 0 }, { 54, 105, 44, 255}}},
{{{ -40, -165, 123 }, 0, { 0, 0 }, { 178, 231, 96, 255}}},
{{{ -40, -266, 32 }, 0, { 0, 0 }, { 212, 148, 48, 255}}},
{{{ -40, -165, -238 }, 0, { 0, 0 }, { 204, 216, 148, 255}}},
{{{ -40, -266, -147 }, 0, { 0, 0 }, { 181, 162, 219, 255}}},
};

Vtx VB_king_bobomb_geo_0x500b098[] = {
{{{ 0, 128, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -127, -127, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -127, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -127, 128, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500b0d8[] = {
{{{ 128, 128, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -127, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 128, -127, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 128, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_king_bobomb_geo_0x500b218[] = {
{{{ 124, 159, 493 }, 0, { 0, 0 }, { 0, 24, 124, 255}}},
{{{ -103, 159, 493 }, 0, { 0, 990 }, { 0, 24, 124, 255}}},
{{{ -103, 0, 524 }, 0, { 478, 990 }, { 0, 8, 126, 255}}},
{{{ 124, 0, 524 }, 0, { 478, 0 }, { 0, 248, 126, 255}}},
{{{ -103, -158, 493 }, 0, { 990, 990 }, { 0, 232, 124, 255}}},
{{{ 124, -158, 493 }, 0, { 990, 0 }, { 0, 232, 124, 255}}},
};

Vtx VB_king_bobomb_geo_0x500b348[] = {
{{{ -189, -1, 571 }, 0, { 0, 0 }, { 220, 25, 118, 255}}},
{{{ -379, 180, 438 }, 0, { 0, 0 }, { 222, 46, 112, 255}}},
{{{ -273, -1, 548 }, 0, { 0, 0 }, { 218, 237, 119, 255}}},
{{{ -379, -183, 438 }, 0, { 0, 0 }, { 215, 213, 111, 255}}},
{{{ -281, -365, 404 }, 0, { 0, 0 }, { 216, 213, 112, 255}}},
{{{ 24, -436, 485 }, 0, { 0, 0 }, { 221, 215, 114, 255}}},
{{{ 24, 432, 485 }, 0, { 0, 0 }, { 217, 42, 113, 255}}},
{{{ -281, 361, 404 }, 0, { 0, 0 }, { 217, 42, 113, 255}}},
};

Vtx VB_king_bobomb_geo_0x500b470[] = {
{{{ 729, 304, 176 }, 0, { 394, -458 }, { 239, 108, 62, 255}}},
{{{ 576, 296, 0 }, 0, { 0, 234 }, { 252, 126, 0, 255}}},
{{{ 416, 290, 0 }, 0, { -31, 962 }, { 233, 124, 0, 255}}},
{{{ 416, 145, 252 }, 0, { 820, 962 }, { 233, 62, 108, 255}}},
{{{ 576, 148, 257 }, 0, { 820, 234 }, { 252, 63, 109, 255}}},
{{{ 729, 0, 352 }, 0, { 1246, -458 }, { 239, 0, 125, 255}}},
{{{ 416, -144, 252 }, 0, { 1671, 962 }, { 233, 194, 108, 255}}},
{{{ 729, 304, -175 }, 0, { 4652, -458 }, { 238, 108, 194, 255}}},
{{{ 415, 145, -250 }, 0, { 4226, 964 }, { 233, 62, 148, 255}}},
{{{ 416, 290, 0 }, 0, { 5079, 962 }, { 233, 124, 0, 255}}},
{{{ 576, 296, 0 }, 0, { 5078, 234 }, { 252, 126, 0, 255}}},
{{{ 576, 148, -256 }, 0, { 4226, 234 }, { 251, 63, 147, 255}}},
{{{ 729, 0, -351 }, 0, { 3800, -458 }, { 238, 0, 131, 255}}},
{{{ 415, -144, -250 }, 0, { 3374, 964 }, { 233, 194, 148, 255}}},
{{{ 576, -147, -256 }, 0, { 3374, 234 }, { 251, 193, 147, 255}}},
{{{ 729, -304, -175 }, 0, { 2948, -458 }, { 238, 148, 194, 255}}},
};

Vtx VB_king_bobomb_geo_0x500b570[] = {
{{{ 729, -304, -175 }, 0, { 2948, -458 }, { 238, 148, 194, 255}}},
{{{ 415, -289, 0 }, 0, { 2522, 964 }, { 233, 132, 0, 255}}},
{{{ 415, -144, -250 }, 0, { 3374, 964 }, { 233, 194, 148, 255}}},
{{{ 576, -295, 0 }, 0, { 2523, 234 }, { 252, 130, 0, 255}}},
{{{ 729, -304, 176 }, 0, { 2097, -458 }, { 239, 148, 62, 255}}},
{{{ 416, -144, 252 }, 0, { 1671, 962 }, { 233, 194, 108, 255}}},
{{{ 576, -147, 257 }, 0, { 1671, 234 }, { 252, 193, 109, 255}}},
{{{ 729, 0, 352 }, 0, { 1246, -458 }, { 239, 0, 125, 255}}},
};

Gfx DL_king_bobomb_geo_0x500b188[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_king_bobomb_geo_0x500b118),
gsSPDisplayList(DL_king_bobomb_geo_0x500b150),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500b118[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05008478),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_king_bobomb_geo_0x500b098, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500b150[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05009478),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_king_bobomb_geo_0x500b0d8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_king_bobomb_geo_0x500a9f0 = {
{ 222, 173, 35}, 0, { 222, 173, 35}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_king_bobomb_geo_0x500a9e8 = {
{111, 86, 17}, 0, {111, 86, 17}, 0
};

Gfx DL_king_bobomb_geo_0x500ad08[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_king_bobomb_geo_0x500abc0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500abc0[] = {
gsSPLight(&Light_king_bobomb_geo_0x500a9f0.col, 1),
gsSPLight(&Light_king_bobomb_geo_0x500a9e8.col, 2),
gsSPVertex(VB_king_bobomb_geo_0x500aa00, 16, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(1, 4, 5, 0,1, 5, 6, 0),
gsSP2Triangles(1, 7, 2, 0,1, 8, 7, 0),
gsSP2Triangles(1, 9, 8, 0,1, 6, 9, 0),
gsSP2Triangles(1, 10, 4, 0,1, 3, 10, 0),
gsSP2Triangles(11, 12, 7, 0,11, 7, 8, 0),
gsSP2Triangles(7, 12, 0, 0,7, 0, 2, 0),
gsSP2Triangles(9, 11, 8, 0,10, 5, 4, 0),
gsSP2Triangles(9, 13, 11, 0,14, 13, 9, 0),
gsSP2Triangles(14, 9, 6, 0,14, 6, 5, 0),
gsSP2Triangles(14, 5, 15, 0,10, 15, 5, 0),
gsSPVertex(VB_king_bobomb_geo_0x500ab00, 12, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(3, 4, 0, 0,2, 5, 6, 0),
gsSP2Triangles(2, 6, 3, 0,2, 1, 7, 0),
gsSP2Triangles(7, 5, 2, 0,8, 4, 3, 0),
gsSP2Triangles(8, 3, 6, 0,6, 9, 8, 0),
gsSP2Triangles(7, 10, 5, 0,5, 10, 11, 0),
gsSP2Triangles(11, 6, 5, 0,11, 9, 6, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a5d8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500a5a0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a5a0[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05002078),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_king_bobomb_geo_0x500a560, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_king_bobomb_geo_0x500b208 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_king_bobomb_geo_0x500b200 = {
{63, 63, 63}, 0, {63, 63, 63}, 0
};

Gfx DL_king_bobomb_geo_0x500b2d0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500b278),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500b278[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05004878),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_king_bobomb_geo_0x500b208.col, 1),
gsSPLight(&Light_king_bobomb_geo_0x500b200.col, 2),
gsSPVertex(VB_king_bobomb_geo_0x500b218, 6, 0),
gsSP2Triangles(0, 1, 2, 0,3, 2, 4, 0),
gsSP2Triangles(2, 3, 0, 0,4, 5, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_king_bobomb_geo_0x500b338 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_king_bobomb_geo_0x500b330 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_king_bobomb_geo_0x500b418[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_king_bobomb_geo_0x500b3c8),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500b3c8[] = {
gsSPLight(&Light_king_bobomb_geo_0x500b338.col, 1),
gsSPLight(&Light_king_bobomb_geo_0x500b330.col, 2),
gsSPVertex(VB_king_bobomb_geo_0x500b348, 8, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 4, 0),
gsSP2Triangles(2, 4, 5, 0,2, 5, 0, 0),
gsSP2Triangles(0, 6, 7, 0,0, 7, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_king_bobomb_geo_0x500b460 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_king_bobomb_geo_0x500b458 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_king_bobomb_geo_0x500b6c0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 5, 0, 0, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500b5f0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500b5f0[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05006078),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 511, 512),
gsSPLight(&Light_king_bobomb_geo_0x500b460.col, 1),
gsSPLight(&Light_king_bobomb_geo_0x500b458.col, 2),
gsSPVertex(VB_king_bobomb_geo_0x500b470, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 0, 0),
gsSP2Triangles(0, 2, 3, 0,5, 4, 3, 0),
gsSP2Triangles(5, 3, 6, 0,7, 8, 9, 0),
gsSP2Triangles(9, 10, 7, 0,7, 11, 8, 0),
gsSP2Triangles(12, 13, 8, 0,8, 11, 12, 0),
gsSP2Triangles(12, 14, 13, 0,13, 14, 15, 0),
gsSPVertex(VB_king_bobomb_geo_0x500b570, 8, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(4, 5, 1, 0,1, 3, 4, 0),
gsSP2Triangles(4, 6, 5, 0,5, 6, 7, 0),
gsSPEndDisplayList(),
};

Light_t Light_king_bobomb_geo_0x500ad40 = {
{ 222, 158, 32}, 0, { 222, 158, 32}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_king_bobomb_geo_0x500ad38 = {
{111, 79, 16}, 0, {111, 79, 16}, 0
};

Gfx DL_king_bobomb_geo_0x500b068[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_king_bobomb_geo_0x500af20),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500af20[] = {
gsSPLight(&Light_king_bobomb_geo_0x500ad40.col, 1),
gsSPLight(&Light_king_bobomb_geo_0x500ad38.col, 2),
gsSPVertex(VB_king_bobomb_geo_0x500ad50, 16, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(1, 4, 5, 0,1, 5, 2, 0),
gsSP2Triangles(1, 3, 6, 0,1, 6, 7, 0),
gsSP2Triangles(1, 8, 4, 0,1, 9, 8, 0),
gsSP2Triangles(1, 10, 9, 0,1, 7, 10, 0),
gsSP2Triangles(8, 11, 5, 0,8, 9, 12, 0),
gsSP2Triangles(8, 12, 11, 0,8, 5, 4, 0),
gsSP2Triangles(10, 12, 9, 0,6, 3, 0, 0),
gsSP2Triangles(10, 13, 14, 0,10, 7, 13, 0),
gsSP2Triangles(10, 14, 12, 0,6, 13, 7, 0),
gsSP1Triangle(6, 0, 15, 0),
gsSPVertex(VB_king_bobomb_geo_0x500ae50, 13, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(1, 0, 4, 0,0, 3, 5, 0),
gsSP2Triangles(0, 5, 6, 0,6, 4, 0, 0),
gsSP2Triangles(7, 5, 3, 0,8, 5, 7, 0),
gsSP2Triangles(3, 9, 7, 0,3, 2, 9, 0),
gsSP2Triangles(10, 9, 2, 0,1, 4, 11, 0),
gsSP2Triangles(2, 12, 10, 0,2, 1, 12, 0),
gsSP1Triangle(11, 12, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a890[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500a858),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a858[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05002078),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_king_bobomb_geo_0x500a818, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a4f0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500a4b8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a4b8[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05002078),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_king_bobomb_geo_0x500a478, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a6c0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500a688),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a688[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05005878),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_king_bobomb_geo_0x500a648, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a7a8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500a770),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a770[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05002078),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_king_bobomb_geo_0x500a730, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a978[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_king_bobomb_geo_0x500a940),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_king_bobomb_geo_0x500a940[] = {
gsDPSetTextureImage(0, 2, 1, king_bobomb_geo__texture_05005878),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_king_bobomb_geo_0x500a900, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

