#include "custom.model.inc.h"
Vtx VB_bobomb_buddy_geo_0x8022a60[] = {
{{{ 133, -47, 0 }, 0, { 480, 0 }, { 255, 255, 255, 255}}},
{{{ 133, 32, 0 }, 0, { 480, 990 }, { 255, 255, 255, 255}}},
{{{ 128, 32, 50 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 128, -47, -49 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ 128, -47, 50 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 128, 32, -49 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8022bb8[] = {
{{{ 0, 49, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -49, -49, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, -49, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ -49, 49, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8022bf8[] = {
{{{ 49, 49, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ 0, -49, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
{{{ 49, -49, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
{{{ 0, 49, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8022e30[] = {
{{{ 27, -26, -31 }, 0, { 0, 0 }, { 235, 150, 191, 0}}},
{{{ -36, 0, -20 }, 0, { 0, 0 }, { 177, 208, 170, 0}}},
{{{ 32, 0, -41 }, 0, { 0, 0 }, { 252, 251, 130, 0}}},
{{{ 85, 0, -32 }, 0, { 0, 0 }, { 80, 241, 160, 255}}},
{{{ 79, 28, -20 }, 0, { 0, 0 }, { 52, 98, 196, 255}}},
{{{ 79, 28, 15 }, 0, { 0, 0 }, { 52, 98, 60, 255}}},
{{{ 85, 0, 27 }, 0, { 0, 0 }, { 80, 241, 96, 255}}},
{{{ 33, 28, 29 }, 0, { 0, 0 }, { 255, 105, 71, 255}}},
{{{ -29, 28, 12 }, 0, { 0, 0 }, { 200, 96, 60, 255}}},
{{{ -36, 0, 16 }, 0, { 0, 0 }, { 177, 208, 86, 255}}},
{{{ 32, 0, 37 }, 0, { 0, 0 }, { 252, 251, 126, 255}}},
{{{ 33, 28, -34 }, 0, { 0, 0 }, { 255, 105, 185, 255}}},
{{{ -29, 28, -16 }, 0, { 0, 0 }, { 200, 96, 196, 255}}},
{{{ 68, -30, 16 }, 0, { 0, 0 }, { 38, 149, 54, 255}}},
{{{ 68, -30, -21 }, 0, { 0, 0 }, { 38, 149, 202, 255}}},
{{{ 27, -26, 27 }, 0, { 0, 0 }, { 235, 150, 65, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8022f30[] = {
{{{ 27, -26, -31 }, 0, { 0, 0 }, { 237, 144, 200, 255}}},
{{{ 27, -26, 27 }, 0, { 0, 0 }, { 245, 162, 83, 0}}},
{{{ -36, 0, 16 }, 0, { 0, 0 }, { 162, 248, 84, 0}}},
{{{ -36, 0, -20 }, 0, { 0, 0 }, { 169, 221, 172, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8022f70[] = {
{{{ 32, 0, 41 }, 0, { 0, 0 }, { 252, 251, 126, 0}}},
{{{ -36, 0, 20 }, 0, { 0, 0 }, { 177, 208, 86, 0}}},
{{{ 27, -26, 31 }, 0, { 0, 0 }, { 235, 150, 65, 0}}},
{{{ 84, 0, -27 }, 0, { 0, 0 }, { 80, 241, 160, 255}}},
{{{ 79, 28, -15 }, 0, { 0, 0 }, { 52, 98, 196, 255}}},
{{{ 79, 28, 20 }, 0, { 0, 0 }, { 52, 98, 60, 255}}},
{{{ 84, 0, 32 }, 0, { 0, 0 }, { 80, 241, 96, 255}}},
{{{ 32, 0, -37 }, 0, { 0, 0 }, { 252, 251, 130, 255}}},
{{{ -36, 0, -16 }, 0, { 0, 0 }, { 177, 208, 170, 255}}},
{{{ -28, 28, -12 }, 0, { 0, 0 }, { 200, 96, 196, 255}}},
{{{ 33, 28, -29 }, 0, { 0, 0 }, { 255, 105, 185, 255}}},
{{{ -28, 28, 16 }, 0, { 0, 0 }, { 200, 96, 60, 255}}},
{{{ 33, 28, 33 }, 0, { 0, 0 }, { 255, 105, 71, 255}}},
{{{ 68, -29, 21 }, 0, { 0, 0 }, { 38, 149, 54, 255}}},
{{{ 68, -29, -16 }, 0, { 0, 0 }, { 38, 149, 202, 255}}},
{{{ 27, -26, -27 }, 0, { 0, 0 }, { 235, 150, 191, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8023070[] = {
{{{ 27, -26, -27 }, 0, { 0, 0 }, { 237, 144, 200, 255}}},
{{{ 27, -26, 31 }, 0, { 0, 0 }, { 245, 162, 83, 0}}},
{{{ -36, 0, 20 }, 0, { 0, 0 }, { 162, 248, 84, 0}}},
{{{ -36, 0, -16 }, 0, { 0, 0 }, { 169, 221, 172, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x80230b0[] = {
{{{ 0, -100, 59 }, 0, { 0, 0 }, { 0, 254, 127, 0}}},
{{{ -53, -99, 28 }, 0, { 0, 0 }, { 193, 254, 109, 0}}},
{{{ -53, -140, 27 }, 0, { 0, 0 }, { 193, 254, 109, 0}}},
{{{ 0, -141, 58 }, 0, { 0, 0 }, { 0, 254, 127, 255}}},
{{{ 53, -99, 28 }, 0, { 0, 0 }, { 63, 254, 109, 255}}},
{{{ 53, -140, 27 }, 0, { 0, 0 }, { 63, 254, 109, 255}}},
{{{ -53, -99, 28 }, 0, { 0, 0 }, { 129, 0, 0, 255}}},
{{{ -53, -98, -32 }, 0, { 0, 0 }, { 129, 0, 0, 255}}},
{{{ -53, -139, -33 }, 0, { 0, 0 }, { 129, 0, 0, 255}}},
{{{ -53, -140, 27 }, 0, { 0, 0 }, { 129, 0, 0, 255}}},
{{{ -53, -98, -32 }, 0, { 0, 0 }, { 193, 2, 147, 255}}},
{{{ 0, -97, -63 }, 0, { 0, 0 }, { 193, 2, 147, 255}}},
{{{ 0, -138, -64 }, 0, { 0, 0 }, { 193, 2, 147, 255}}},
{{{ -53, -139, -33 }, 0, { 0, 0 }, { 193, 2, 147, 255}}},
};

Vtx VB_bobomb_buddy_geo_0x8023190[] = {
{{{ 53, -98, -32 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 53, -99, 28 }, 0, { 0, 0 }, { 127, 0, 0, 0}}},
{{{ 53, -140, 27 }, 0, { 0, 0 }, { 127, 0, 0, 0}}},
{{{ 53, -139, -33 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 0, -97, -63 }, 0, { 0, 0 }, { 63, 2, 147, 255}}},
{{{ 53, -98, -32 }, 0, { 0, 0 }, { 63, 2, 147, 255}}},
{{{ 53, -139, -33 }, 0, { 0, 0 }, { 63, 2, 147, 255}}},
{{{ 0, -138, -64 }, 0, { 0, 0 }, { 63, 2, 147, 255}}},
{{{ 0, -138, -64 }, 0, { 0, 0 }, { 0, 129, 254, 255}}},
{{{ 53, -139, -33 }, 0, { 0, 0 }, { 0, 129, 254, 255}}},
{{{ 53, -140, 27 }, 0, { 0, 0 }, { 0, 129, 254, 255}}},
{{{ 0, -141, 58 }, 0, { 0, 0 }, { 0, 129, 254, 255}}},
{{{ -53, -140, 27 }, 0, { 0, 0 }, { 0, 129, 254, 255}}},
{{{ -53, -139, -33 }, 0, { 0, 0 }, { 0, 129, 254, 255}}},
};

Gfx DL_black_bobomb_geo_0x8022d08[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_black_bobomb_geo_0x8022c38),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_black_bobomb_geo_0x8022c38[] = {
gsDPSetTextureImage(0, 2, 1, black_bobomb_geo__texture_0801DA60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_black_bobomb_geo_0x8022bb8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsDPSetTextureImage(0, 2, 1, black_bobomb_geo__texture_0801EA60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_black_bobomb_geo_0x8022bf8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Light_t Light_black_bobomb_geo_0x8022df0 = {
{ 255, 153, 18}, 0, { 255, 153, 18}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_black_bobomb_geo_0x8022de8 = {
{63, 38, 4}, 0, {63, 38, 4}, 0
};

Gfx DL_black_bobomb_geo_0x8023270[] = {
gsSPLight(&Light_black_bobomb_geo_0x8022df0.col, 1),
gsSPLight(&Light_black_bobomb_geo_0x8022de8.col, 2),
gsSPVertex(VB_black_bobomb_geo_0x8022e30, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 5, 6, 0,7, 8, 9, 0),
gsSP2Triangles(7, 9, 10, 0,11, 12, 8, 0),
gsSP2Triangles(11, 8, 7, 0,6, 13, 14, 0),
gsSP2Triangles(6, 14, 3, 0,9, 8, 12, 0),
gsSP2Triangles(9, 12, 1, 0,10, 9, 15, 0),
gsSP2Triangles(2, 1, 12, 0,2, 12, 11, 0),
gsSP2Triangles(10, 6, 5, 0,10, 5, 7, 0),
gsSP2Triangles(0, 14, 13, 0,0, 13, 15, 0),
gsSP2Triangles(11, 4, 3, 0,11, 3, 2, 0),
gsSP2Triangles(2, 3, 14, 0,2, 14, 0, 0),
gsSP2Triangles(7, 5, 4, 0,7, 4, 11, 0),
gsSP2Triangles(15, 13, 6, 0,15, 6, 10, 0),
gsSPVertex(VB_black_bobomb_geo_0x8022f30, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_black_bobomb_geo_0x8023378[] = {
gsSPLight(&Light_black_bobomb_geo_0x8022df0.col, 1),
gsSPLight(&Light_black_bobomb_geo_0x8022de8.col, 2),
gsSPVertex(VB_black_bobomb_geo_0x8022f70, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 5, 6, 0,7, 8, 9, 0),
gsSP2Triangles(7, 9, 10, 0,10, 9, 11, 0),
gsSP2Triangles(10, 11, 12, 0,6, 13, 14, 0),
gsSP2Triangles(6, 14, 3, 0,1, 11, 9, 0),
gsSP2Triangles(1, 9, 8, 0,15, 8, 7, 0),
gsSP2Triangles(12, 11, 1, 0,12, 1, 0, 0),
gsSP2Triangles(10, 4, 3, 0,10, 3, 7, 0),
gsSP2Triangles(15, 14, 13, 0,15, 13, 2, 0),
gsSP2Triangles(0, 6, 5, 0,0, 5, 12, 0),
gsSP2Triangles(2, 13, 6, 0,2, 6, 0, 0),
gsSP2Triangles(12, 5, 4, 0,12, 4, 10, 0),
gsSP2Triangles(7, 3, 14, 0,7, 14, 15, 0),
gsSPVertex(VB_black_bobomb_geo_0x8023070, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_black_bobomb_geo_0x8022e08 = {
{ 178, 178, 178}, 0, { 178, 178, 178}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_black_bobomb_geo_0x8022e00 = {
{44, 44, 44}, 0, {44, 44, 44}, 0
};

Gfx DL_black_bobomb_geo_0x8023480[] = {
gsSPLight(&Light_black_bobomb_geo_0x8022e08.col, 1),
gsSPLight(&Light_black_bobomb_geo_0x8022e00.col, 2),
gsSPVertex(VB_black_bobomb_geo_0x80230b0, 14, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 0, 3, 0,4, 3, 5, 0),
gsSP2Triangles(6, 7, 8, 0,6, 8, 9, 0),
gsSP2Triangles(10, 11, 12, 0,10, 12, 13, 0),
gsSPVertex(VB_black_bobomb_geo_0x8023190, 14, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,4, 6, 7, 0),
gsSP2Triangles(8, 9, 10, 0,8, 10, 11, 0),
gsSP2Triangles(8, 11, 12, 0,8, 12, 13, 0),
gsSPEndDisplayList(),
};

Gfx DL_black_bobomb_geo_0x8022b58[] = {
gsSPDisplayList(DL_black_bobomb_geo_0x8022ac0),
gsDPSetTextureImage(0, 2, 1, black_bobomb_geo__texture_08021A60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPDisplayList(DL_black_bobomb_geo_0x8022b08),
gsSPEndDisplayList(),
};

Gfx DL_black_bobomb_geo_0x8022ac0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPEndDisplayList(),
};

Gfx DL_black_bobomb_geo_0x8022b08[] = {
gsSPVertex(VB_black_bobomb_geo_0x8022a60, 6, 0),
gsSP2Triangles(0, 1, 2, 0,3, 1, 0, 0),
gsSP2Triangles(0, 2, 4, 0,3, 5, 1, 0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_black_bobomb_geo_0x8022b88[] = {
gsSPDisplayList(DL_black_bobomb_geo_0x8022ac0),
gsDPSetTextureImage(0, 2, 1, black_bobomb_geo__texture_08022260),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPDisplayList(DL_black_bobomb_geo_0x8022b08),
gsSPEndDisplayList(),
};

Gfx DL_bobomb_buddy_geo_0x8022d78[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_bobomb_buddy_geo_0x8022ca0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_bobomb_buddy_geo_0x8022ca0[] = {
gsDPSetTextureImage(0, 2, 1, bobomb_buddy_geo__texture_0801FA60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_bobomb_buddy_geo_0x8022bb8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsDPSetTextureImage(0, 2, 1, bobomb_buddy_geo__texture_08020A60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_bobomb_buddy_geo_0x8022bf8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

