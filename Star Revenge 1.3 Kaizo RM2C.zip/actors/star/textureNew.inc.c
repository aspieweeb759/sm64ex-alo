ALIGNED8 u8 star_geo__texture_0302A6F0[] = {
#include "actors/star/star_geo_0x302a6f0_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_0302AEF0[] = {
#include "actors/star/star_geo_0x302aef0_custom.rgba16.inc.c"
};
