#ifndef star_star_model_HEADER_H
#define star_star_model_HEADER_H
#include "types.h"
extern Vtx VB_star_geo_0x302b6f0[];
extern Vtx VB_star_geo_0x302b920[];
extern u8 star_geo__texture_0302A6F0[];
extern Light_t Light_star_geo_0x302a6e0;
extern Ambient_t Light_star_geo_0x302a6d8;
extern Gfx DL_star_geo_0x302b870[];
extern Gfx DL_star_geo_0x302b7b0[];
extern u8 star_geo__texture_0302AEF0[];
extern Light_t Light_star_geo_0x302b910;
extern Ambient_t Light_star_geo_0x302b908;
extern Gfx DL_star_geo_0x302ba18[];
extern Gfx DL_star_geo_0x302b9c0[];
#endif