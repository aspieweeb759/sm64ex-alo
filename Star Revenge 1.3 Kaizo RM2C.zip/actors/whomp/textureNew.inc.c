ALIGNED8 u8 whomp_geo__texture_0601EB60[] = {
#include "actors/whomp/whomp_geo_0x601eb60_custom.rgba16.inc.c"
};
ALIGNED8 u8 whomp_geo__texture_0601C360[] = {
#include "actors/whomp/whomp_geo_0x601c360_custom.rgba16.inc.c"
};
ALIGNED8 u8 whomp_geo__texture_0601D360[] = {
#include "actors/whomp/whomp_geo_0x601d360_custom.rgba16.inc.c"
};
ALIGNED8 u8 whomp_geo__texture_0601E360[] = {
#include "actors/whomp/whomp_geo_0x601e360_custom.rgba16.inc.c"
};
