#ifndef whomp_whomp_model_HEADER_H
#define whomp_whomp_model_HEADER_H
#include "types.h"
extern Vtx VB_whomp_geo_0x601f378[];
extern Vtx VB_whomp_geo_0x601f478[];
extern Vtx VB_whomp_geo_0x601f4b8[];
extern Vtx VB_whomp_geo_0x601f690[];
extern Vtx VB_whomp_geo_0x601f780[];
extern Vtx VB_whomp_geo_0x601f8f8[];
extern Vtx VB_whomp_geo_0x601f9e8[];
extern Vtx VB_whomp_geo_0x601fb48[];
extern Vtx VB_whomp_geo_0x601fc30[];
extern Vtx VB_whomp_geo_0x601fd30[];
extern Vtx VB_whomp_geo_0x601ff20[];
extern u8 whomp_geo__texture_0601EB60[];
extern u8 whomp_geo__texture_0601C360[];
extern u8 whomp_geo__texture_0601D360[];
extern Light_t Light_whomp_geo_0x601f368;
extern Ambient_t Light_whomp_geo_0x601f360;
extern Gfx DL_whomp_geo_0x601f5e0[];
extern Gfx DL_whomp_geo_0x601f4f8[];
extern Gfx DL_whomp_geo_0x601f570[];
extern Gfx DL_whomp_geo_0x601f5a8[];
extern Light_t Light_whomp_geo_0x601fd20;
extern Ambient_t Light_whomp_geo_0x601fd18;
extern Gfx DL_whomp_geo_0x601fea8[];
extern Gfx DL_whomp_geo_0x601fe10[];
extern Light_t Light_whomp_geo_0x601ff10;
extern Ambient_t Light_whomp_geo_0x601ff08;
extern Gfx DL_whomp_geo_0x6020038[];
extern Gfx DL_whomp_geo_0x601ffa0[];
extern Light_t Light_whomp_geo_0x601f680;
extern Ambient_t Light_whomp_geo_0x601f678;
extern Gfx DL_whomp_geo_0x601f880[];
extern Gfx DL_whomp_geo_0x601f7f0[];
extern u8 whomp_geo__texture_0601E360[];
extern Gfx DL_whomp_geo_0x601fbc0[];
extern Gfx DL_whomp_geo_0x601fb88[];
extern Light_t Light_whomp_geo_0x601f8e8;
extern Ambient_t Light_whomp_geo_0x601f8e0;
extern Gfx DL_whomp_geo_0x601fae8[];
extern Gfx DL_whomp_geo_0x601fa58[];
extern Gfx DL_whomp_geo_0x601fca8[];
extern Gfx DL_whomp_geo_0x601fc70[];
#endif