#include "custom.model.inc.h"
Vtx VB_whomp_geo_0x601f378[] = {
{{{ -52, 610, -201 }, 0, { 470, 990 }, { 0, 126, 0, 255}}},
{{{ -52, 610, 202 }, 0, { 0, 2012 }, { 0, 126, 0, 255}}},
{{{ 1559, 600, 202 }, 0, { 0, -1022 }, { 0, 126, 0, 255}}},
{{{ 1559, 600, -201 }, 0, { 0, 320 }, { 126, 0, 0, 255}}},
{{{ 1551, -609, 202 }, 0, { 1980, 990 }, { 126, 0, 0, 255}}},
{{{ 1551, -609, -201 }, 0, { 1980, 320 }, { 126, 0, 0, 255}}},
{{{ 1559, 600, 202 }, 0, { 0, 990 }, { 126, 0, 0, 255}}},
{{{ -60, -598, -201 }, 0, { 1962, 320 }, { 130, 0, 0, 255}}},
{{{ -52, 610, 202 }, 0, { -48, 990 }, { 130, 0, 0, 255}}},
{{{ -52, 610, -201 }, 0, { -48, 320 }, { 130, 0, 0, 255}}},
{{{ -60, -598, 202 }, 0, { 1962, 990 }, { 130, 0, 0, 255}}},
{{{ -60, -598, 202 }, 0, { 0, 990 }, { 0, 130, 0, 255}}},
{{{ -60, -598, -201 }, 0, { 470, 990 }, { 0, 130, 0, 255}}},
{{{ 1551, -609, -201 }, 0, { 470, -1022 }, { 0, 130, 0, 255}}},
{{{ 1551, -609, 202 }, 0, { 0, -1022 }, { 0, 130, 0, 255}}},
{{{ 1559, 600, -201 }, 0, { 470, -1022 }, { 0, 126, 0, 255}}},
};

Vtx VB_whomp_geo_0x601f478[] = {
{{{ -60, -598, -201 }, 0, { 0, 2012 }, { 0, 0, 129, 255}}},
{{{ 1559, 600, -201 }, 0, { 990, 0 }, { 0, 0, 129, 255}}},
{{{ 1551, -609, -201 }, 0, { 0, 0 }, { 0, 0, 129, 255}}},
{{{ -52, 610, -201 }, 0, { 990, 2012 }, { 0, 0, 129, 255}}},
};

Vtx VB_whomp_geo_0x601f4b8[] = {
{{{ -52, 610, 202 }, 0, { 0, 2012 }, { 0, 0, 127, 255}}},
{{{ -60, -598, 202 }, 0, { 990, 2012 }, { 0, 0, 127, 255}}},
{{{ 1551, -609, 202 }, 0, { 990, 0 }, { 0, 0, 127, 255}}},
{{{ 1559, 600, 202 }, 0, { 0, 0 }, { 0, 0, 127, 255}}},
};

Vtx VB_whomp_geo_0x601f690[] = {
{{{ 290, 0, 85 }, 0, { 952, 0 }, { 237, 28, 122, 255}}},
{{{ -10, 35, 13 }, 0, { 246, 976 }, { 237, 106, 65, 255}}},
{{{ -10, 0, 38 }, 0, { 672, 976 }, { 237, 227, 121, 255}}},
{{{ 290, 80, 28 }, 0, { 952, 0 }, { 237, 125, 8, 255}}},
{{{ -10, 21, -27 }, 0, { 246, 976 }, { 237, 94, 174, 255}}},
{{{ -10, 35, 13 }, 0, { 672, 976 }, { 237, 106, 65, 255}}},
{{{ 290, 49, -65 }, 0, { 0, 0 }, { 237, 47, 140, 255}}},
{{{ 290, 49, -65 }, 0, { 952, 0 }, { 237, 47, 140, 255}}},
{{{ -10, -20, -27 }, 0, { 246, 976 }, { 237, 209, 140, 255}}},
{{{ -10, 21, -27 }, 0, { 672, 976 }, { 237, 94, 174, 255}}},
{{{ 290, -48, -65 }, 0, { 0, 0 }, { 237, 162, 174, 255}}},
{{{ 290, -79, 28 }, 0, { 952, 0 }, { 237, 149, 65, 255}}},
{{{ 290, 0, 85 }, 0, { 0, 0 }, { 237, 28, 122, 255}}},
{{{ -10, 0, 38 }, 0, { 246, 976 }, { 237, 227, 121, 255}}},
{{{ -10, -34, 13 }, 0, { 672, 976 }, { 237, 131, 8, 255}}},
};

Vtx VB_whomp_geo_0x601f780[] = {
{{{ 290, -48, -65 }, 0, { 952, 0 }, { 237, 162, 174, 255}}},
{{{ 290, -79, 28 }, 0, { 0, 0 }, { 237, 149, 65, 255}}},
{{{ -10, -34, 13 }, 0, { 246, 976 }, { 237, 131, 8, 255}}},
{{{ 290, 0, 85 }, 0, { 952, 0 }, { 237, 28, 122, 255}}},
{{{ 290, 80, 28 }, 0, { 0, 0 }, { 237, 125, 8, 255}}},
{{{ -10, 35, 13 }, 0, { 246, 976 }, { 237, 106, 65, 255}}},
{{{ -10, -20, -27 }, 0, { 672, 976 }, { 237, 209, 140, 255}}},
};

Vtx VB_whomp_geo_0x601f8f8[] = {
{{{ -10, 0, -37 }, 0, { 246, 976 }, { 237, 28, 134, 255}}},
{{{ 290, 80, -26 }, 0, { 952, 0 }, { 237, 106, 191, 255}}},
{{{ 290, 0, -84 }, 0, { 0, 0 }, { 237, 226, 135, 255}}},
{{{ -10, 35, -12 }, 0, { 246, 976 }, { 237, 125, 248, 255}}},
{{{ 290, 49, 66 }, 0, { 952, 0 }, { 237, 94, 82, 255}}},
{{{ 290, 80, -26 }, 0, { 0, 0 }, { 237, 106, 191, 255}}},
{{{ -10, 21, 28 }, 0, { 672, 976 }, { 237, 47, 116, 255}}},
{{{ -10, 21, 28 }, 0, { 246, 976 }, { 237, 47, 116, 255}}},
{{{ 290, -48, 66 }, 0, { 952, 0 }, { 237, 209, 116, 255}}},
{{{ 290, 49, 66 }, 0, { 0, 0 }, { 237, 94, 82, 255}}},
{{{ -10, -20, 28 }, 0, { 672, 976 }, { 237, 162, 82, 255}}},
{{{ -10, -34, -12 }, 0, { 246, 976 }, { 237, 149, 192, 255}}},
{{{ -10, 0, -37 }, 0, { 672, 976 }, { 237, 28, 134, 255}}},
{{{ 290, 0, -84 }, 0, { 952, 0 }, { 237, 226, 135, 255}}},
{{{ 290, -79, -26 }, 0, { 0, 0 }, { 237, 131, 249, 255}}},
};

Vtx VB_whomp_geo_0x601f9e8[] = {
{{{ -10, -20, 28 }, 0, { 246, 976 }, { 237, 162, 82, 255}}},
{{{ -10, -34, -12 }, 0, { 672, 976 }, { 237, 149, 192, 255}}},
{{{ 290, -79, -26 }, 0, { 952, 0 }, { 237, 131, 249, 255}}},
{{{ -10, 0, -37 }, 0, { 246, 976 }, { 237, 28, 134, 255}}},
{{{ -10, 35, -12 }, 0, { 672, 976 }, { 237, 125, 248, 255}}},
{{{ 290, 80, -26 }, 0, { 952, 0 }, { 237, 106, 191, 255}}},
{{{ 290, -48, 66 }, 0, { 0, 0 }, { 237, 209, 116, 255}}},
};

Vtx VB_whomp_geo_0x601fb48[] = {
{{{ -37, -37, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 38, -37, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 38, 38, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -37, 38, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_whomp_geo_0x601fc30[] = {
{{{ -37, -37, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 38, -37, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 38, 38, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
{{{ -37, 38, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_whomp_geo_0x601fd30[] = {
{{{ 174, 183, 177 }, 0, { 1364, 114 }, { 1, 62, 110, 255}}},
{{{ 180, 257, 2 }, 0, { 490, -34 }, { 70, 105, 0, 255}}},
{{{ 22, 158, 2 }, 0, { 490, 162 }, { 155, 76, 255, 255}}},
{{{ -28, -89, 2 }, 0, { 490, 658 }, { 132, 231, 0, 255}}},
{{{ 177, 182, -171 }, 0, { -376, 116 }, { 201, 57, 157, 255}}},
{{{ 154, -260, 3 }, 0, { 492, 998 }, { 233, 132, 1, 255}}},
{{{ 158, -143, 201 }, 0, { 1482, 768 }, { 56, 198, 97, 255}}},
{{{ 161, -152, -190 }, 0, { -470, 784 }, { 113, 223, 211, 255}}},
{{{ 161, -152, -190 }, 0, { -2, 774 }, { 113, 223, 211, 255}}},
{{{ 174, 183, 177 }, 0, { 916, 104 }, { 1, 62, 110, 255}}},
{{{ 158, -143, 201 }, 0, { 974, 756 }, { 56, 198, 97, 255}}},
{{{ 180, 257, 2 }, 0, { 478, -46 }, { 70, 105, 0, 255}}},
{{{ 177, 182, -171 }, 0, { 44, 104 }, { 201, 57, 157, 255}}},
{{{ 154, -260, 3 }, 0, { 480, 990 }, { 233, 132, 1, 255}}},
};

Vtx VB_whomp_geo_0x601ff20[] = {
{{{ 154, -260, -2 }, 0, { 470, 998 }, { 110, 195, 255, 255}}},
{{{ 174, 183, -176 }, 0, { -110, 114 }, { 1, 62, 146, 255}}},
{{{ 180, 257, -1 }, 0, { 472, -34 }, { 70, 105, 0, 255}}},
{{{ 158, -143, -200 }, 0, { -188, 768 }, { 223, 196, 150, 255}}},
{{{ 22, 158, -1 }, 0, { 472, 162 }, { 155, 76, 1, 255}}},
{{{ -28, -89, -1 }, 0, { 472, 658 }, { 132, 231, 0, 255}}},
{{{ 177, 182, 172 }, 0, { 1050, 116 }, { 3, 61, 111, 255}}},
{{{ 161, -152, 191 }, 0, { 1112, 784 }, { 225, 194, 106, 255}}},
};

Light_t Light_whomp_geo_0x601f368 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_whomp_geo_0x601f360 = {
{76, 76, 76}, 0, {76, 76, 76}, 0
};

Gfx DL_whomp_geo_0x601f5e0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsSPGeometryMode(G_SHADING_SMOOTH, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601f4f8),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPDisplayList(DL_whomp_geo_0x601f570),
gsSPDisplayList(DL_whomp_geo_0x601f5a8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601f4f8[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601EB60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_whomp_geo_0x601f368.col, 1),
gsSPLight(&Light_whomp_geo_0x601f360.col, 2),
gsSPVertex(VB_whomp_geo_0x601f378, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 6, 4, 0,7, 8, 9, 0),
gsSP2Triangles(7, 10, 8, 0,11, 12, 13, 0),
gsSP2Triangles(11, 13, 14, 0,0, 2, 15, 0),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601f570[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601C360),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_whomp_geo_0x601f478, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601f5a8[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601D360),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPVertex(VB_whomp_geo_0x601f4b8, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_whomp_geo_0x601fd20 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_whomp_geo_0x601fd18 = {
{76, 76, 76}, 0, {76, 76, 76}, 0
};

Gfx DL_whomp_geo_0x601fea8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601fe10),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601fe10[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601EB60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_whomp_geo_0x601fd20.col, 1),
gsSPLight(&Light_whomp_geo_0x601fd18.col, 2),
gsSPVertex(VB_whomp_geo_0x601fd30, 14, 0),
gsSP2Triangles(0, 1, 2, 0,2, 3, 0, 0),
gsSP2Triangles(2, 1, 4, 0,4, 3, 2, 0),
gsSP2Triangles(5, 6, 3, 0,3, 6, 0, 0),
gsSP2Triangles(3, 7, 5, 0,4, 7, 3, 0),
gsSP2Triangles(8, 9, 10, 0,8, 11, 9, 0),
gsSP2Triangles(8, 12, 11, 0,8, 10, 13, 0),
gsSPEndDisplayList(),
};

Light_t Light_whomp_geo_0x601ff10 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_whomp_geo_0x601ff08 = {
{76, 76, 76}, 0, {76, 76, 76}, 0
};

Gfx DL_whomp_geo_0x6020038[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601ffa0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601ffa0[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601EB60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_whomp_geo_0x601ff10.col, 1),
gsSPLight(&Light_whomp_geo_0x601ff08.col, 2),
gsSPVertex(VB_whomp_geo_0x601ff20, 8, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(4, 2, 1, 0,1, 5, 4, 0),
gsSP2Triangles(1, 3, 5, 0,5, 3, 0, 0),
gsSP2Triangles(4, 5, 6, 0,0, 7, 5, 0),
gsSP2Triangles(5, 7, 6, 0,6, 2, 4, 0),
gsSP2Triangles(0, 2, 6, 0,0, 6, 7, 0),
gsSPEndDisplayList(),
};

Light_t Light_whomp_geo_0x601f680 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_whomp_geo_0x601f678 = {
{76, 76, 76}, 0, {76, 76, 76}, 0
};

Gfx DL_whomp_geo_0x601f880[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601f7f0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601f7f0[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601EB60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_whomp_geo_0x601f680.col, 1),
gsSPLight(&Light_whomp_geo_0x601f678.col, 2),
gsSPVertex(VB_whomp_geo_0x601f690, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 6, 4, 0,7, 8, 9, 0),
gsSP2Triangles(7, 10, 8, 0,11, 12, 13, 0),
gsSP1Triangle(11, 13, 14, 0),
gsSPVertex(VB_whomp_geo_0x601f780, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP1Triangle(0, 2, 6, 0),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601fbc0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601fb88),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601fb88[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601E360),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_whomp_geo_0x601fb48, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Light_t Light_whomp_geo_0x601f8e8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_whomp_geo_0x601f8e0 = {
{76, 76, 76}, 0, {76, 76, 76}, 0
};

Gfx DL_whomp_geo_0x601fae8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601fa58),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601fa58[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601EB60),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_whomp_geo_0x601f8e8.col, 1),
gsSPLight(&Light_whomp_geo_0x601f8e0.col, 2),
gsSPVertex(VB_whomp_geo_0x601f8f8, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(3, 6, 4, 0,7, 8, 9, 0),
gsSP2Triangles(7, 10, 8, 0,11, 12, 13, 0),
gsSP1Triangle(11, 13, 14, 0),
gsSPVertex(VB_whomp_geo_0x601f9e8, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP1Triangle(0, 2, 6, 0),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601fca8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_whomp_geo_0x601fc70),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_whomp_geo_0x601fc70[] = {
gsDPSetTextureImage(0, 2, 1, whomp_geo__texture_0601E360),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_whomp_geo_0x601fc30, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

