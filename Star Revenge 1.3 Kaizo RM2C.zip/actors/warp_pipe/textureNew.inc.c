ALIGNED8 u8 warp_pipe_geo__texture_03007E40[] = {
#include "actors/warp_pipe/warp_pipe_geo_0x3007e40_custom.rgba16.inc.c"
};
ALIGNED8 u8 warp_pipe_geo__texture_03009168[] = {
#include "actors/warp_pipe/warp_pipe_geo_0x3009168_custom.rgba16.inc.c"
};
