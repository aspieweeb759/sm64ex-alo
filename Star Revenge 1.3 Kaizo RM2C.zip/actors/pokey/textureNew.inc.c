ALIGNED8 u8 pokey_head_geo__texture_05011750[] = {
#include "actors/pokey/pokey_head_geo_0x5011750_custom.rgba16.inc.c"
};
ALIGNED8 u8 pokey_head_geo__texture_05011F50[] = {
#include "actors/pokey/pokey_head_geo_0x5011f50_custom.rgba16.inc.c"
};
ALIGNED8 u8 pokey_body_part_geo__texture_05012878[] = {
#include "actors/pokey/pokey_body_part_geo_0x5012878_custom.rgba16.inc.c"
};
