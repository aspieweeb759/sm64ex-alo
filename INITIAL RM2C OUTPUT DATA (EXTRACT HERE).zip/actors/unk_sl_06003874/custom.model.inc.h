#ifndef unk_sl_06003874_unk_sl_06003874_model_HEADER_H
#define unk_sl_06003874_unk_sl_06003874_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_06003874_0x6002860[];
extern Vtx VB_unk_DL_06003874_0x6002940[];
extern Vtx VB_unk_DL_06003874_0x6002980[];
extern Vtx VB_unk_DL_06003874_0x6002a60[];
extern Vtx VB_unk_DL_06003874_0x6002aa0[];
extern Vtx VB_unk_DL_06003874_0x6002e00[];
extern Vtx VB_unk_DL_06003874_0x6002e40[];
extern Vtx VB_unk_DL_06003874_0x6002f68[];
extern Light_t Light_unk_DL_06003874_0x6000008;
extern Ambient_t Light_unk_DL_06003874_0x6000000;
extern Gfx DL_unk_DL_06003874_0x6002b30[];
extern Light_t Light_unk_DL_06003874_0x6000020;
extern Ambient_t Light_unk_DL_06003874_0x6000018;
extern Gfx DL_unk_DL_06003874_0x6002bc8[];
extern u8 unk_DL_06003874__texture_06000060[];
extern u8 unk_DL_06003874__texture_06001060[];
extern Gfx DL_unk_DL_06003874_0x6002ef0[];
extern Gfx DL_unk_DL_06003874_0x6002e80[];
extern Gfx DL_unk_DL_06003874_0x6002eb8[];
extern Light_t Light_unk_DL_06003874_0x6000038;
extern Ambient_t Light_unk_DL_06003874_0x6000030;
extern Gfx DL_unk_DL_06003874_0x6002c60[];
extern u8 unk_DL_06003874__texture_06002060[];
extern Gfx DL_unk_DL_06003874_0x6003010[];
extern Gfx DL_unk_DL_06003874_0x6002fc8[];
#endif