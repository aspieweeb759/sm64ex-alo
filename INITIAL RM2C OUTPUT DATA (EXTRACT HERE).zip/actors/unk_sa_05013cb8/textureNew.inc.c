ALIGNED8 u8 unk_DL_05013cb8__texture_05012848[] = {
#include "actors/unk_sa_05013cb8/unk_DL_05013cb8_0x5012848_custom.ia16.inc.c"
};
