#ifndef unk_bits_16000388_unk_bits_16000388_model_HEADER_H
#define unk_bits_16000388_unk_bits_16000388_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_16000388_0x3007a00[];
extern Vtx VB_unk_DL_16000388_0x3007af0[];
extern Vtx VB_unk_DL_16000388_0x3007be0[];
extern Vtx VB_unk_DL_16000388_0x3007cd0[];
extern Vtx VB_unk_DL_16000388_0x3007dc0[];
extern Vtx VB_unk_DL_16000388_0x3009028[];
extern Vtx VB_unk_DL_16000388_0x3009128[];
extern u8 unk_DL_16000388__texture_03007E40[];
extern Light_t Light_unk_DL_16000388_0x30079f0;
extern Ambient_t Light_unk_DL_16000388_0x30079e8;
extern Gfx DL_unk_DL_16000388_0x3008f98[];
extern Gfx DL_unk_DL_16000388_0x3008e40[];
extern u8 unk_DL_16000388__texture_03009168[];
extern Light_t Light_unk_DL_16000388_0x3009000;
extern Light_t Light_unk_DL_16000388_0x3009018;
extern Ambient_t Light_unk_DL_16000388_0x3008ff8;
extern Ambient_t Light_unk_DL_16000388_0x3009010;
extern Gfx DL_unk_DL_16000388_0x3009a50[];
extern Gfx DL_unk_DL_16000388_0x3009968[];
extern Gfx DL_unk_DL_16000388_0x3009a20[];
#endif