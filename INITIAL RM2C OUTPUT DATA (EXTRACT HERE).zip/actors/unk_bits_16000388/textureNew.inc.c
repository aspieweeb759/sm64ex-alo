ALIGNED8 u8 unk_DL_16000388__texture_03007E40[] = {
#include "actors/unk_bits_16000388/unk_DL_16000388_0x3007e40_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_16000388__texture_03009168[] = {
#include "actors/unk_bits_16000388/unk_DL_16000388_0x3009168_custom.rgba16.inc.c"
};
