#include "custom.model.inc.h"
const GeoLayout unk_DL_0d0000b0[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_BILLBOARD_WITH_PARAMS(0,0,0,0),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_unk_DL_0d0000b0_0x601f3c0),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
