#ifndef unk_bowser_1_0d0000b0_unk_bowser_1_0d0000b0_model_HEADER_H
#define unk_bowser_1_0d0000b0_unk_bowser_1_0d0000b0_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_0d0000b0_0x601eb48[];
extern u8 unk_DL_0d0000b0__texture_0601EB88[];
extern Gfx DL_unk_DL_0d0000b0_0x601f3c0[];
extern Gfx DL_unk_DL_0d0000b0_0x601f388[];
#endif