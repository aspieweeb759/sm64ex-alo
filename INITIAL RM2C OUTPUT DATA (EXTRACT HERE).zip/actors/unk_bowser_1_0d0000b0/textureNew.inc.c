ALIGNED8 u8 unk_DL_0d0000b0__texture_0601EB88[] = {
#include "actors/unk_bowser_1_0d0000b0/unk_DL_0d0000b0_0x601eb88_custom.rgba16.inc.c"
};
