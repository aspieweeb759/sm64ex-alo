ALIGNED8 u8 unk_DL_05002e00__texture_05001C48[] = {
#include "actors/unk_wf_05002e00/unk_DL_05002e00_0x5001c48_custom.ia16.inc.c"
};
