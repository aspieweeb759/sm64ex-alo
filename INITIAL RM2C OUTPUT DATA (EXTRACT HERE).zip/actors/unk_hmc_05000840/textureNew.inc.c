ALIGNED8 u8 unk_DL_05000840__texture_05000040[] = {
#include "actors/unk_hmc_05000840/unk_DL_05000840_0x5000040_custom.ia16.inc.c"
};
