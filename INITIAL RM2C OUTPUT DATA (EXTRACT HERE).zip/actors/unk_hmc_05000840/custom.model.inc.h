#ifndef unk_hmc_05000840_unk_hmc_05000840_model_HEADER_H
#define unk_hmc_05000840_unk_hmc_05000840_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_05000840_0x5000000[];
extern u8 unk_DL_05000840__texture_05000040[];
extern Gfx DL_unk_DL_05000840_0x5000840[];
#endif