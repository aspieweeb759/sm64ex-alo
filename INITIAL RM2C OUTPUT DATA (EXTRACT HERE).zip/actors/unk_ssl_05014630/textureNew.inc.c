ALIGNED8 u8 unk_DL_05014630__texture_05013128[] = {
#include "actors/unk_ssl_05014630/unk_DL_05014630_0x5013128_custom.ia16.inc.c"
};
