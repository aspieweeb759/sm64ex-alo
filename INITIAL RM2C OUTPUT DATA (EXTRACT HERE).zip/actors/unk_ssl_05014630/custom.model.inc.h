#ifndef unk_ssl_05014630_unk_ssl_05014630_model_HEADER_H
#define unk_ssl_05014630_unk_ssl_05014630_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_05014630_0x5014140[];
extern Vtx VB_unk_DL_05014630_0x5014220[];
extern Vtx VB_unk_DL_05014630_0x5014320[];
extern Vtx VB_unk_DL_05014630_0x5014400[];
extern u8 unk_DL_05014630__texture_05013128[];
extern Light_t Light_unk_DL_05014630_0x5014130;
extern Ambient_t Light_unk_DL_05014630_0x5014128;
extern Gfx DL_unk_DL_05014630_0x50145c0[];
extern Gfx DL_unk_DL_05014630_0x5014450[];
#endif