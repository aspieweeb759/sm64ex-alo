#include "custom.model.inc.h"
const GeoLayout unk_DL_05014630[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_unk_DL_05014630_0x50145c0),
GEO_CLOSE_NODE(),
GEO_END(),
};
