ALIGNED8 u8 unk_DL_05008d14__texture_050017A0[] = {
#include "actors/unk_sa_05008d14/unk_DL_05008d14_0x50017a0_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_05008d14__texture_05001FA0[] = {
#include "actors/unk_sa_05008d14/unk_DL_05008d14_0x5001fa0_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_05008d14__texture_050037A0[] = {
#include "actors/unk_sa_05008d14/unk_DL_05008d14_0x50037a0_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_05008d14__texture_05002FA0[] = {
#include "actors/unk_sa_05008d14/unk_DL_05008d14_0x5002fa0_custom.rgba16.inc.c"
};
