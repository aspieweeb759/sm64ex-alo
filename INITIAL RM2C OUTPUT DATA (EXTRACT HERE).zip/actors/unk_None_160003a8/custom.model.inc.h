#ifndef unk_None_160003a8_unk_None_160003a8_model_HEADER_H
#define unk_None_160003a8_unk_None_160003a8_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_160003a8_0x3013910[];
extern Vtx VB_unk_DL_160003a8_0x3013a10[];
extern Vtx VB_unk_DL_160003a8_0x3013a90[];
extern Vtx VB_unk_DL_160003a8_0x3013b50[];
extern Vtx VB_unk_DL_160003a8_0x3013f20[];
extern Vtx VB_unk_DL_160003a8_0x3013fa0[];
extern u8 unk_DL_160003a8__texture_0300AD10[];
extern u8 unk_DL_160003a8__texture_03009D10[];
extern Light_t Light_unk_DL_160003a8_0x3009ce8;
extern Light_t Light_unk_DL_160003a8_0x3009d00;
extern Ambient_t Light_unk_DL_160003a8_0x3009ce0;
extern Ambient_t Light_unk_DL_160003a8_0x3009cf8;
extern Gfx DL_unk_DL_160003a8_0x3013e28[];
extern Gfx DL_unk_DL_160003a8_0x3013c10[];
extern Gfx DL_unk_DL_160003a8_0x3013cc8[];
extern Gfx DL_unk_DL_160003a8_0x3013d78[];
extern Gfx DL_unk_DL_160003a8_0x3014100[];
extern Gfx DL_unk_DL_160003a8_0x3014020[];
#endif