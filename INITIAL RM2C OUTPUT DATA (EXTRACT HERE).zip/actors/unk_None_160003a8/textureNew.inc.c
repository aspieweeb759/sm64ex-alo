ALIGNED8 u8 unk_DL_160003a8__texture_0300AD10[] = {
#include "actors/unk_None_160003a8/unk_DL_160003a8_0x300ad10_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_160003a8__texture_03009D10[] = {
#include "actors/unk_None_160003a8/unk_DL_160003a8_0x3009d10_custom.rgba16.inc.c"
};
