ALIGNED8 u8 unk_DL_05003120__texture_05002C48[] = {
#include "actors/unk_wf_05003120/unk_DL_05003120_0x5002c48_custom.rgba16.inc.c"
};
