#ifndef unk_wf_05003120_unk_wf_05003120_model_HEADER_H
#define unk_wf_05003120_unk_wf_05003120_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_05003120_0x5002e60[];
extern Vtx VB_unk_DL_05003120_0x5002f60[];
extern u8 unk_DL_05003120__texture_05002C48[];
extern Light_t Light_unk_DL_05003120_0x5001bd8;
extern Ambient_t Light_unk_DL_05003120_0x5001bd0;
extern Gfx DL_unk_DL_05003120_0x5003120[];
extern Gfx DL_unk_DL_05003120_0x5003020[];
#endif