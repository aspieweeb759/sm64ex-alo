ALIGNED8 u8 unk_DL_06003754__texture_06000060[] = {
#include "actors/unk_sl_06003754/unk_DL_06003754_0x6000060_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_06003754__texture_06001060[] = {
#include "actors/unk_sl_06003754/unk_DL_06003754_0x6001060_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_06003754__texture_06002060[] = {
#include "actors/unk_sl_06003754/unk_DL_06003754_0x6002060_custom.rgba16.inc.c"
};
