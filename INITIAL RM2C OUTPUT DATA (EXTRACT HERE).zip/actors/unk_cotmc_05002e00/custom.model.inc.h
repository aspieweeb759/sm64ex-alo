#ifndef unk_cotmc_05002e00_unk_cotmc_05002e00_model_HEADER_H
#define unk_cotmc_05002e00_unk_cotmc_05002e00_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_05002e00_0x5002cc8[];
extern u8 unk_DL_05002e00__texture_05001C48[];
extern Light_t Light_unk_DL_05002e00_0x5001bc0;
extern Ambient_t Light_unk_DL_05002e00_0x5001bb8;
extern Gfx DL_unk_DL_05002e00_0x5002e00[];
extern Gfx DL_unk_DL_05002e00_0x5002d88[];
#endif