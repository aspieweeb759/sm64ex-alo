ALIGNED8 u8 unk_DL_0c000410__texture_05004028[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5004028_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05002C28[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5002c28_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05002A28[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5002a28_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05003E28[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5003e28_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05000A28[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5000a28_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05002E28[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5002e28_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05001228[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5001228_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05001A28[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5001a28_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05002228[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5002228_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0c000410__texture_05003628[] = {
#include "actors/unk_castle_grounds_0c000410/unk_DL_0c000410_0x5003628_custom.rgba16.inc.c"
};
