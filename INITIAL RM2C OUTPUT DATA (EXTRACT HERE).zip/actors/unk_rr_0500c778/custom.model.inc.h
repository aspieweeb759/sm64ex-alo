#ifndef unk_rr_0500c778_unk_rr_0500c778_model_HEADER_H
#define unk_rr_0500c778_unk_rr_0500c778_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_0500c778_0x500b278[];
extern Vtx VB_unk_DL_0500c778_0x500b378[];
extern Vtx VB_unk_DL_0500c778_0x500b478[];
extern Vtx VB_unk_DL_0500c778_0x500b578[];
extern Vtx VB_unk_DL_0500c778_0x500b5b8[];
extern Vtx VB_unk_DL_0500c778_0x500b6a8[];
extern Vtx VB_unk_DL_0500c778_0x500b798[];
extern Vtx VB_unk_DL_0500c778_0x500b898[];
extern Vtx VB_unk_DL_0500c778_0x500b998[];
extern Vtx VB_unk_DL_0500c778_0x500ba98[];
extern Vtx VB_unk_DL_0500c778_0x500bad8[];
extern Vtx VB_unk_DL_0500c778_0x500bbc8[];
extern Vtx VB_unk_DL_0500c778_0x500c188[];
extern Vtx VB_unk_DL_0500c778_0x500c1c8[];
extern u8 unk_DL_0500c778__texture_05005A30[];
extern u8 unk_DL_0500c778__texture_05006A30[];
extern Gfx DL_unk_DL_0500c778_0x500c278[];
extern Gfx DL_unk_DL_0500c778_0x500c208[];
extern Gfx DL_unk_DL_0500c778_0x500c240[];
extern Light_t Light_unk_DL_0500c778_0x500b250;
extern Ambient_t Light_unk_DL_0500c778_0x500b248;
extern Gfx DL_unk_DL_0500c778_0x500be98[];
extern Gfx DL_unk_DL_0500c778_0x500be10[];
extern Light_t Light_unk_DL_0500c778_0x500b238;
extern Ambient_t Light_unk_DL_0500c778_0x500b230;
extern Gfx DL_unk_DL_0500c778_0x500bcb8[];
extern Gfx DL_unk_DL_0500c778_0x500c100[];
extern Gfx DL_unk_DL_0500c778_0x500c078[];
extern Gfx DL_unk_DL_0500c778_0x500bf20[];
#endif