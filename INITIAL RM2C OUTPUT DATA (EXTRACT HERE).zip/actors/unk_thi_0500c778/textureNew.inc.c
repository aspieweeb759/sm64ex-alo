ALIGNED8 u8 unk_DL_0500c778__texture_05005A30[] = {
#include "actors/unk_thi_0500c778/unk_DL_0500c778_0x5005a30_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0500c778__texture_05006A30[] = {
#include "actors/unk_thi_0500c778/unk_DL_0500c778_0x5006a30_custom.rgba16.inc.c"
};
