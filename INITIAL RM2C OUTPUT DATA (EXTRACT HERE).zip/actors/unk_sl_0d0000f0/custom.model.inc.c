#include "custom.model.inc.h"
Vtx VB_unk_DL_0d0000f0_0x60051e0[] = {
{{{ 226, 1, 300 }, 0, { 1988, 0 }, { 205, 248, 115, 255}}},
{{{ 0, 0, 200 }, 0, { 2656, 358 }, { 172, 251, 94, 255}}},
{{{ 278, -190, 140 }, 0, { 988, 390 }, { 210, 150, 51, 255}}},
{{{ 261, 194, -174 }, 0, { 824, 392 }, { 204, 100, 200, 255}}},
{{{ 226, 1, -299 }, 0, { -8, 0 }, { 205, 248, 141, 255}}},
{{{ 0, 0, -199 }, 0, { -672, 312 }, { 172, 251, 162, 255}}},
{{{ 261, 194, 175 }, 0, { 1156, 392 }, { 204, 100, 56, 255}}},
{{{ 0, 0, 200 }, 0, { 2656, 312 }, { 172, 251, 94, 255}}},
{{{ 0, 0, -199 }, 0, { -672, 358 }, { 172, 251, 162, 255}}},
{{{ 278, -190, -139 }, 0, { 992, 390 }, { 210, 150, 205, 255}}},
};

Vtx VB_unk_DL_0d0000f0_0x6005280[] = {
{{{ 0, 0, 200 }, 0, { 0, 0 }, { 172, 251, 94, 255}}},
{{{ -88, -68, 0 }, 0, { 0, 0 }, { 159, 175, 0, 255}}},
{{{ 278, -190, 140 }, 0, { 0, 0 }, { 210, 150, 51, 255}}},
{{{ -88, 71, 0 }, 0, { 0, 0 }, { 155, 76, 0, 255}}},
{{{ 261, 194, 175 }, 0, { 0, 0 }, { 204, 100, 56, 255}}},
{{{ 0, 0, -199 }, 0, { 0, 0 }, { 172, 251, 162, 255}}},
{{{ 278, -190, -139 }, 0, { 0, 0 }, { 210, 150, 205, 255}}},
{{{ 261, 194, -174 }, 0, { 0, 0 }, { 204, 100, 200, 255}}},
};

Vtx VB_unk_DL_0d0000f0_0x6005440[] = {
{{{ 418, 89, -157 }, 0, { 388, 0 }, { 70, 98, 219, 255}}},
{{{ 261, 194, 175 }, 0, { 1604, 408 }, { 70, 98, 37, 255}}},
{{{ 418, 89, 157 }, 0, { 1540, 0 }, { 67, 91, 57, 255}}},
{{{ 418, 89, 157 }, 0, { 684, 0 }, { 67, 91, 57, 255}}},
{{{ 261, 194, 175 }, 0, { 1156, 392 }, { 70, 98, 37, 255}}},
{{{ 226, 1, 300 }, 0, { 1988, 0 }, { 52, 249, 115, 255}}},
{{{ 418, 89, -157 }, 0, { 1296, 0 }, { 70, 98, 219, 255}}},
{{{ 226, 1, -299 }, 0, { -8, 0 }, { 51, 249, 141, 255}}},
{{{ 261, 194, -174 }, 0, { 824, 392 }, { 67, 91, 199, 255}}},
{{{ 418, -85, -157 }, 0, { 1296, 0 }, { 40, 186, 159, 255}}},
{{{ 278, -190, -139 }, 0, { 992, 390 }, { 70, 157, 221, 255}}},
{{{ 278, -190, 140 }, 0, { 988, 390 }, { 64, 161, 53, 255}}},
{{{ 418, -85, 157 }, 0, { 684, 0 }, { 40, 186, 97, 255}}},
{{{ 261, 194, -174 }, 0, { 324, 408 }, { 67, 91, 199, 255}}},
};

Vtx VB_unk_DL_0d0000f0_0x6005520[] = {
{{{ 278, -190, -139 }, 0, { 1512, 416 }, { 70, 157, 221, 255}}},
{{{ 418, -85, -156 }, 0, { 1588, 0 }, { 76, 155, 0, 255}}},
{{{ 418, -85, 158 }, 0, { 248, 0 }, { 76, 155, 0, 255}}},
{{{ 278, -190, 140 }, 0, { 320, 416 }, { 64, 161, 53, 255}}},
{{{ 238, -15, 286 }, 0, { 2336, 754 }, { 62, 206, 98, 255}}},
{{{ 272, 77, 312 }, 0, { 124, 1062 }, { 62, 206, 98, 255}}},
{{{ 229, 73, 337 }, 0, { 124, 436 }, { 62, 206, 98, 255}}},
};

Vtx VB_unk_DL_0d0000f0_0x60056a8[] = {
{{{ 356, 121, -159 }, 0, { 960, 4 }, { 255, 255, 255, 255}}},
{{{ 356, -128, 150 }, 0, { 28, 918 }, { 255, 255, 255, 255}}},
{{{ 356, -128, -149 }, 0, { 930, 918 }, { 255, 255, 255, 255}}},
{{{ 356, 121, 160 }, 0, { -2, 4 }, { 255, 255, 255, 255}}},
{{{ 226, 1, 298 }, 0, { -414, 442 }, { 255, 255, 255, 255}}},
{{{ 226, 1, -297 }, 0, { 1374, 442 }, { 255, 255, 255, 255}}},
};

Vtx VB_unk_DL_0d0000f0_0x6005820[] = {
{{{ 0, 0, 0 }, 0, { 0, 0 }, { 131, 17, 0, 0}}},
{{{ 180, 90, 0 }, 0, { 0, 0 }, { 200, 113, 0, 0}}},
{{{ 180, 40, -80 }, 0, { 0, 0 }, { 200, 42, 151, 0}}},
{{{ 180, -120, -40 }, 0, { 0, 0 }, { 187, 176, 187, 255}}},
{{{ 180, -120, 40 }, 0, { 0, 0 }, { 187, 176, 69, 255}}},
{{{ 180, 90, 0 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 40, 80 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, -120, 40 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, -120, -40 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 40, -80 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 40, 80 }, 0, { 0, 0 }, { 200, 42, 105, 255}}},
};

Vtx VB_unk_DL_0d0000f0_0x60058d0[] = {
{{{ 180, 40, 80 }, 0, { 0, 0 }, { 200, 42, 105, 0}}},
{{{ 180, 90, 0 }, 0, { 0, 0 }, { 200, 113, 0, 0}}},
{{{ 0, 0, 0 }, 0, { 0, 0 }, { 131, 17, 0, 0}}},
{{{ 180, -120, -40 }, 0, { 0, 0 }, { 187, 176, 187, 255}}},
{{{ 180, -120, 40 }, 0, { 0, 0 }, { 187, 176, 69, 255}}},
{{{ 180, -120, -40 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 40, -80 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 90, 0 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, -120, 40 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 40, 80 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
{{{ 180, 40, -80 }, 0, { 0, 0 }, { 200, 42, 151, 255}}},
};

Gfx DL_unk_DL_0d0000f0_0x6005750[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT, 0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_unk_DL_0d0000f0_0x6005708),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x6005708[] = {
gsDPSetTextureImage(0, 2, 1, unk_DL_0d0000f0__texture_060049B0),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_unk_DL_0d0000f0_0x60056a8, 6, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(1, 3, 4, 0,5, 0, 2, 0),
gsSPEndDisplayList(),
};

Light_t Light_unk_DL_0d0000f0_0x60057f8 = {
{ 255, 255, 0}, 0, { 255, 255, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_unk_DL_0d0000f0_0x60057f0 = {
{63, 63, 0}, 0, {63, 63, 0}, 0
};

Gfx DL_unk_DL_0d0000f0_0x6005980[] = {
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
gsSPLight(&Light_unk_DL_0d0000f0_0x60057f8.col, 1),
gsSPLight(&Light_unk_DL_0d0000f0_0x60057f0.col, 2),
gsSPVertex(VB_unk_DL_0d0000f0_0x6005820, 11, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 4, 0),
gsSP2Triangles(5, 6, 7, 0,5, 7, 8, 0),
gsSP2Triangles(5, 8, 9, 0,10, 1, 0, 0),
gsSP2Triangles(0, 4, 10, 0,2, 3, 0, 0),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x60059f0[] = {
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
gsSPLight(&Light_unk_DL_0d0000f0_0x60057f8.col, 1),
gsSPLight(&Light_unk_DL_0d0000f0_0x60057f0.col, 2),
gsSPVertex(VB_unk_DL_0d0000f0_0x60058d0, 11, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 2, 0),
gsSP2Triangles(5, 6, 7, 0,8, 5, 7, 0),
gsSP2Triangles(9, 8, 7, 0,2, 1, 10, 0),
gsSP2Triangles(10, 3, 2, 0,2, 4, 0, 0),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Light_t Light_unk_DL_0d0000f0_0x60051b8 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Light_t Light_unk_DL_0d0000f0_0x60051d0 = {
{ 0, 127, 71}, 0, { 0, 127, 71}, 0, { 40, 40, 40}, 0
};

Light_t Light_unk_DL_0d0000f0_0x6005430 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_unk_DL_0d0000f0_0x60051b0 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Ambient_t Light_unk_DL_0d0000f0_0x60051c8 = {
{0, 63, 35}, 0, {0, 63, 35}, 0
};

Ambient_t Light_unk_DL_0d0000f0_0x6005428 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_unk_DL_0d0000f0_0x6005688[] = {
gsSPDisplayList(DL_unk_DL_0d0000f0_0x60053b8),
gsSPDisplayList(DL_unk_DL_0d0000f0_0x6005618),
gsDPSetEnvColor(255, 255, 255, 255),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x60053b8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_unk_DL_0d0000f0_0x6005300),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
gsSPDisplayList(DL_unk_DL_0d0000f0_0x6005358),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x6005300[] = {
gsDPSetTextureImage(0, 2, 1, unk_DL_0d0000f0__texture_060039B0),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_unk_DL_0d0000f0_0x60051b8.col, 1),
gsSPLight(&Light_unk_DL_0d0000f0_0x60051b0.col, 2),
gsSPVertex(VB_unk_DL_0d0000f0_0x60051e0, 10, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 0, 0,8, 4, 9, 0),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x6005358[] = {
gsSPLight(&Light_unk_DL_0d0000f0_0x60051d0.col, 1),
gsSPLight(&Light_unk_DL_0d0000f0_0x60051c8.col, 2),
gsSPVertex(VB_unk_DL_0d0000f0_0x6005280, 8, 0),
gsSP2Triangles(0, 1, 2, 0,1, 0, 3, 0),
gsSP2Triangles(3, 0, 4, 0,3, 5, 1, 0),
gsSP2Triangles(6, 2, 1, 0,1, 5, 6, 0),
gsSP2Triangles(5, 3, 7, 0,4, 7, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x6005618[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
gsSPGeometryMode(G_CULL_BACK, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 2, 5, 0, 2, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPDisplayList(DL_unk_DL_0d0000f0_0x6005590),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK),
gsSPEndDisplayList(),
};

Gfx DL_unk_DL_0d0000f0_0x6005590[] = {
gsDPSetTextureImage(0, 2, 1, unk_DL_0d0000f0__texture_060039B0),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsSPLight(&Light_unk_DL_0d0000f0_0x6005430.col, 1),
gsSPLight(&Light_unk_DL_0d0000f0_0x6005428.col, 2),
gsSPVertex(VB_unk_DL_0d0000f0_0x6005440, 14, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,9, 10, 7, 0),
gsSP2Triangles(5, 11, 12, 0,0, 13, 1, 0),
gsSPVertex(VB_unk_DL_0d0000f0_0x6005520, 7, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP1Triangle(4, 5, 6, 0),
gsSPEndDisplayList(),
};

