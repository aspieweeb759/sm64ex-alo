ALIGNED8 u8 unk_DL_0d0000f0__texture_060049B0[] = {
#include "actors/unk_sl_0d0000f0/unk_DL_0d0000f0_0x60049b0_custom.rgba16.inc.c"
};
ALIGNED8 u8 unk_DL_0d0000f0__texture_060039B0[] = {
#include "actors/unk_sl_0d0000f0/unk_DL_0d0000f0_0x60039b0_custom.rgba16.inc.c"
};
