#ifndef unk_sl_0d0000f0_unk_sl_0d0000f0_model_HEADER_H
#define unk_sl_0d0000f0_unk_sl_0d0000f0_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_0d0000f0_0x60051e0[];
extern Vtx VB_unk_DL_0d0000f0_0x6005280[];
extern Vtx VB_unk_DL_0d0000f0_0x6005440[];
extern Vtx VB_unk_DL_0d0000f0_0x6005520[];
extern Vtx VB_unk_DL_0d0000f0_0x60056a8[];
extern Vtx VB_unk_DL_0d0000f0_0x6005820[];
extern Vtx VB_unk_DL_0d0000f0_0x60058d0[];
extern u8 unk_DL_0d0000f0__texture_060049B0[];
extern Gfx DL_unk_DL_0d0000f0_0x6005750[];
extern Gfx DL_unk_DL_0d0000f0_0x6005708[];
extern Light_t Light_unk_DL_0d0000f0_0x60057f8;
extern Ambient_t Light_unk_DL_0d0000f0_0x60057f0;
extern Gfx DL_unk_DL_0d0000f0_0x6005980[];
extern Gfx DL_unk_DL_0d0000f0_0x60059f0[];
extern u8 unk_DL_0d0000f0__texture_060039B0[];
extern Light_t Light_unk_DL_0d0000f0_0x60051b8;
extern Light_t Light_unk_DL_0d0000f0_0x60051d0;
extern Light_t Light_unk_DL_0d0000f0_0x6005430;
extern Ambient_t Light_unk_DL_0d0000f0_0x60051b0;
extern Ambient_t Light_unk_DL_0d0000f0_0x60051c8;
extern Ambient_t Light_unk_DL_0d0000f0_0x6005428;
extern Gfx DL_unk_DL_0d0000f0_0x6005688[];
extern Gfx DL_unk_DL_0d0000f0_0x60053b8[];
extern Gfx DL_unk_DL_0d0000f0_0x6005300[];
extern Gfx DL_unk_DL_0d0000f0_0x6005358[];
extern Gfx DL_unk_DL_0d0000f0_0x6005618[];
extern Gfx DL_unk_DL_0d0000f0_0x6005590[];
#endif