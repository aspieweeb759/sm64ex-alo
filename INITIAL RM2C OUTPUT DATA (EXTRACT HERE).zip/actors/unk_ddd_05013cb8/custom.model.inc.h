#ifndef unk_ddd_05013cb8_unk_ddd_05013cb8_model_HEADER_H
#define unk_ddd_05013cb8_unk_ddd_05013cb8_model_HEADER_H
#include "types.h"
extern Vtx VB_unk_DL_05013cb8_0x5013848[];
extern Vtx VB_unk_DL_05013cb8_0x5013928[];
extern Vtx VB_unk_DL_05013cb8_0x5013a28[];
extern Vtx VB_unk_DL_05013cb8_0x5013b08[];
extern u8 unk_DL_05013cb8__texture_05012848[];
extern Gfx DL_unk_DL_05013cb8_0x5013cb8[];
extern Gfx DL_unk_DL_05013cb8_0x5013b58[];
#endif