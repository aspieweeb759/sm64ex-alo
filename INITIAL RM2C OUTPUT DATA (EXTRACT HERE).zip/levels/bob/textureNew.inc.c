ALIGNED8 u8 bob_1__texture_09005000[] = {
#include "levels/bob/bob_1_0x9005000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002810[] = {
#include "levels/bob/bob_1_0xe002810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E000010[] = {
#include "levels/bob/bob_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002010[] = {
#include "levels/bob/bob_1_0xe002010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001810[] = {
#include "levels/bob/bob_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001010[] = {
#include "levels/bob/bob_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E000810[] = {
#include "levels/bob/bob_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_geo_000440__texture_09008800[] = {
#include "levels/bob/bob_geo_000440_0x9008800_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_geo_000458__texture_09006000[] = {
#include "levels/bob/bob_geo_000458_0x9006000_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_geo_000470__texture_09008800[] = {
#include "levels/bob/bob_geo_000470_0x9008800_custom.rgba16.inc.c"
};
