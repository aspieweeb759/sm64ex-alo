ALIGNED8 u8 ccm_1__texture_0E000010[] = {
#include "levels/ccm/ccm_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 ccm_1__texture_0E000810[] = {
#include "levels/ccm/ccm_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 ccm_1__texture_09009800[] = {
#include "levels/ccm/ccm_1_0x9009800_custom.rgba16.inc.c"
};
