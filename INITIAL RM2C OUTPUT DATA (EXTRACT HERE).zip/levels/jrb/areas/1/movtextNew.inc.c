static Movtex jrb_1_Movtex_0_0[] = {1, 0, 15, 3, -8192, -8192, 8192, -8192, 8192, 8192, -8192, 8192, 1, 120, 0, 0};

const struct MovtexQuadCollection jrb_1_Movtex_0[] = {
{0,jrb_1_Movtex_0_0},
{-1, NULL},
};
