ALIGNED8 u8 jrb_1__texture_0E001810[] = {
#include "levels/jrb/jrb_1_0xe001810_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E001010[] = {
#include "levels/jrb/jrb_1_0xe001010_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E000810[] = {
#include "levels/jrb/jrb_1_0xe000810_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E000010[] = {
#include "levels/jrb/jrb_1_0xe000010_custom.rgba16.inc.c"
};
