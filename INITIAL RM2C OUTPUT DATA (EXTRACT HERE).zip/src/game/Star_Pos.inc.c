#define KoopaBoBStarPos { 3030, 4500, -4600 }
#define KoopaTHIStarPos { 7100, -1300, -6000 }
#define KingBobOmbStarPos -700.0f, -313.0f, 3815.0f
#define KingWhompStarPos 1187.0f, 1468.0f, 1521.0f
#define EyerockStarPos 0.0f, -900.0f, -3700.0f
#define BigBullyStarPos -2581.0f, 275.0f, -1311.0f
#define ChillBullyStarPos 130.0f, 1600.0f, -4335.0f
#define BigPiranhasStarPos -6300.0f, -1850.0f, -6300.0f
#define TuxieMotherStarPos 3167.0f, -4300.0f, 5108.0f
#define WigglerStarPos 0.0f, 2048.0f, 0.0f
#define PssSlideStarPos -6358.0f, -4300.0f, 4700.0f
#define RacingPenguinStarPos -7339.0f, -5700.0f, -6774.0f
#define TreasureChestStarPos -1800.0f, -2500.0f, -1700.0f
#define GhostHuntBooStarPos 980.0f, 1100.0f, 250.0f
#define KleptoStarPos -5550.0f, 300.0f, -930.0f
#define MerryGoRoundStarPos -1600.0f, -2100.0f, 205.0f
#define MrIStarPos 1370, 2000.0f, -320.0f
#define BalconyBooStarPos 700.0f, 3200.0f, 1900.0f
#define BigBullyTrioStarPos 3700.0f, 600.0f, -5500.0f
