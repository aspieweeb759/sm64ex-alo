#include <PR/ultratypes.h>
#include "behavior_actions.h"
#include "macros.h"
#include "types.h"
#include "behavior_data.h"
struct Struct802C0DF0 sExclamationBoxContents[] = { { 0, 0, 0, 135,  bhvWingCap },
{ 1, 0, 0, 134,  bhvMetalCap },
{ 2, 0, 0, 136,  bhvVanishCap },
{ 3, 0, 0, 190,  bhvKoopaShell },
{ 4, 0, 0, 116,  bhvSingleCoinGetsSpawned },
{ 5, 0, 0, 0,  bhvThreeCoinsSpawn },
{ 6, 0, 0, 0,  bhvTenCoinsSpawn },
{ 7, 0, 0, 212,  bhv1upWalking },
{ 8, 0, 0, 122,  bhvSpawnedStar },
{ 9, 0, 0, 212,  bhv1upRunningAway },
{ 10, 0, 1, 122,  bhvSpawnedStar },
{ 11, 0, 2, 122,  bhvSpawnedStar },
{ 12, 0, 3, 122,  bhvSpawnedStar },
{ 13, 0, 4, 122,  bhvSpawnedStar },
{ 14, 0, 5, 122,  bhvSpawnedStar },
{ 99, 0, 0, 0, NULL } };
