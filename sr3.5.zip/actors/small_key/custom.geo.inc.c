#include "custom.model.inc.h"
const GeoLayout small_key_geo[]= {
GEO_SHADOW(1,150,80),
GEO_OPEN_NODE(),
GEO_SCALE(0,16384),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_small_key_geo_0x5006a68),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
