ALIGNED8 u8 bowser_bomb_geo__texture_06059C10[] = {
#include "actors/bowser_bomb/bowser_bomb_geo_0x6059c10_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_bomb_geo__texture_06057C10[] = {
#include "actors/bowser_bomb/bowser_bomb_geo_0x6057c10_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_bomb_geo__texture_06058C10[] = {
#include "actors/bowser_bomb/bowser_bomb_geo_0x6058c10_custom.rgba16.inc.c"
};
