#ifndef pebble_pebble_model_HEADER_H
#define pebble_pebble_model_HEADER_H
#include "types.h"
extern Vtx VB_pebble_seg3_dl_0301CB00_0x301c2c0[];
extern u8 pebble_seg3_dl_0301CB00__texture_0301C300[];
extern Gfx DL_pebble_seg3_dl_0301CB00_0x301cb00[];
#endif