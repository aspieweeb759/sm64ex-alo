ALIGNED8 u8 bub_geo__texture_0600E2A8[] = {
#include "actors/bub/bub_geo_0x600e2a8_custom.rgba16.inc.c"
};
ALIGNED8 u8 bub_geo__texture_0600EAA8[] = {
#include "actors/bub/bub_geo_0x600eaa8_custom.rgba16.inc.c"
};
ALIGNED8 u8 bub_geo__texture_0600F2A8[] = {
#include "actors/bub/bub_geo_0x600f2a8_custom.rgba16.inc.c"
};
ALIGNED8 u8 bub_geo__texture_060102A8[] = {
#include "actors/bub/bub_geo_0x60102a8_custom.rgba16.inc.c"
};
