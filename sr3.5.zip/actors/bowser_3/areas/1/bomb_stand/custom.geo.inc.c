#include "custom.model.inc.h"
const GeoLayout bowser_3_geo_000380[]= {
GEO_CULLING_RADIUS(700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bowser_3_geo_000380_0x7004958),
GEO_CLOSE_NODE(),
GEO_END(),
};
