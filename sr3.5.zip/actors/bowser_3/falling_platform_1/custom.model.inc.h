#ifndef bowser_3_falling_platform_1_model_HEADER_H
#define bowser_3_falling_platform_1_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000290_0x7002030[];
extern Vtx VB_bowser_3_geo_000290_0x7002090[];
extern Vtx VB_bowser_3_geo_000290_0x70020d0[];
extern u8 bowser_3_geo_000290__texture_07000800[];
extern u8 bowser_3_geo_000290__texture_07001000[];
extern Light_t Light_bowser_3_geo_000290_0x7002008;
extern Light_t Light_bowser_3_geo_000290_0x7002020;
extern Ambient_t Light_bowser_3_geo_000290_0x7002000;
extern Ambient_t Light_bowser_3_geo_000290_0x7002018;
extern Gfx DL_bowser_3_geo_000290_0x70022a8[];
extern Gfx DL_bowser_3_geo_000290_0x70021d0[];
extern Gfx DL_bowser_3_geo_000290_0x7002240[];
#endif