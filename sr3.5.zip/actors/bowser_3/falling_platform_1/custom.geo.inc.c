#include "custom.model.inc.h"
const GeoLayout bowser_3_geo_000290[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bowser_3_geo_000290_0x70022a8),
GEO_CLOSE_NODE(),
GEO_END(),
};
