#ifndef bowser_3_falling_platform_9_model_HEADER_H
#define bowser_3_falling_platform_9_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_3_geo_000350_0x70039f0[];
extern Vtx VB_bowser_3_geo_000350_0x7003a50[];
extern Vtx VB_bowser_3_geo_000350_0x7003a90[];
extern u8 bowser_3_geo_000350__texture_07000800[];
extern u8 bowser_3_geo_000350__texture_07001000[];
extern Light_t Light_bowser_3_geo_000350_0x70039c8;
extern Light_t Light_bowser_3_geo_000350_0x70039e0;
extern Ambient_t Light_bowser_3_geo_000350_0x70039c0;
extern Ambient_t Light_bowser_3_geo_000350_0x70039d8;
extern Gfx DL_bowser_3_geo_000350_0x7003c68[];
extern Gfx DL_bowser_3_geo_000350_0x7003b90[];
extern Gfx DL_bowser_3_geo_000350_0x7003c00[];
#endif