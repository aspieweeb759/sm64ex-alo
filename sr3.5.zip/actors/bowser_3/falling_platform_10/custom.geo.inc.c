#include "custom.model.inc.h"
const GeoLayout bowser_3_geo_000368[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bowser_3_geo_000368_0x7003fa0),
GEO_CLOSE_NODE(),
GEO_END(),
};
