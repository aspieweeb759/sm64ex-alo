#include "custom.model.inc.h"
const GeoLayout bowser_3_geo_000320[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bowser_3_geo_000320_0x70035f8),
GEO_CLOSE_NODE(),
GEO_END(),
};
