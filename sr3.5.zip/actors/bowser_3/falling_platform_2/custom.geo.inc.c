#include "custom.model.inc.h"
const GeoLayout bowser_3_geo_0002A8[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bowser_3_geo_0002A8_0x70025e0),
GEO_CLOSE_NODE(),
GEO_END(),
};
