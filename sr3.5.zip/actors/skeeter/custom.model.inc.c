#include "custom.model.inc.h"
Vtx VB_skeeter_geo_0x6000990[] = {
{{{ -44, 45, 0 }, 0, { 0, 0 }, { 0, 255, 212, 255}}},
{{{ -44, -44, 0 }, 0, { 0, 990 }, { 0, 255, 212, 255}}},
{{{ 45, -44, 0 }, 0, { 990, 990 }, { 0, 255, 212, 255}}},
{{{ 45, 45, 0 }, 0, { 990, 0 }, { 0, 255, 212, 255}}},
};

Vtx VB_skeeter_geo_0x6000a78[] = {
{{{ -14, 15, 0 }, 0, { 0, 0 }, { 255, 85, 0, 255}}},
{{{ -14, -14, 0 }, 0, { 0, 990 }, { 255, 85, 0, 255}}},
{{{ 15, -14, 0 }, 0, { 990, 990 }, { 255, 85, 0, 255}}},
{{{ 15, 15, 0 }, 0, { 990, 0 }, { 255, 85, 0, 255}}},
};

Vtx VB_skeeter_geo_0x6000b60[] = {
{{{ -17, 18, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
{{{ -17, -17, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
{{{ 18, -17, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
{{{ 18, 18, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_skeeter_geo_0x6000c48[] = {
{{{ 66, 8, 69 }, 0, { 536, 0 }, { 255, 255, 255, 255}}},
{{{ 85, -24, -35 }, 0, { -99, 0 }, { 255, 255, 255, 255}}},
{{{ 63, 75, -10 }, 0, { 218, 421 }, { 255, 255, 255, 255}}},
};

Vtx VB_skeeter_geo_0x6000d18[] = {
{{{ 63, 75, 11 }, 0, { 218, 421 }, { 255, 255, 255, 255}}},
{{{ 85, -24, 36 }, 0, { 536, 0 }, { 255, 255, 255, 255}}},
{{{ 66, 8, -68 }, 0, { -99, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_skeeter_geo_0x6000e00[] = {
{{{ 45, -24, -122 }, 0, { 0, 0 }, { 106, 233, 192, 255}}},
{{{ 45, 120, 76 }, 0, { 0, 0 }, { 36, 96, 74, 255}}},
{{{ 45, -24, 123 }, 0, { 0, 0 }, { 40, 214, 112, 255}}},
{{{ 45, 120, -75 }, 0, { 0, 0 }, { 165, 69, 203, 255}}},
{{{ -14, 0, 0 }, 0, { 0, 0 }, { 130, 253, 0, 255}}},
{{{ 45, -114, 0 }, 0, { 0, 0 }, { 178, 157, 0, 255}}},
};

Vtx VB_skeeter_geo_0x6000fa0[] = {
{{{ 555, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 555, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x6000fe0[] = {
{{{ 405, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 405, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x60010d0[] = {
{{{ 555, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 555, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x6001110[] = {
{{{ 405, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 405, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x6001200[] = {
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 555, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 555, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x6001240[] = {
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 405, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 405, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x6001b30[] = {
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 555, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 555, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x6001b70[] = {
{{{ 0, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 405, 0, 15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 405, 0, -15 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Vtx VB_skeeter_geo_0x60037b0[] = {
{{{ 162, 7, -7 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, 7, -7 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 0, -7, 7 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
{{{ 162, -7, 7 }, 0, { 0, 0 }, { 21, 21, 8, 0}}},
};

Gfx DL_skeeter_geo_0x6000a08[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_skeeter_geo_0x60009d0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x60009d0[] = {
gsDPSetTextureImage(0, 2, 1, skeeter_geo__texture_06000090),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_skeeter_geo_0x6000990, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6004070[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6000fe0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6004040[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6000fa0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Light_t Light_skeeter_geo_0x6000df0 = {
{ 255, 170, 0}, 0, { 255, 170, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_skeeter_geo_0x6000de8 = {
{127, 85, 0}, 0, {127, 85, 0}, 0
};

Gfx DL_skeeter_geo_0x6000ec0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPDisplayList(DL_skeeter_geo_0x6000e60),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000e60[] = {
gsSPLight(&Light_skeeter_geo_0x6000df0.col, 1),
gsSPLight(&Light_skeeter_geo_0x6000de8.col, 2),
gsSPVertex(VB_skeeter_geo_0x6000e00, 6, 0),
gsSP2Triangles(0, 1, 2, 0,0, 3, 1, 0),
gsSP2Triangles(2, 1, 4, 0,1, 3, 4, 0),
gsSP2Triangles(3, 0, 4, 0,5, 2, 4, 0),
gsSP2Triangles(0, 5, 4, 0,5, 0, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6004120[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6001110, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x60040f0[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x60010d0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,3, 0, 2, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x60041d0[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6001240, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x60041a0[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6001200, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000bd8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_skeeter_geo_0x6000ba0),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000ba0[] = {
gsDPSetTextureImage(0, 2, 1, skeeter_geo__texture_06000090),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_skeeter_geo_0x6000b60, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000ca8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 3, 0, 2, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 28),
gsSPDisplayList(DL_skeeter_geo_0x6000c78),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000c78[] = {
gsDPSetTextureImage(0, 2, 1, skeeter_geo__texture_06000890),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 127, 512),
gsSPVertex(VB_skeeter_geo_0x6000c48, 3, 0),
gsSP1Triangle(0, 1, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000d78[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 3, 0, 2, 4, 0),
gsDPSetTileSize(0, 0, 0, 60, 28),
gsSPDisplayList(DL_skeeter_geo_0x6000d48),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000d48[] = {
gsDPSetTextureImage(0, 2, 1, skeeter_geo__texture_06000890),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 127, 512),
gsSPVertex(VB_skeeter_geo_0x6000d18, 3, 0),
gsSP1Triangle(0, 1, 2, 0),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6004648[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6001b70, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6004618[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x6001b30, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6005328[] = {
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH, 0),
gsSPVertex(VB_skeeter_geo_0x60037b0, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING|G_SHADING_SMOOTH),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000af0[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
gsSPGeometryMode(G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsSPDisplayList(DL_skeeter_geo_0x6000ab8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_skeeter_geo_0x6000ab8[] = {
gsDPSetTextureImage(0, 2, 1, skeeter_geo__texture_06000090),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPVertex(VB_skeeter_geo_0x6000a78, 4, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSPEndDisplayList(),
};

