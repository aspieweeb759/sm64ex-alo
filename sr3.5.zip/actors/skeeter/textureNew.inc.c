ALIGNED8 u8 skeeter_geo__texture_06000090[] = {
#include "actors/skeeter/skeeter_geo_0x6000090_custom.rgba16.inc.c"
};
ALIGNED8 u8 skeeter_geo__texture_06000890[] = {
#include "actors/skeeter/skeeter_geo_0x6000890_custom.rgba16.inc.c"
};
