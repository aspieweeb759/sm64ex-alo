#ifndef skeeter_skeeter_model_HEADER_H
#define skeeter_skeeter_model_HEADER_H
#include "types.h"
extern Vtx VB_skeeter_geo_0x6000990[];
extern Vtx VB_skeeter_geo_0x6000a78[];
extern Vtx VB_skeeter_geo_0x6000b60[];
extern Vtx VB_skeeter_geo_0x6000c48[];
extern Vtx VB_skeeter_geo_0x6000d18[];
extern Vtx VB_skeeter_geo_0x6000e00[];
extern Vtx VB_skeeter_geo_0x6000fa0[];
extern Vtx VB_skeeter_geo_0x6000fe0[];
extern Vtx VB_skeeter_geo_0x60010d0[];
extern Vtx VB_skeeter_geo_0x6001110[];
extern Vtx VB_skeeter_geo_0x6001200[];
extern Vtx VB_skeeter_geo_0x6001240[];
extern Vtx VB_skeeter_geo_0x6001b30[];
extern Vtx VB_skeeter_geo_0x6001b70[];
extern Vtx VB_skeeter_geo_0x60037b0[];
extern u8 skeeter_geo__texture_06000090[];
extern Gfx DL_skeeter_geo_0x6000a08[];
extern Gfx DL_skeeter_geo_0x60009d0[];
extern Gfx DL_skeeter_geo_0x6004070[];
extern Gfx DL_skeeter_geo_0x6004040[];
extern Light_t Light_skeeter_geo_0x6000df0;
extern Ambient_t Light_skeeter_geo_0x6000de8;
extern Gfx DL_skeeter_geo_0x6000ec0[];
extern Gfx DL_skeeter_geo_0x6000e60[];
extern Gfx DL_skeeter_geo_0x6004120[];
extern Gfx DL_skeeter_geo_0x60040f0[];
extern Gfx DL_skeeter_geo_0x60041d0[];
extern Gfx DL_skeeter_geo_0x60041a0[];
extern Gfx DL_skeeter_geo_0x6000bd8[];
extern Gfx DL_skeeter_geo_0x6000ba0[];
extern u8 skeeter_geo__texture_06000890[];
extern Gfx DL_skeeter_geo_0x6000ca8[];
extern Gfx DL_skeeter_geo_0x6000c78[];
extern Gfx DL_skeeter_geo_0x6000d78[];
extern Gfx DL_skeeter_geo_0x6000d48[];
extern Gfx DL_skeeter_geo_0x6004648[];
extern Gfx DL_skeeter_geo_0x6004618[];
extern Gfx DL_skeeter_geo_0x6005328[];
extern Gfx DL_skeeter_geo_0x6000af0[];
extern Gfx DL_skeeter_geo_0x6000ab8[];
#endif