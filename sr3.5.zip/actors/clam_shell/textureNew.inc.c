ALIGNED8 u8 clam_shell_geo__texture_05000030[] = {
#include "actors/clam_shell/clam_shell_geo_0x5000030_custom.rgba16.inc.c"
};
ALIGNED8 u8 clam_shell_geo__texture_05000830[] = {
#include "actors/clam_shell/clam_shell_geo_0x5000830_custom.rgba16.inc.c"
};
