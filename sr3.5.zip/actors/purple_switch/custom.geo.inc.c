#include "custom.model.inc.h"
const GeoLayout purple_switch_geo[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_purple_switch_geo_0x800c718),
GEO_CLOSE_NODE(),
GEO_END(),
};
