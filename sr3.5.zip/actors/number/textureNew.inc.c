ALIGNED8 u8 number_geo__texture_02000000[] = {
#include "actors/number/number_geo_0x2000000_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000200[] = {
#include "actors/number/number_geo_0x2000200_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000400[] = {
#include "actors/number/number_geo_0x2000400_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000600[] = {
#include "actors/number/number_geo_0x2000600_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000800[] = {
#include "actors/number/number_geo_0x2000800_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000A00[] = {
#include "actors/number/number_geo_0x2000a00_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000C00[] = {
#include "actors/number/number_geo_0x2000c00_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02000E00[] = {
#include "actors/number/number_geo_0x2000e00_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02001000[] = {
#include "actors/number/number_geo_0x2001000_custom.rgba16.inc.c"
};
ALIGNED8 u8 number_geo__texture_02001200[] = {
#include "actors/number/number_geo_0x2001200_custom.rgba16.inc.c"
};
