#ifndef goomba_goomba_model_HEADER_H
#define goomba_goomba_model_HEADER_H
#include "types.h"
extern Vtx VB_goomba_geo_0x801a580[];
extern Vtx VB_goomba_geo_0x801a670[];
extern Vtx VB_goomba_geo_0x801a760[];
extern Vtx VB_goomba_geo_0x801a850[];
extern Vtx VB_goomba_geo_0x801a940[];
extern Vtx VB_goomba_geo_0x801aa30[];
extern Vtx VB_goomba_geo_0x801ab20[];
extern Vtx VB_goomba_geo_0x801ac10[];
extern Vtx VB_goomba_geo_0x801ad00[];
extern Vtx VB_goomba_geo_0x801adf0[];
extern Vtx VB_goomba_geo_0x801aee0[];
extern Vtx VB_goomba_geo_0x801afd0[];
extern Vtx VB_goomba_geo_0x801b0c0[];
extern Vtx VB_goomba_geo_0x801b618[];
extern Vtx VB_goomba_geo_0x801b700[];
extern Vtx VB_goomba_geo_0x801b800[];
extern Vtx VB_goomba_geo_0x801b8f0[];
extern Vtx VB_goomba_geo_0x801b9d0[];
extern Vtx VB_goomba_geo_0x801ba50[];
extern Vtx VB_goomba_geo_0x801bb40[];
extern Vtx VB_goomba_geo_0x801bc40[];
extern Vtx VB_goomba_geo_0x801bd40[];
extern Gfx DL_goomba_geo_0x801d760[];
extern u8 goomba_geo__texture_08019530[];
extern Gfx DL_goomba_geo_0x801b690[];
extern Gfx DL_goomba_geo_0x801b658[];
extern u8 goomba_geo__texture_08019D80[];
extern Light_t Light_goomba_geo_0x8019d30;
extern Ambient_t Light_goomba_geo_0x8019d38;
extern Gfx DL_goomba_geo_0x801b1b0[];
extern Light_t Light_goomba_geo_0x80194d8;
extern Ambient_t Light_goomba_geo_0x80194d0;
extern Gfx DL_goomba_geo_0x801ce20[];
extern Light_t Light_goomba_geo_0x80194f0;
extern Ambient_t Light_goomba_geo_0x80194e8;
extern Gfx DL_goomba_geo_0x801cf78[];
#endif