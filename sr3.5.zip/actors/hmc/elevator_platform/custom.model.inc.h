#ifndef hmc_elevator_platform_model_HEADER_H
#define hmc_elevator_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_hmc_geo_0005D0_0x7022928[];
extern u8 hmc_geo_0005D0__texture_09002800[];
extern Light_t Light_hmc_geo_0005D0_0x7022918;
extern Ambient_t Light_hmc_geo_0005D0_0x7022910;
extern Gfx DL_hmc_geo_0005D0_0x7022aa0[];
extern Gfx DL_hmc_geo_0005D0_0x7022a08[];
#endif