#include "custom.model.inc.h"
const GeoLayout hmc_geo_0005B8[]= {
GEO_CULLING_RADIUS(200),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_hmc_geo_0005B8_0x7023090),
GEO_CLOSE_NODE(),
GEO_END(),
};
