#ifndef hmc_grill_door_model_HEADER_H
#define hmc_grill_door_model_HEADER_H
#include "types.h"
extern Vtx VB_hmc_geo_000530_0x701fdc8[];
extern Vtx VB_hmc_geo_000530_0x701feb8[];
extern u8 hmc_geo_000530__texture_09001000[];
extern Gfx DL_hmc_geo_000530_0x701fff8[];
extern Gfx DL_hmc_geo_000530_0x701ff68[];
#endif