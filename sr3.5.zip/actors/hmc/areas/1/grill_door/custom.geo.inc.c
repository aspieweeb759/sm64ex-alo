#include "custom.model.inc.h"
const GeoLayout hmc_geo_000530[]= {
GEO_CULLING_RADIUS(1000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_hmc_geo_000530_0x701fff8),
GEO_CLOSE_NODE(),
GEO_END(),
};
