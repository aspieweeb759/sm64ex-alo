#ifndef hmc_rolling_rock_model_HEADER_H
#define hmc_rolling_rock_model_HEADER_H
#include "types.h"
extern Vtx VB_hmc_geo_000548_0x70249c8[];
extern Vtx VB_hmc_geo_000548_0x7024ab8[];
extern Vtx VB_hmc_geo_000548_0x7024ba8[];
extern Vtx VB_hmc_geo_000548_0x7024c98[];
extern Vtx VB_hmc_geo_000548_0x7024d88[];
extern Vtx VB_hmc_geo_000548_0x7024e78[];
extern Vtx VB_hmc_geo_000548_0x7024f68[];
extern Vtx VB_hmc_geo_000548_0x7025058[];
extern Vtx VB_hmc_geo_000548_0x7025148[];
extern Vtx VB_hmc_geo_000548_0x7025238[];
extern Vtx VB_hmc_geo_000548_0x7025328[];
extern Vtx VB_hmc_geo_000548_0x7025418[];
extern u8 hmc_geo_000548__texture_070231C8[];
extern u8 hmc_geo_000548__texture_070239C8[];
extern u8 hmc_geo_000548__texture_070241C8[];
extern Light_t Light_hmc_geo_000548_0x7023178;
extern Ambient_t Light_hmc_geo_000548_0x7023180;
extern Gfx DL_hmc_geo_000548_0x7025508[];
#endif