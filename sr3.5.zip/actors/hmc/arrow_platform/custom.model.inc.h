#ifndef hmc_arrow_platform_model_HEADER_H
#define hmc_arrow_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_hmc_geo_0005A0_0x70243b0[];
extern Vtx VB_hmc_geo_0005A0_0x70244a0[];
extern Vtx VB_hmc_geo_0005A0_0x7024590[];
extern Vtx VB_hmc_geo_0005A0_0x7024680[];
extern Vtx VB_hmc_geo_0005A0_0x7024770[];
extern Vtx VB_hmc_geo_0005A0_0x7024860[];
extern Vtx VB_hmc_geo_0005A0_0x7024950[];
extern Vtx VB_hmc_geo_0005A0_0x7024a40[];
extern Vtx VB_hmc_geo_0005A0_0x7024b30[];
extern Vtx VB_hmc_geo_0005A0_0x7024c20[];
extern Vtx VB_hmc_geo_0005A0_0x7024d10[];
extern Vtx VB_hmc_geo_0005A0_0x7024e00[];
extern u8 hmc_geo_0005A0__texture_07022BB0[];
extern u8 hmc_geo_0005A0__texture_070233B0[];
extern u8 hmc_geo_0005A0__texture_07023BB0[];
extern Light_t Light_hmc_geo_0005A0_0x7022b60;
extern Ambient_t Light_hmc_geo_0005A0_0x7022b68;
extern Gfx DL_hmc_geo_0005A0_0x7024ef0[];
#endif