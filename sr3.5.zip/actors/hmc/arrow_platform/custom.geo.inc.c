#include "custom.model.inc.h"
const GeoLayout hmc_geo_0005A0[]= {
GEO_CULLING_RADIUS(550),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_hmc_geo_0005A0_0x7024ef0),
GEO_CLOSE_NODE(),
GEO_END(),
};
