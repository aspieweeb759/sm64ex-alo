#include "custom.model.inc.h"
const GeoLayout hmc_geo_000588[]= {
GEO_CULLING_RADIUS(100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_hmc_geo_000588_0x7024110),
GEO_CLOSE_NODE(),
GEO_END(),
};
