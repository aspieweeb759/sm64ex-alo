#include "custom.model.inc.h"
const GeoLayout invisible_bowser_accessory_geo[]= {
GEO_CULLING_RADIUS(10000),
GEO_OPEN_NODE(),
GEO_ASM(20, geo_update_layer_transparency),
GEO_DISPLAY_LIST(6,DL_invisible_bowser_accessory_geo_0x601eac0),
GEO_CLOSE_NODE(),
GEO_END(),
};
