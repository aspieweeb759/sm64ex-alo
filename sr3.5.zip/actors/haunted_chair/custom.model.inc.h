#ifndef haunted_chair_haunted_chair_model_HEADER_H
#define haunted_chair_haunted_chair_model_HEADER_H
#include "types.h"
extern Vtx VB_haunted_chair_geo_0x5004c78[];
extern Vtx VB_haunted_chair_geo_0x5004d78[];
extern Vtx VB_haunted_chair_geo_0x5004f70[];
extern Vtx VB_haunted_chair_geo_0x5005070[];
extern Vtx VB_haunted_chair_geo_0x5005218[];
extern Vtx VB_haunted_chair_geo_0x5005308[];
extern Vtx VB_haunted_chair_geo_0x5005490[];
extern Vtx VB_haunted_chair_geo_0x5005580[];
extern u8 haunted_chair_geo__texture_05004060[];
extern Light_t Light_haunted_chair_geo_0x5004f60;
extern Ambient_t Light_haunted_chair_geo_0x5004f58;
extern Gfx DL_haunted_chair_geo_0x5005190[];
extern Gfx DL_haunted_chair_geo_0x50050f0[];
extern u8 haunted_chair_geo__texture_05003860[];
extern Light_t Light_haunted_chair_geo_0x5005480;
extern Ambient_t Light_haunted_chair_geo_0x5005478;
extern Gfx DL_haunted_chair_geo_0x5005680[];
extern Gfx DL_haunted_chair_geo_0x50055f0[];
extern Light_t Light_haunted_chair_geo_0x5005208;
extern Ambient_t Light_haunted_chair_geo_0x5005200;
extern Gfx DL_haunted_chair_geo_0x5005408[];
extern Gfx DL_haunted_chair_geo_0x5005378[];
extern u8 haunted_chair_geo__texture_05003060[];
extern Light_t Light_haunted_chair_geo_0x5004c68;
extern Ambient_t Light_haunted_chair_geo_0x5004c60;
extern Gfx DL_haunted_chair_geo_0x5004ee8[];
extern Gfx DL_haunted_chair_geo_0x5004e38[];
#endif