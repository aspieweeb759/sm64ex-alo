#include "custom.model.inc.h"
const GeoLayout geo_bbh_0005B0[]= {
GEO_CULLING_RADIUS(700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_0005B0_0x701fd08),
GEO_CLOSE_NODE(),
GEO_END(),
};
