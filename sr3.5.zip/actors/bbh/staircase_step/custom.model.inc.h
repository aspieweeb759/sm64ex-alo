#ifndef bbh_staircase_step_model_HEADER_H
#define bbh_staircase_step_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_0005B0_0x701f948[];
extern Vtx VB_geo_bbh_0005B0_0x701fa38[];
extern Vtx VB_geo_bbh_0005B0_0x701fb28[];
extern Vtx VB_geo_bbh_0005B0_0x701fc18[];
extern u8 geo_bbh_0005B0__texture_0701F148[];
extern Light_t Light_geo_bbh_0005B0_0x701f0f8;
extern Ambient_t Light_geo_bbh_0005B0_0x701f100;
extern Gfx DL_geo_bbh_0005B0_0x701fd08[];
#endif