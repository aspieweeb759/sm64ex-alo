#include "custom.model.inc.h"
const GeoLayout geo_bbh_0005E0[]= {
GEO_CULLING_RADIUS(650),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_0005E0_0x701f7e8),
GEO_CLOSE_NODE(),
GEO_END(),
};
