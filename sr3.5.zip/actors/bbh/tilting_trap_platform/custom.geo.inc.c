#include "custom.model.inc.h"
const GeoLayout geo_bbh_0005C8[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_0005C8_0x701f5f8),
GEO_CLOSE_NODE(),
GEO_END(),
};
