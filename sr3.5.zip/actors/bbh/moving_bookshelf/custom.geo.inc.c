#include "custom.model.inc.h"
const GeoLayout geo_bbh_000610[]= {
GEO_CULLING_RADIUS(1000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_000610_0x701fd28),
GEO_CLOSE_NODE(),
GEO_END(),
};
