#include "custom.model.inc.h"
const GeoLayout geo_bbh_000628[]= {
GEO_CULLING_RADIUS(600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_geo_bbh_000628_0x701ffe8),
GEO_CLOSE_NODE(),
GEO_END(),
};
