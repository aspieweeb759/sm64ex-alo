#ifndef bbh_mesh_elevator_model_HEADER_H
#define bbh_mesh_elevator_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_000628_0x701fdb8[];
extern Vtx VB_geo_bbh_000628_0x701fea8[];
extern u8 geo_bbh_000628__texture_09000000[];
extern Gfx DL_geo_bbh_000628_0x701ffe8[];
extern Gfx DL_geo_bbh_000628_0x701ff58[];
#endif