#ifndef bbh_coffin_model_HEADER_H
#define bbh_coffin_model_HEADER_H
#include "types.h"
extern Vtx VB_geo_bbh_000658_0x7020bd0[];
extern Vtx VB_geo_bbh_000658_0x7020cc0[];
extern u8 geo_bbh_000658__texture_070203D0[];
extern Light_t Light_geo_bbh_000658_0x7020380;
extern Ambient_t Light_geo_bbh_000658_0x7020388;
extern Gfx DL_geo_bbh_000658_0x7020db0[];
#endif