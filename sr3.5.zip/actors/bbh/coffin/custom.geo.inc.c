#include "custom.model.inc.h"
const GeoLayout geo_bbh_000658[]= {
GEO_CULLING_RADIUS(800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_000658_0x7020db0),
GEO_CLOSE_NODE(),
GEO_END(),
};
