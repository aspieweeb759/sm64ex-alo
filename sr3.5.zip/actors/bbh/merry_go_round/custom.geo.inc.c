#include "custom.model.inc.h"
const GeoLayout geo_bbh_000640[]= {
GEO_CULLING_RADIUS(2300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_000640_0x70202f0),
GEO_CLOSE_NODE(),
GEO_END(),
};
