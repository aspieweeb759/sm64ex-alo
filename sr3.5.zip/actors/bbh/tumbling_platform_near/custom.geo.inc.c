#include "custom.model.inc.h"
const GeoLayout geo_bbh_0005F8[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_geo_bbh_0005F8_0x701fab0),
GEO_CLOSE_NODE(),
GEO_END(),
};
