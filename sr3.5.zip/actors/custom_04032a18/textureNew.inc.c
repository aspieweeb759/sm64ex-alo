ALIGNED8 u8 custom_DL_04032a18__texture_04032780[] = {
#include "actors/custom_04032a18/custom_DL_04032a18_0x4032780_custom.rgba16.inc.c"
};
