ALIGNED8 u8 mad_piano_geo__texture_050072F0[] = {
#include "actors/mad_piano/mad_piano_geo_0x50072f0_custom.rgba16.inc.c"
};
ALIGNED8 u8 mad_piano_geo__texture_05007AF0[] = {
#include "actors/mad_piano/mad_piano_geo_0x5007af0_custom.rgba16.inc.c"
};
ALIGNED8 u8 mad_piano_geo__texture_050082F0[] = {
#include "actors/mad_piano/mad_piano_geo_0x50082f0_custom.rgba16.inc.c"
};
ALIGNED8 u8 mad_piano_geo__texture_05007EF0[] = {
#include "actors/mad_piano/mad_piano_geo_0x5007ef0_custom.rgba16.inc.c"
};
ALIGNED8 u8 mad_piano_geo__texture_050076F0[] = {
#include "actors/mad_piano/mad_piano_geo_0x50076f0_custom.rgba16.inc.c"
};
ALIGNED8 u8 mad_piano_geo__texture_05006AF0[] = {
#include "actors/mad_piano/mad_piano_geo_0x5006af0_custom.rgba16.inc.c"
};
