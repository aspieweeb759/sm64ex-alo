ALIGNED8 u8 mr_blizzard_hidden_geo__texture_05009470[] = {
#include "actors/snowman/mr_blizzard_hidden_geo_0x5009470_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_blizzard_hidden_geo__texture_0500A470[] = {
#include "actors/snowman/mr_blizzard_hidden_geo_0x500a470_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_blizzard_hidden_geo__texture_0500BC70[] = {
#include "actors/snowman/mr_blizzard_hidden_geo_0x500bc70_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_blizzard_hidden_geo__texture_0500B470[] = {
#include "actors/snowman/mr_blizzard_hidden_geo_0x500b470_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_blizzard_hidden_geo__texture_05008C70[] = {
#include "actors/snowman/mr_blizzard_hidden_geo_0x5008c70_custom.rgba16.inc.c"
};
