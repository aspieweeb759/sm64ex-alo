#include "custom.model.inc.h"
const GeoLayout metallic_ball_geo[]= {
GEO_SHADOW(1,150,60),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_metallic_ball_geo_0x60212e8),
GEO_CLOSE_NODE(),
GEO_END(),
};
