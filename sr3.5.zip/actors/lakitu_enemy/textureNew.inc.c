ALIGNED8 u8 enemy_lakitu_geo__texture_050114E0[] = {
#include "actors/lakitu_enemy/enemy_lakitu_geo_0x50114e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 enemy_lakitu_geo__texture_05011CE0[] = {
#include "actors/lakitu_enemy/enemy_lakitu_geo_0x5011ce0_custom.rgba16.inc.c"
};
ALIGNED8 u8 enemy_lakitu_geo__texture_0500F4E0[] = {
#include "actors/lakitu_enemy/enemy_lakitu_geo_0x500f4e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 enemy_lakitu_geo__texture_050104E0[] = {
#include "actors/lakitu_enemy/enemy_lakitu_geo_0x50104e0_custom.rgba16.inc.c"
};
