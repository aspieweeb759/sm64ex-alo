#ifndef bubble_bubble_model_HEADER_H
#define bubble_bubble_model_HEADER_H
#include "types.h"
extern Vtx VB_purple_marble_geo_0x401cd20[];
extern u8 bubble_geo__texture_0401CD60[];
extern Gfx DL_bubble_geo_0x401dd60[];
extern u8 purple_marble_geo__texture_0401D560[];
extern Gfx DL_purple_marble_geo_0x401dde0[];
#endif