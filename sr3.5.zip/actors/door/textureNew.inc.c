ALIGNED8 u8 metal_door_geo__texture_0300E510[] = {
#include "actors/door/metal_door_geo_0x300e510_custom.rgba16.inc.c"
};
ALIGNED8 u8 metal_door_geo__texture_0300D510[] = {
#include "actors/door/metal_door_geo_0x300d510_custom.rgba16.inc.c"
};
ALIGNED8 u8 hazy_maze_door_geo__texture_0300FD10[] = {
#include "actors/door/hazy_maze_door_geo_0x300fd10_custom.rgba16.inc.c"
};
ALIGNED8 u8 hazy_maze_door_geo__texture_0300ED10[] = {
#include "actors/door/hazy_maze_door_geo_0x300ed10_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_door_0_star_geo__texture_0300AD10[] = {
#include "actors/door/castle_door_0_star_geo_0x300ad10_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_door_0_star_geo__texture_03009D10[] = {
#include "actors/door/castle_door_0_star_geo_0x3009d10_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_door_0_star_geo__texture_03011D10[] = {
#include "actors/door/castle_door_0_star_geo_0x3011d10_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_door_1_star_geo__texture_03012510[] = {
#include "actors/door/castle_door_1_star_geo_0x3012510_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_door_3_stars_geo__texture_03012D10[] = {
#include "actors/door/castle_door_3_stars_geo_0x3012d10_custom.rgba16.inc.c"
};
ALIGNED8 u8 key_door_geo__texture_03013510[] = {
#include "actors/door/key_door_geo_0x3013510_custom.rgba16.inc.c"
};
ALIGNED8 u8 wooden_door_geo__texture_0300CD10[] = {
#include "actors/door/wooden_door_geo_0x300cd10_custom.rgba16.inc.c"
};
ALIGNED8 u8 wooden_door_geo__texture_0300BD10[] = {
#include "actors/door/wooden_door_geo_0x300bd10_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_door_geo__texture_03011510[] = {
#include "actors/door/haunted_door_geo_0x3011510_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_door_geo__texture_03010510[] = {
#include "actors/door/haunted_door_geo_0x3010510_custom.rgba16.inc.c"
};
