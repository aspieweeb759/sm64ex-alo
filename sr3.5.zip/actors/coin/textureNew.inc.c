ALIGNED8 u8 yellow_coin_geo__texture_030056D0[] = {
#include "actors/coin/yellow_coin_geo_0x30056d0_custom.rgba16.inc.c"
};
