#include "custom.model.inc.h"
const GeoLayout rr_geo_000860[]= {
GEO_CULLING_RADIUS(1300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000860_0x7019918),
GEO_CLOSE_NODE(),
GEO_END(),
};
