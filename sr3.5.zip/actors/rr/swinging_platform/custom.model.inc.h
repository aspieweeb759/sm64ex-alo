#ifndef rr_swinging_platform_model_HEADER_H
#define rr_swinging_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000860_0x7019228[];
extern Vtx VB_rr_geo_000860_0x7019328[];
extern Vtx VB_rr_geo_000860_0x7019428[];
extern Vtx VB_rr_geo_000860_0x7019528[];
extern Vtx VB_rr_geo_000860_0x7019568[];
extern Vtx VB_rr_geo_000860_0x70195e8[];
extern Vtx VB_rr_geo_000860_0x70196e8[];
extern u8 rr_geo_000860__texture_09007000[];
extern u8 rr_geo_000860__texture_09007800[];
extern u8 rr_geo_000860__texture_09001000[];
extern Gfx DL_rr_geo_000860_0x7019918[];
extern Gfx DL_rr_geo_000860_0x7019728[];
extern Gfx DL_rr_geo_000860_0x7019848[];
extern Gfx DL_rr_geo_000860_0x7019890[];
extern Gfx DL_rr_geo_000860_0x70198f8[];
#endif