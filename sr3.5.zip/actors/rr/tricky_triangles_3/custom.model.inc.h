#ifndef rr_tricky_triangles_3_model_HEADER_H
#define rr_tricky_triangles_3_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000988_0x7020fa8[];
extern Vtx VB_rr_geo_000988_0x7021098[];
extern Vtx VB_rr_geo_000988_0x7021188[];
extern Vtx VB_rr_geo_000988_0x7021278[];
extern Vtx VB_rr_geo_000988_0x7021358[];
extern Vtx VB_rr_geo_000988_0x7021438[];
extern Vtx VB_rr_geo_000988_0x7021528[];
extern Vtx VB_rr_geo_000988_0x7021618[];
extern Vtx VB_rr_geo_000988_0x7021708[];
extern Vtx VB_rr_geo_000988_0x7021808[];
extern Vtx VB_rr_geo_000988_0x70218f8[];
extern Vtx VB_rr_geo_000988_0x70219e8[];
extern Vtx VB_rr_geo_000988_0x7021ae8[];
extern Vtx VB_rr_geo_000988_0x7021bd8[];
extern Vtx VB_rr_geo_000988_0x7021cd8[];
extern Vtx VB_rr_geo_000988_0x7021db8[];
extern Vtx VB_rr_geo_000988_0x7021e98[];
extern Vtx VB_rr_geo_000988_0x7021f88[];
extern Vtx VB_rr_geo_000988_0x7022078[];
extern Vtx VB_rr_geo_000988_0x7022168[];
extern Vtx VB_rr_geo_000988_0x7022258[];
extern Vtx VB_rr_geo_000988_0x7022348[];
extern Vtx VB_rr_geo_000988_0x7022438[];
extern Vtx VB_rr_geo_000988_0x7022528[];
extern Vtx VB_rr_geo_000988_0x70225c8[];
extern Vtx VB_rr_geo_000988_0x70226a8[];
extern Vtx VB_rr_geo_000988_0x70227a8[];
extern Vtx VB_rr_geo_000988_0x70228a8[];
extern Vtx VB_rr_geo_000988_0x7022998[];
extern Vtx VB_rr_geo_000988_0x7022a88[];
extern Vtx VB_rr_geo_000988_0x7022b78[];
extern Vtx VB_rr_geo_000988_0x7022c68[];
extern Vtx VB_rr_geo_000988_0x7022d58[];
extern Vtx VB_rr_geo_000988_0x7022e48[];
extern Vtx VB_rr_geo_000988_0x7022f48[];
extern Vtx VB_rr_geo_000988_0x7023048[];
extern u8 rr_geo_000988__texture_09000800[];
extern u8 rr_geo_000988__texture_09002000[];
extern Gfx DL_rr_geo_000988_0x70239a8[];
extern Gfx DL_rr_geo_000988_0x7023118[];
extern Gfx DL_rr_geo_000988_0x7023728[];
#endif