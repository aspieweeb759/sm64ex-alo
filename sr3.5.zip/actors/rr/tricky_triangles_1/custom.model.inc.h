#ifndef rr_tricky_triangles_1_model_HEADER_H
#define rr_tricky_triangles_1_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000958_0x701c3a0[];
extern Vtx VB_rr_geo_000958_0x701c490[];
extern Vtx VB_rr_geo_000958_0x701c580[];
extern u8 rr_geo_000958__texture_0701BBA0[];
extern Light_t Light_rr_geo_000958_0x701bb90;
extern Ambient_t Light_rr_geo_000958_0x701bb98;
extern Gfx DL_rr_geo_000958_0x701c670[];
#endif