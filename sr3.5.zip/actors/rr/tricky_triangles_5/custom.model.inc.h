#ifndef rr_tricky_triangles_5_model_HEADER_H
#define rr_tricky_triangles_5_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0009B8_0x70264d8[];
extern Vtx VB_rr_geo_0009B8_0x70265c8[];
extern Vtx VB_rr_geo_0009B8_0x70266b8[];
extern Vtx VB_rr_geo_0009B8_0x70267a8[];
extern Vtx VB_rr_geo_0009B8_0x7026888[];
extern Vtx VB_rr_geo_0009B8_0x7026968[];
extern Vtx VB_rr_geo_0009B8_0x7026a58[];
extern Vtx VB_rr_geo_0009B8_0x7026b48[];
extern Vtx VB_rr_geo_0009B8_0x7026c38[];
extern Vtx VB_rr_geo_0009B8_0x7026d38[];
extern Vtx VB_rr_geo_0009B8_0x7026e28[];
extern Vtx VB_rr_geo_0009B8_0x7026f18[];
extern Vtx VB_rr_geo_0009B8_0x7027018[];
extern Vtx VB_rr_geo_0009B8_0x7027108[];
extern Vtx VB_rr_geo_0009B8_0x7027208[];
extern Vtx VB_rr_geo_0009B8_0x70272e8[];
extern Vtx VB_rr_geo_0009B8_0x70273c8[];
extern Vtx VB_rr_geo_0009B8_0x70274b8[];
extern Vtx VB_rr_geo_0009B8_0x70275a8[];
extern Vtx VB_rr_geo_0009B8_0x7027698[];
extern Vtx VB_rr_geo_0009B8_0x7027788[];
extern Vtx VB_rr_geo_0009B8_0x7027878[];
extern Vtx VB_rr_geo_0009B8_0x7027968[];
extern Vtx VB_rr_geo_0009B8_0x7027a58[];
extern Vtx VB_rr_geo_0009B8_0x7027af8[];
extern Vtx VB_rr_geo_0009B8_0x7027be8[];
extern Vtx VB_rr_geo_0009B8_0x7027cd8[];
extern Vtx VB_rr_geo_0009B8_0x7027dc8[];
extern Vtx VB_rr_geo_0009B8_0x7027ea8[];
extern Vtx VB_rr_geo_0009B8_0x7027fa8[];
extern Vtx VB_rr_geo_0009B8_0x7028098[];
extern Vtx VB_rr_geo_0009B8_0x7028198[];
extern Vtx VB_rr_geo_0009B8_0x7028288[];
extern Vtx VB_rr_geo_0009B8_0x7028388[];
extern Vtx VB_rr_geo_0009B8_0x7028468[];
extern u8 rr_geo_0009B8__texture_09000800[];
extern u8 rr_geo_0009B8__texture_09002000[];
extern Gfx DL_rr_geo_0009B8_0x7028dc0[];
extern Gfx DL_rr_geo_0009B8_0x7028538[];
extern Gfx DL_rr_geo_0009B8_0x7028b48[];
#endif