#include "custom.model.inc.h"
const GeoLayout rr_geo_0009B8[]= {
GEO_CULLING_RADIUS(1500),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_0009B8_0x7028dc0),
GEO_CLOSE_NODE(),
GEO_END(),
};
