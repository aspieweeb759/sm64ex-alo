#include "custom.model.inc.h"
const GeoLayout rr_geo_000908[]= {
GEO_CULLING_RADIUS(1000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_rr_geo_000908_0x701bba8),
GEO_CLOSE_NODE(),
GEO_END(),
};
