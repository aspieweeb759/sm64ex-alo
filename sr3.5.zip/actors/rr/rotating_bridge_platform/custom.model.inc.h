#ifndef rr_rotating_bridge_platform_model_HEADER_H
#define rr_rotating_bridge_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000878_0x7019a18[];
extern Vtx VB_rr_geo_000878_0x7019b08[];
extern Vtx VB_rr_geo_000878_0x7019c08[];
extern Vtx VB_rr_geo_000878_0x7019cb8[];
extern Vtx VB_rr_geo_000878_0x7019cf8[];
extern Vtx VB_rr_geo_000878_0x7019d78[];
extern Vtx VB_rr_geo_000878_0x7019e78[];
extern Vtx VB_rr_geo_000878_0x7019f78[];
extern Vtx VB_rr_geo_000878_0x701a068[];
extern u8 rr_geo_000878__texture_09001800[];
extern u8 rr_geo_000878__texture_09007800[];
extern u8 rr_geo_000878__texture_09003000[];
extern u8 rr_geo_000878__texture_09002000[];
extern Light_t Light_rr_geo_000878_0x70199a8;
extern Light_t Light_rr_geo_000878_0x70199c0;
extern Light_t Light_rr_geo_000878_0x70199d8;
extern Light_t Light_rr_geo_000878_0x70199f0;
extern Light_t Light_rr_geo_000878_0x7019a08;
extern Ambient_t Light_rr_geo_000878_0x70199a0;
extern Ambient_t Light_rr_geo_000878_0x70199b8;
extern Ambient_t Light_rr_geo_000878_0x70199d0;
extern Ambient_t Light_rr_geo_000878_0x70199e8;
extern Ambient_t Light_rr_geo_000878_0x7019a00;
extern Gfx DL_rr_geo_000878_0x701a3a0[];
extern Gfx DL_rr_geo_000878_0x701a0f8[];
extern Gfx DL_rr_geo_000878_0x701a1e0[];
extern Gfx DL_rr_geo_000878_0x701a218[];
extern Gfx DL_rr_geo_000878_0x701a320[];
#endif