#ifndef rr_tricky_triangles_2_model_HEADER_H
#define rr_tricky_triangles_2_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000970_0x701e518[];
extern Vtx VB_rr_geo_000970_0x701e608[];
extern Vtx VB_rr_geo_000970_0x701e6f8[];
extern Vtx VB_rr_geo_000970_0x701e7e8[];
extern Vtx VB_rr_geo_000970_0x701e8c8[];
extern Vtx VB_rr_geo_000970_0x701e9a8[];
extern Vtx VB_rr_geo_000970_0x701ea98[];
extern Vtx VB_rr_geo_000970_0x701eb88[];
extern Vtx VB_rr_geo_000970_0x701ec78[];
extern Vtx VB_rr_geo_000970_0x701ed78[];
extern Vtx VB_rr_geo_000970_0x701ee68[];
extern Vtx VB_rr_geo_000970_0x701ef58[];
extern Vtx VB_rr_geo_000970_0x701f058[];
extern Vtx VB_rr_geo_000970_0x701f148[];
extern Vtx VB_rr_geo_000970_0x701f248[];
extern Vtx VB_rr_geo_000970_0x701f328[];
extern Vtx VB_rr_geo_000970_0x701f408[];
extern Vtx VB_rr_geo_000970_0x701f4f8[];
extern Vtx VB_rr_geo_000970_0x701f5e8[];
extern Vtx VB_rr_geo_000970_0x701f6d8[];
extern Vtx VB_rr_geo_000970_0x701f7c8[];
extern Vtx VB_rr_geo_000970_0x701f8b8[];
extern Vtx VB_rr_geo_000970_0x701f9a8[];
extern Vtx VB_rr_geo_000970_0x701fa98[];
extern Vtx VB_rr_geo_000970_0x701fb38[];
extern Vtx VB_rr_geo_000970_0x701fc38[];
extern Vtx VB_rr_geo_000970_0x701fd18[];
extern Vtx VB_rr_geo_000970_0x701fe18[];
extern Vtx VB_rr_geo_000970_0x701ff08[];
extern Vtx VB_rr_geo_000970_0x701fff8[];
extern Vtx VB_rr_geo_000970_0x70200e8[];
extern Vtx VB_rr_geo_000970_0x70201d8[];
extern Vtx VB_rr_geo_000970_0x70202c8[];
extern Vtx VB_rr_geo_000970_0x70203b8[];
extern Vtx VB_rr_geo_000970_0x70204b8[];
extern Vtx VB_rr_geo_000970_0x70205b8[];
extern u8 rr_geo_000970__texture_09000800[];
extern u8 rr_geo_000970__texture_09002000[];
extern Gfx DL_rr_geo_000970_0x7020f18[];
extern Gfx DL_rr_geo_000970_0x7020688[];
extern Gfx DL_rr_geo_000970_0x7020c98[];
#endif