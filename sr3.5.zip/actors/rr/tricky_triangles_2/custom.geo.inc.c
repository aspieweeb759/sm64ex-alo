#include "custom.model.inc.h"
const GeoLayout rr_geo_000970[]= {
GEO_CULLING_RADIUS(1500),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000970_0x7020f18),
GEO_CLOSE_NODE(),
GEO_END(),
};
