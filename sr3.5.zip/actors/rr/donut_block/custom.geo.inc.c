#include "custom.model.inc.h"
const GeoLayout rr_geo_000920[]= {
GEO_CULLING_RADIUS(420),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000920_0x701b660),
GEO_DISPLAY_LIST(4,DL_rr_geo_000920_0x701b798),
GEO_CLOSE_NODE(),
GEO_END(),
};
