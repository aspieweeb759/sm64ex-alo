#include "custom.model.inc.h"
const GeoLayout rr_geo_000848[]= {
GEO_CULLING_RADIUS(500),
GEO_OPEN_NODE(),
GEO_ASM(0, geo_exec_flying_carpet_create),
GEO_CLOSE_NODE(),
GEO_END(),
};
