#include "custom.model.inc.h"
const GeoLayout rr_geo_000690[]= {
GEO_CULLING_RADIUS(3000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000690_0x7004a98),
GEO_CLOSE_NODE(),
GEO_END(),
};
