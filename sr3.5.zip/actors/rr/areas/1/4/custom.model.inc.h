#ifndef rr_4_model_HEADER_H
#define rr_4_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000690_0x7002ef8[];
extern Vtx VB_rr_geo_000690_0x7002fd8[];
extern Vtx VB_rr_geo_000690_0x70030d8[];
extern Vtx VB_rr_geo_000690_0x70031d8[];
extern Vtx VB_rr_geo_000690_0x70032b8[];
extern Vtx VB_rr_geo_000690_0x70033a8[];
extern Vtx VB_rr_geo_000690_0x7003488[];
extern Vtx VB_rr_geo_000690_0x7003568[];
extern Vtx VB_rr_geo_000690_0x7003668[];
extern Vtx VB_rr_geo_000690_0x7003758[];
extern Vtx VB_rr_geo_000690_0x7003858[];
extern Vtx VB_rr_geo_000690_0x7003948[];
extern Vtx VB_rr_geo_000690_0x7003a28[];
extern Vtx VB_rr_geo_000690_0x7003b08[];
extern Vtx VB_rr_geo_000690_0x7003bf8[];
extern Vtx VB_rr_geo_000690_0x7003cf8[];
extern Vtx VB_rr_geo_000690_0x7003de8[];
extern Vtx VB_rr_geo_000690_0x7003ee8[];
extern Vtx VB_rr_geo_000690_0x7003fe8[];
extern Vtx VB_rr_geo_000690_0x7004058[];
extern Vtx VB_rr_geo_000690_0x7004148[];
extern Vtx VB_rr_geo_000690_0x7004248[];
extern Vtx VB_rr_geo_000690_0x7004338[];
extern Vtx VB_rr_geo_000690_0x7004428[];
extern u8 rr_geo_000690__texture_09001800[];
extern u8 rr_geo_000690__texture_09007000[];
extern Gfx DL_rr_geo_000690_0x7004a98[];
extern Gfx DL_rr_geo_000690_0x7004468[];
extern Gfx DL_rr_geo_000690_0x7004950[];
#endif