#include "custom.model.inc.h"
const GeoLayout rr_geo_000788[]= {
GEO_CULLING_RADIUS(4000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000788_0x700f3d0),
GEO_CLOSE_NODE(),
GEO_END(),
};
