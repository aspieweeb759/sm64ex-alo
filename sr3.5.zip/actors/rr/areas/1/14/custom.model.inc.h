#ifndef rr_14_model_HEADER_H
#define rr_14_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000788_0x700f100[];
extern Vtx VB_rr_geo_000788_0x700f1f0[];
extern Vtx VB_rr_geo_000788_0x700f2e0[];
extern u8 rr_geo_000788__texture_0700E900[];
extern Light_t Light_rr_geo_000788_0x700e8b0;
extern Ambient_t Light_rr_geo_000788_0x700e8b8;
extern Gfx DL_rr_geo_000788_0x700f3d0[];
#endif