#ifndef rr_10_model_HEADER_H
#define rr_10_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000720_0x700bbb8[];
extern Vtx VB_rr_geo_000720_0x700bcb8[];
extern Vtx VB_rr_geo_000720_0x700bdb8[];
extern Vtx VB_rr_geo_000720_0x700beb8[];
extern Vtx VB_rr_geo_000720_0x700bf98[];
extern Vtx VB_rr_geo_000720_0x700c098[];
extern Vtx VB_rr_geo_000720_0x700c188[];
extern Vtx VB_rr_geo_000720_0x700c278[];
extern Vtx VB_rr_geo_000720_0x700c358[];
extern Vtx VB_rr_geo_000720_0x700c458[];
extern Vtx VB_rr_geo_000720_0x700c558[];
extern Vtx VB_rr_geo_000720_0x700c658[];
extern u8 rr_geo_000720__texture_09000800[];
extern u8 rr_geo_000720__texture_09007000[];
extern u8 rr_geo_000720__texture_09003000[];
extern Gfx DL_rr_geo_000720_0x700ca38[];
extern Gfx DL_rr_geo_000720_0x700c698[];
extern Gfx DL_rr_geo_000720_0x700c820[];
extern Gfx DL_rr_geo_000720_0x700c9b8[];
#endif