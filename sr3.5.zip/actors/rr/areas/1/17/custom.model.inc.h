#ifndef rr_17_model_HEADER_H
#define rr_17_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0007D0_0x7014de0[];
extern Vtx VB_rr_geo_0007D0_0x7014ee0[];
extern Vtx VB_rr_geo_0007D0_0x7014fd0[];
extern Vtx VB_rr_geo_0007D0_0x70150c0[];
extern Vtx VB_rr_geo_0007D0_0x70151b0[];
extern Vtx VB_rr_geo_0007D0_0x7015290[];
extern u8 rr_geo_0007D0__texture_09000000[];
extern u8 rr_geo_0007D0__texture_09003800[];
extern Gfx DL_rr_geo_0007D0_0x70154f0[];
extern Gfx DL_rr_geo_0007D0_0x7015340[];
extern Gfx DL_rr_geo_0007D0_0x70153a8[];
#endif