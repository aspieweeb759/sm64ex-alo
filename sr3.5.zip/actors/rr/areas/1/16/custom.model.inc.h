#ifndef rr_16_model_HEADER_H
#define rr_16_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0007B8_0x70143c8[];
extern Vtx VB_rr_geo_0007B8_0x70144a8[];
extern Vtx VB_rr_geo_0007B8_0x70145a8[];
extern Vtx VB_rr_geo_0007B8_0x70146a8[];
extern Vtx VB_rr_geo_0007B8_0x70147a8[];
extern Vtx VB_rr_geo_0007B8_0x7014898[];
extern Vtx VB_rr_geo_0007B8_0x7014998[];
extern Vtx VB_rr_geo_0007B8_0x7014a98[];
extern u8 rr_geo_0007B8__texture_09008000[];
extern u8 rr_geo_0007B8__texture_09001800[];
extern Gfx DL_rr_geo_0007B8_0x7014d68[];
extern Gfx DL_rr_geo_0007B8_0x7014b08[];
extern Gfx DL_rr_geo_0007B8_0x7014bb8[];
#endif