#include "custom.model.inc.h"
const GeoLayout rr_geo_0007B8[]= {
GEO_CULLING_RADIUS(1600),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_0007B8_0x7014d68),
GEO_CLOSE_NODE(),
GEO_END(),
};
