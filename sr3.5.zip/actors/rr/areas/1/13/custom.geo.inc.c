#include "custom.model.inc.h"
const GeoLayout rr_geo_000770[]= {
GEO_CULLING_RADIUS(1500),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_rr_geo_000770_0x700e830),
GEO_CLOSE_NODE(),
GEO_END(),
};
