#ifndef rr_13_model_HEADER_H
#define rr_13_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000770_0x700e208[];
extern Vtx VB_rr_geo_000770_0x700e2f8[];
extern Vtx VB_rr_geo_000770_0x700e3e8[];
extern Vtx VB_rr_geo_000770_0x700e4d8[];
extern Vtx VB_rr_geo_000770_0x700e5c8[];
extern u8 rr_geo_000770__texture_09005800[];
extern Gfx DL_rr_geo_000770_0x700e830[];
extern Gfx DL_rr_geo_000770_0x700e6c8[];
#endif