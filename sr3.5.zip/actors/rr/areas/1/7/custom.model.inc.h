#ifndef rr_7_model_HEADER_H
#define rr_7_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0006D8_0x7007ef0[];
extern Vtx VB_rr_geo_0006D8_0x7007ff0[];
extern Vtx VB_rr_geo_0006D8_0x70080f0[];
extern u8 rr_geo_0006D8__texture_09001800[];
extern Gfx DL_rr_geo_0006D8_0x7008258[];
extern Gfx DL_rr_geo_0006D8_0x7008170[];
#endif