#ifndef rr_9_model_HEADER_H
#define rr_9_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000708_0x7008e98[];
extern Vtx VB_rr_geo_000708_0x7008f98[];
extern Vtx VB_rr_geo_000708_0x7009098[];
extern Vtx VB_rr_geo_000708_0x7009188[];
extern Vtx VB_rr_geo_000708_0x7009268[];
extern Vtx VB_rr_geo_000708_0x7009358[];
extern Vtx VB_rr_geo_000708_0x7009448[];
extern Vtx VB_rr_geo_000708_0x7009538[];
extern Vtx VB_rr_geo_000708_0x7009628[];
extern Vtx VB_rr_geo_000708_0x7009718[];
extern Vtx VB_rr_geo_000708_0x7009808[];
extern Vtx VB_rr_geo_000708_0x70098f8[];
extern Vtx VB_rr_geo_000708_0x70099e8[];
extern Vtx VB_rr_geo_000708_0x7009ad8[];
extern Vtx VB_rr_geo_000708_0x7009bd8[];
extern Vtx VB_rr_geo_000708_0x7009cd8[];
extern Vtx VB_rr_geo_000708_0x7009dd8[];
extern Vtx VB_rr_geo_000708_0x7009eb8[];
extern Vtx VB_rr_geo_000708_0x7009fb8[];
extern Vtx VB_rr_geo_000708_0x700a098[];
extern Vtx VB_rr_geo_000708_0x700a188[];
extern Vtx VB_rr_geo_000708_0x700a288[];
extern Vtx VB_rr_geo_000708_0x700a388[];
extern Vtx VB_rr_geo_000708_0x700a468[];
extern Vtx VB_rr_geo_000708_0x700a568[];
extern Vtx VB_rr_geo_000708_0x700a658[];
extern Vtx VB_rr_geo_000708_0x700a748[];
extern Vtx VB_rr_geo_000708_0x700a838[];
extern Vtx VB_rr_geo_000708_0x700a928[];
extern Vtx VB_rr_geo_000708_0x700aa18[];
extern Vtx VB_rr_geo_000708_0x700ab18[];
extern Vtx VB_rr_geo_000708_0x700ac08[];
extern Vtx VB_rr_geo_000708_0x700ace8[];
extern Vtx VB_rr_geo_000708_0x700adc8[];
extern Vtx VB_rr_geo_000708_0x700aeb8[];
extern Vtx VB_rr_geo_000708_0x700afb8[];
extern Vtx VB_rr_geo_000708_0x700b0b8[];
extern u8 rr_geo_000708__texture_09007000[];
extern Gfx DL_rr_geo_000708_0x700bb48[];
extern Gfx DL_rr_geo_000708_0x700b138[];
#endif