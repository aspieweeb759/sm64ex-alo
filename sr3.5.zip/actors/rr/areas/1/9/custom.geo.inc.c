#include "custom.model.inc.h"
const GeoLayout rr_geo_000708[]= {
GEO_CULLING_RADIUS(4000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000708_0x700bb48),
GEO_CLOSE_NODE(),
GEO_END(),
};
