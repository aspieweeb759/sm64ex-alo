#include "custom.model.inc.h"
const GeoLayout rr_geo_000800[]= {
GEO_CULLING_RADIUS(4500),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_rr_geo_000800_0x7016600),
GEO_CLOSE_NODE(),
GEO_END(),
};
