#ifndef rr_19_model_HEADER_H
#define rr_19_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000800_0x7016330[];
extern Vtx VB_rr_geo_000800_0x7016420[];
extern Vtx VB_rr_geo_000800_0x7016510[];
extern u8 rr_geo_000800__texture_07015B30[];
extern Light_t Light_rr_geo_000800_0x7015b20;
extern Ambient_t Light_rr_geo_000800_0x7015b28;
extern Gfx DL_rr_geo_000800_0x7016600[];
#endif