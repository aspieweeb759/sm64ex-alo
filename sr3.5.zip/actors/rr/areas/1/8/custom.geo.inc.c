#include "custom.model.inc.h"
const GeoLayout rr_geo_0006F0[]= {
GEO_CULLING_RADIUS(2800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_0006F0_0x7008e20),
GEO_CLOSE_NODE(),
GEO_END(),
};
