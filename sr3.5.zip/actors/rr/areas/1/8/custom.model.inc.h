#ifndef rr_8_model_HEADER_H
#define rr_8_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0006F0_0x70082c8[];
extern Vtx VB_rr_geo_0006F0_0x70083c8[];
extern Vtx VB_rr_geo_0006F0_0x70084c8[];
extern Vtx VB_rr_geo_0006F0_0x70085b8[];
extern Vtx VB_rr_geo_0006F0_0x70086b8[];
extern Vtx VB_rr_geo_0006F0_0x7008798[];
extern Vtx VB_rr_geo_0006F0_0x7008858[];
extern Vtx VB_rr_geo_0006F0_0x7008958[];
extern Vtx VB_rr_geo_0006F0_0x7008a58[];
extern u8 rr_geo_0006F0__texture_09001800[];
extern u8 rr_geo_0006F0__texture_09007000[];
extern Gfx DL_rr_geo_0006F0_0x7008e20[];
extern Gfx DL_rr_geo_0006F0_0x7008b58[];
extern Gfx DL_rr_geo_0006F0_0x7008d28[];
#endif