#ifndef rr_2_model_HEADER_H
#define rr_2_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000660_0x7002a28[];
extern Vtx VB_rr_geo_000660_0x7002b18[];
extern Vtx VB_rr_geo_000660_0x7002c08[];
extern Vtx VB_rr_geo_000660_0x7002cf8[];
extern Vtx VB_rr_geo_000660_0x7002de8[];
extern Vtx VB_rr_geo_000660_0x7002ed8[];
extern Vtx VB_rr_geo_000660_0x7002fc8[];
extern Vtx VB_rr_geo_000660_0x70030b8[];
extern Vtx VB_rr_geo_000660_0x70031a8[];
extern Vtx VB_rr_geo_000660_0x7003298[];
extern Vtx VB_rr_geo_000660_0x7003388[];
extern Vtx VB_rr_geo_000660_0x7003478[];
extern u8 rr_geo_000660__texture_07002228[];
extern Light_t Light_rr_geo_000660_0x70021d8;
extern Ambient_t Light_rr_geo_000660_0x70021e0;
extern Gfx DL_rr_geo_000660_0x7003568[];
#endif