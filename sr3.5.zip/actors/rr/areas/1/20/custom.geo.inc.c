#include "custom.model.inc.h"
const GeoLayout rr_geo_000818[]= {
GEO_CULLING_RADIUS(5000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_rr_geo_000818_0x7018990),
GEO_CLOSE_NODE(),
GEO_END(),
};
