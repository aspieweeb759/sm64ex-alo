#ifndef rr_20_model_HEADER_H
#define rr_20_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000818_0x70173e8[];
extern Vtx VB_rr_geo_000818_0x70174d8[];
extern Vtx VB_rr_geo_000818_0x70175c8[];
extern Vtx VB_rr_geo_000818_0x70176b8[];
extern Vtx VB_rr_geo_000818_0x70177b8[];
extern Vtx VB_rr_geo_000818_0x7017898[];
extern Vtx VB_rr_geo_000818_0x7017978[];
extern Vtx VB_rr_geo_000818_0x7017a58[];
extern Vtx VB_rr_geo_000818_0x7017b38[];
extern Vtx VB_rr_geo_000818_0x7017c18[];
extern Vtx VB_rr_geo_000818_0x7017d18[];
extern Vtx VB_rr_geo_000818_0x7017dc8[];
extern Vtx VB_rr_geo_000818_0x7017e48[];
extern Vtx VB_rr_geo_000818_0x7017f38[];
extern Vtx VB_rr_geo_000818_0x7018028[];
extern Vtx VB_rr_geo_000818_0x7018128[];
extern Vtx VB_rr_geo_000818_0x7018218[];
extern Vtx VB_rr_geo_000818_0x7018308[];
extern Vtx VB_rr_geo_000818_0x7018408[];
extern u8 rr_geo_000818__texture_09005800[];
extern u8 rr_geo_000818__texture_09006000[];
extern u8 rr_geo_000818__texture_07001800[];
extern Gfx DL_rr_geo_000818_0x7018990[];
extern Gfx DL_rr_geo_000818_0x7018488[];
extern Gfx DL_rr_geo_000818_0x7018770[];
extern Gfx DL_rr_geo_000818_0x70187b8[];
#endif