#ifndef rr_6_model_HEADER_H
#define rr_6_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0006C0_0x7005d00[];
extern Vtx VB_rr_geo_0006C0_0x7005df0[];
extern Vtx VB_rr_geo_0006C0_0x7005ef0[];
extern Vtx VB_rr_geo_0006C0_0x7005ff0[];
extern Vtx VB_rr_geo_0006C0_0x70060f0[];
extern Vtx VB_rr_geo_0006C0_0x70061e0[];
extern Vtx VB_rr_geo_0006C0_0x70062d0[];
extern Vtx VB_rr_geo_0006C0_0x70063b0[];
extern Vtx VB_rr_geo_0006C0_0x70064a0[];
extern Vtx VB_rr_geo_0006C0_0x7006590[];
extern Vtx VB_rr_geo_0006C0_0x7006690[];
extern Vtx VB_rr_geo_0006C0_0x70066d0[];
extern Vtx VB_rr_geo_0006C0_0x70067c0[];
extern Vtx VB_rr_geo_0006C0_0x70068b0[];
extern Vtx VB_rr_geo_0006C0_0x70069a0[];
extern Vtx VB_rr_geo_0006C0_0x7006aa0[];
extern Vtx VB_rr_geo_0006C0_0x7006b80[];
extern Vtx VB_rr_geo_0006C0_0x7006c60[];
extern Vtx VB_rr_geo_0006C0_0x7006d50[];
extern Vtx VB_rr_geo_0006C0_0x7006e50[];
extern Vtx VB_rr_geo_0006C0_0x7006f30[];
extern Vtx VB_rr_geo_0006C0_0x7007020[];
extern Vtx VB_rr_geo_0006C0_0x7007110[];
extern Vtx VB_rr_geo_0006C0_0x7007150[];
extern Vtx VB_rr_geo_0006C0_0x7007250[];
extern Vtx VB_rr_geo_0006C0_0x7007350[];
extern Vtx VB_rr_geo_0006C0_0x70073d0[];
extern Vtx VB_rr_geo_0006C0_0x70074d0[];
extern Vtx VB_rr_geo_0006C0_0x70075c0[];
extern u8 rr_geo_0006C0__texture_09001800[];
extern u8 rr_geo_0006C0__texture_09008000[];
extern u8 rr_geo_0006C0__texture_09007000[];
extern u8 rr_geo_0006C0__texture_09004800[];
extern u8 rr_geo_0006C0__texture_09000800[];
extern Gfx DL_rr_geo_0006C0_0x7007e60[];
extern Gfx DL_rr_geo_0006C0_0x70076b0[];
extern Gfx DL_rr_geo_0006C0_0x7007868[];
extern Gfx DL_rr_geo_0006C0_0x70079b0[];
extern Gfx DL_rr_geo_0006C0_0x7007cb0[];
extern Gfx DL_rr_geo_0006C0_0x7007d88[];
#endif