#ifndef rr_15_model_HEADER_H
#define rr_15_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0007A0_0x7013038[];
extern Vtx VB_rr_geo_0007A0_0x7013128[];
extern Vtx VB_rr_geo_0007A0_0x7013218[];
extern Vtx VB_rr_geo_0007A0_0x7013308[];
extern Vtx VB_rr_geo_0007A0_0x70133f8[];
extern Vtx VB_rr_geo_0007A0_0x70134e8[];
extern Vtx VB_rr_geo_0007A0_0x70135d8[];
extern Vtx VB_rr_geo_0007A0_0x70136c8[];
extern Vtx VB_rr_geo_0007A0_0x70137b8[];
extern Vtx VB_rr_geo_0007A0_0x70138a8[];
extern Vtx VB_rr_geo_0007A0_0x7013998[];
extern Vtx VB_rr_geo_0007A0_0x7013a88[];
extern u8 rr_geo_0007A0__texture_07012838[];
extern Light_t Light_rr_geo_0007A0_0x70127e8;
extern Ambient_t Light_rr_geo_0007A0_0x70127f0;
extern Gfx DL_rr_geo_0007A0_0x7013b78[];
#endif