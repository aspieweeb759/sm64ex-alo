#include "custom.model.inc.h"
const GeoLayout rr_geo_000738[]= {
GEO_CULLING_RADIUS(4000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000738_0x700dbd8),
GEO_DISPLAY_LIST(4,DL_rr_geo_000738_0x700de88),
GEO_CLOSE_NODE(),
GEO_END(),
};
