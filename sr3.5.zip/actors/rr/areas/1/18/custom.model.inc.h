#ifndef rr_18_model_HEADER_H
#define rr_18_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0007E8_0x7015d90[];
extern Vtx VB_rr_geo_0007E8_0x7015e80[];
extern Vtx VB_rr_geo_0007E8_0x7015f70[];
extern Vtx VB_rr_geo_0007E8_0x7016060[];
extern Vtx VB_rr_geo_0007E8_0x7016150[];
extern Vtx VB_rr_geo_0007E8_0x7016240[];
extern Vtx VB_rr_geo_0007E8_0x7016330[];
extern Vtx VB_rr_geo_0007E8_0x7016420[];
extern Vtx VB_rr_geo_0007E8_0x7016510[];
extern Vtx VB_rr_geo_0007E8_0x7016600[];
extern Vtx VB_rr_geo_0007E8_0x70166f0[];
extern Vtx VB_rr_geo_0007E8_0x70167e0[];
extern u8 rr_geo_0007E8__texture_07015590[];
extern Light_t Light_rr_geo_0007E8_0x7015580;
extern Ambient_t Light_rr_geo_0007E8_0x7015588;
extern Gfx DL_rr_geo_0007E8_0x70168d0[];
#endif