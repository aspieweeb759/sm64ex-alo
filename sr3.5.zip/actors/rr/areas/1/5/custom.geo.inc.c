#include "custom.model.inc.h"
const GeoLayout rr_geo_0006A8[]= {
GEO_CULLING_RADIUS(3000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_0006A8_0x7005c80),
GEO_CLOSE_NODE(),
GEO_END(),
};
