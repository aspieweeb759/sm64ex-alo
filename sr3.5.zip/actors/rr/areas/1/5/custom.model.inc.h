#ifndef rr_5_model_HEADER_H
#define rr_5_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0006A8_0x7004b10[];
extern Vtx VB_rr_geo_0006A8_0x7004c10[];
extern Vtx VB_rr_geo_0006A8_0x7004d10[];
extern Vtx VB_rr_geo_0006A8_0x7004e00[];
extern Vtx VB_rr_geo_0006A8_0x7004ee0[];
extern Vtx VB_rr_geo_0006A8_0x7004fd0[];
extern Vtx VB_rr_geo_0006A8_0x70050c0[];
extern Vtx VB_rr_geo_0006A8_0x70051b0[];
extern Vtx VB_rr_geo_0006A8_0x70052b0[];
extern Vtx VB_rr_geo_0006A8_0x70053b0[];
extern Vtx VB_rr_geo_0006A8_0x70054b0[];
extern Vtx VB_rr_geo_0006A8_0x70055b0[];
extern Vtx VB_rr_geo_0006A8_0x70056b0[];
extern Vtx VB_rr_geo_0006A8_0x70056f0[];
extern u8 rr_geo_0006A8__texture_09007000[];
extern u8 rr_geo_0006A8__texture_09001800[];
extern u8 rr_geo_0006A8__texture_09000800[];
extern Gfx DL_rr_geo_0006A8_0x7005c80[];
extern Gfx DL_rr_geo_0006A8_0x70057f0[];
extern Gfx DL_rr_geo_0006A8_0x7005a48[];
extern Gfx DL_rr_geo_0006A8_0x7005c18[];
#endif