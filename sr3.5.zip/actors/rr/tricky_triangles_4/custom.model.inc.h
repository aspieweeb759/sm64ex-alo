#ifndef rr_tricky_triangles_4_model_HEADER_H
#define rr_tricky_triangles_4_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0009A0_0x7023a38[];
extern Vtx VB_rr_geo_0009A0_0x7023b28[];
extern Vtx VB_rr_geo_0009A0_0x7023c18[];
extern Vtx VB_rr_geo_0009A0_0x7023d08[];
extern Vtx VB_rr_geo_0009A0_0x7023de8[];
extern Vtx VB_rr_geo_0009A0_0x7023ec8[];
extern Vtx VB_rr_geo_0009A0_0x7023fb8[];
extern Vtx VB_rr_geo_0009A0_0x70240a8[];
extern Vtx VB_rr_geo_0009A0_0x7024198[];
extern Vtx VB_rr_geo_0009A0_0x7024298[];
extern Vtx VB_rr_geo_0009A0_0x7024388[];
extern Vtx VB_rr_geo_0009A0_0x7024478[];
extern Vtx VB_rr_geo_0009A0_0x7024578[];
extern Vtx VB_rr_geo_0009A0_0x7024668[];
extern Vtx VB_rr_geo_0009A0_0x7024768[];
extern Vtx VB_rr_geo_0009A0_0x7024848[];
extern Vtx VB_rr_geo_0009A0_0x7024928[];
extern Vtx VB_rr_geo_0009A0_0x7024a18[];
extern Vtx VB_rr_geo_0009A0_0x7024b08[];
extern Vtx VB_rr_geo_0009A0_0x7024bf8[];
extern Vtx VB_rr_geo_0009A0_0x7024ce8[];
extern Vtx VB_rr_geo_0009A0_0x7024dd8[];
extern Vtx VB_rr_geo_0009A0_0x7024ec8[];
extern Vtx VB_rr_geo_0009A0_0x7024fb8[];
extern Vtx VB_rr_geo_0009A0_0x7025058[];
extern Vtx VB_rr_geo_0009A0_0x7025158[];
extern Vtx VB_rr_geo_0009A0_0x7025238[];
extern Vtx VB_rr_geo_0009A0_0x7025338[];
extern Vtx VB_rr_geo_0009A0_0x7025428[];
extern Vtx VB_rr_geo_0009A0_0x7025518[];
extern Vtx VB_rr_geo_0009A0_0x7025608[];
extern Vtx VB_rr_geo_0009A0_0x7025708[];
extern Vtx VB_rr_geo_0009A0_0x70257e8[];
extern Vtx VB_rr_geo_0009A0_0x70258e8[];
extern Vtx VB_rr_geo_0009A0_0x70259d8[];
extern Vtx VB_rr_geo_0009A0_0x7025ac8[];
extern u8 rr_geo_0009A0__texture_09000800[];
extern u8 rr_geo_0009A0__texture_09002000[];
extern Gfx DL_rr_geo_0009A0_0x7026448[];
extern Gfx DL_rr_geo_0009A0_0x7025bb8[];
extern Gfx DL_rr_geo_0009A0_0x70261c8[];
#endif