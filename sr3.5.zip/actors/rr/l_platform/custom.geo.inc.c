#include "custom.model.inc.h"
const GeoLayout rr_geo_000940[]= {
GEO_CULLING_RADIUS(1100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_000940_0x701bb20),
GEO_CLOSE_NODE(),
GEO_END(),
};
