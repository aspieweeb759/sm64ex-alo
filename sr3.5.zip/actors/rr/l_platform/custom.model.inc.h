#ifndef rr_l_platform_model_HEADER_H
#define rr_l_platform_model_HEADER_H
#include "types.h"
#endif