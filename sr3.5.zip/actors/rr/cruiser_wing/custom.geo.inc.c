#include "custom.model.inc.h"
const GeoLayout rr_geo_000890[]= {
GEO_CULLING_RADIUS(1200),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_rr_geo_000890_0x701a4b8),
GEO_CLOSE_NODE(),
GEO_END(),
};
