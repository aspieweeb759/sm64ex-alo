#ifndef rr_cruiser_wing_model_HEADER_H
#define rr_cruiser_wing_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_000890_0x701a440[];
extern u8 rr_geo_000890__texture_07000800[];
extern Gfx DL_rr_geo_000890_0x701a4b8[];
extern Gfx DL_rr_geo_000890_0x701a480[];
#endif