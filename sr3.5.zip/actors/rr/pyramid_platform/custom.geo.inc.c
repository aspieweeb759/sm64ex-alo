#include "custom.model.inc.h"
const GeoLayout rr_geo_0008D8[]= {
GEO_CULLING_RADIUS(700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_rr_geo_0008D8_0x701add8),
GEO_CLOSE_NODE(),
GEO_END(),
};
