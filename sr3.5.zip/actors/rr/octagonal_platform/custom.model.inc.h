#ifndef rr_octagonal_platform_model_HEADER_H
#define rr_octagonal_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0008A8_0x701a540[];
extern Vtx VB_rr_geo_0008A8_0x701a630[];
extern Vtx VB_rr_geo_0008A8_0x701a720[];
extern Vtx VB_rr_geo_0008A8_0x701a810[];
extern u8 rr_geo_0008A8__texture_09001800[];
extern Light_t Light_rr_geo_0008A8_0x701a530;
extern Ambient_t Light_rr_geo_0008A8_0x701a528;
extern Gfx DL_rr_geo_0008A8_0x701a9b0[];
extern Gfx DL_rr_geo_0008A8_0x701a880[];
#endif