#include "custom.model.inc.h"
const GeoLayout rr_geo_0008C0[]= {
GEO_CULLING_RADIUS(700),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_rr_geo_0008C0_0x701bd70),
GEO_CLOSE_NODE(),
GEO_END(),
};
