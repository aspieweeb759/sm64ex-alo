#ifndef rr_sliding_platform_model_HEADER_H
#define rr_sliding_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_rr_geo_0008C0_0x701b230[];
extern Vtx VB_rr_geo_0008C0_0x701b320[];
extern Vtx VB_rr_geo_0008C0_0x701b410[];
extern Vtx VB_rr_geo_0008C0_0x701b500[];
extern Vtx VB_rr_geo_0008C0_0x701b5f0[];
extern Vtx VB_rr_geo_0008C0_0x701b6e0[];
extern Vtx VB_rr_geo_0008C0_0x701b7d0[];
extern Vtx VB_rr_geo_0008C0_0x701b8c0[];
extern Vtx VB_rr_geo_0008C0_0x701b9b0[];
extern Vtx VB_rr_geo_0008C0_0x701baa0[];
extern Vtx VB_rr_geo_0008C0_0x701bb90[];
extern Vtx VB_rr_geo_0008C0_0x701bc80[];
extern u8 rr_geo_0008C0__texture_0701AA30[];
extern Light_t Light_rr_geo_0008C0_0x701aa20;
extern Ambient_t Light_rr_geo_0008C0_0x701aa28;
extern Gfx DL_rr_geo_0008C0_0x701bd70[];
#endif