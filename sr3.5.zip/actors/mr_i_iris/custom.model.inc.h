#ifndef mr_i_iris_mr_i_iris_model_HEADER_H
#define mr_i_iris_mr_i_iris_model_HEADER_H
#include "types.h"
extern Vtx VB_mr_i_iris_geo_0x6002130[];
extern u8 mr_i_iris_geo__texture_06002170[];
extern Gfx DL_mr_i_iris_geo_0x60041d8[];
extern Gfx DL_mr_i_iris_geo_0x6004170[];
extern u8 mr_i_iris_geo__texture_06002970[];
extern Gfx DL_mr_i_iris_geo_0x60041f0[];
extern u8 mr_i_iris_geo__texture_06003170[];
extern Gfx DL_mr_i_iris_geo_0x6004208[];
extern u8 mr_i_iris_geo__texture_06003970[];
extern Gfx DL_mr_i_iris_geo_0x6004220[];
#endif