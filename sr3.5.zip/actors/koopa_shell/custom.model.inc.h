#ifndef koopa_shell_koopa_shell_model_HEADER_H
#define koopa_shell_koopa_shell_model_HEADER_H
#include "types.h"
extern Vtx VB_koopa_shell_geo_0x80284a0[];
extern Vtx VB_koopa_shell_geo_0x8028540[];
extern Vtx VB_koopa_shell_geo_0x8028620[];
extern Vtx VB_koopa_shell_geo_0x8028670[];
extern Vtx VB_koopa_shell_geo_0x8028760[];
extern Vtx VB_koopa_shell_geo_0x8028850[];
extern u8 koopa_shell_geo__texture_08027CA0[];
extern u8 koopa_shell_geo__texture_080274A0[];
extern Light_t Light_koopa_shell_geo_0x8027478;
extern Light_t Light_koopa_shell_geo_0x8027490;
extern Ambient_t Light_koopa_shell_geo_0x8027470;
extern Ambient_t Light_koopa_shell_geo_0x8027488;
extern Gfx DL_koopa_shell_geo_0x8028b78[];
extern Gfx DL_koopa_shell_geo_0x80288e0[];
extern Gfx DL_koopa_shell_geo_0x8028978[];
extern Gfx DL_koopa_shell_geo_0x8028a20[];
#endif