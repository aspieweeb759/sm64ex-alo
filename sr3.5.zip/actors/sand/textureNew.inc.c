ALIGNED8 u8 sand_seg3_dl_0302BCD0__texture_0302BAD0[] = {
#include "actors/sand/sand_seg3_dl_0302BCD0_0x302bad0_custom.rgba16.inc.c"
};
