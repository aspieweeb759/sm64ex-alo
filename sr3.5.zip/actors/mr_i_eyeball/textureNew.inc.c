ALIGNED8 u8 mr_i_geo__texture_06000080[] = {
#include "actors/mr_i_eyeball/mr_i_geo_0x6000080_custom.rgba16.inc.c"
};
ALIGNED8 u8 mr_i_geo__texture_06001080[] = {
#include "actors/mr_i_eyeball/mr_i_geo_0x6001080_custom.rgba16.inc.c"
};
