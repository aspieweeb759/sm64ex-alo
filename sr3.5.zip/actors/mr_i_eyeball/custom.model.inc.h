#ifndef mr_i_eyeball_mr_i_eyeball_model_HEADER_H
#define mr_i_eyeball_mr_i_eyeball_model_HEADER_H
#include "types.h"
extern Vtx VB_mr_i_geo_0x6000000[];
extern u8 mr_i_geo__texture_06000080[];
extern u8 mr_i_geo__texture_06001080[];
extern Gfx DL_mr_i_geo_0x6002080[];
#endif