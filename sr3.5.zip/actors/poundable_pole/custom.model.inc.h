#ifndef poundable_pole_poundable_pole_model_HEADER_H
#define poundable_pole_poundable_pole_model_HEADER_H
#include "types.h"
extern Vtx VB_wooden_post_geo_0x6002050[];
extern Vtx VB_wooden_post_geo_0x60020d0[];
extern Vtx VB_wooden_post_geo_0x60021c0[];
extern Vtx VB_wooden_post_geo_0x60022b0[];
extern u8 wooden_post_geo__texture_06001050[];
extern u8 wooden_post_geo__texture_06001850[];
extern Light_t Light_wooden_post_geo_0x6001040;
extern Ambient_t Light_wooden_post_geo_0x6001038;
extern Gfx DL_wooden_post_geo_0x6002410[];
extern Gfx DL_wooden_post_geo_0x60022f0[];
extern Gfx DL_wooden_post_geo_0x6002358[];
#endif