ALIGNED8 u8 klepto_geo__texture_05003008[] = {
#include "actors/klepto/klepto_geo_0x5003008_custom.rgba16.inc.c"
};
ALIGNED8 u8 klepto_geo__texture_05000008[] = {
#include "actors/klepto/klepto_geo_0x5000008_custom.rgba16.inc.c"
};
ALIGNED8 u8 klepto_geo__texture_05000808[] = {
#include "actors/klepto/klepto_geo_0x5000808_custom.rgba16.inc.c"
};
ALIGNED8 u8 klepto_geo__texture_05001008[] = {
#include "actors/klepto/klepto_geo_0x5001008_custom.rgba16.inc.c"
};
ALIGNED8 u8 klepto_geo__texture_05002008[] = {
#include "actors/klepto/klepto_geo_0x5002008_custom.rgba16.inc.c"
};
