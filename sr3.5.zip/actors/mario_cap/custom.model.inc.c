#include "custom.model.inc.h"
Vtx VB_marios_cap_geo_0x3022750[] = {
{{{ 33, 35, 118 }, 0, { 728, 758 }, { 48, 38, 110, 255}}},
{{{ 96, 22, 45 }, 0, { 1240, 876 }, { 72, 164, 49, 255}}},
{{{ 71, 101, 113 }, 0, { 1028, 148 }, { 85, 22, 91, 255}}},
{{{ 0, 110, 143 }, 0, { 460, 68 }, { 0, 52, 115, 255}}},
{{{ -31, 35, 118 }, 0, { 206, 762 }, { 208, 38, 111, 255}}},
{{{ -70, 101, 113 }, 0, { -106, 158 }, { 171, 22, 91, 255}}},
{{{ -95, 22, 46 }, 0, { -302, 890 }, { 168, 185, 56, 255}}},
};

Vtx VB_marios_cap_geo_0x30227c0[] = {
{{{ -66, 2, 139 }, 0, { 0, 0 }, { 176, 187, 69, 255}}},
{{{ 0, 0, 163 }, 0, { 0, 0 }, { 0, 186, 105, 255}}},
{{{ -31, 35, 118 }, 0, { 0, 0 }, { 208, 38, 111, 255}}},
{{{ -32, 17, 109 }, 0, { 0, 0 }, { 0, 131, 240, 255}}},
{{{ 33, 17, 109 }, 0, { 0, 0 }, { 251, 132, 234, 255}}},
{{{ -95, 22, 46 }, 0, { 0, 0 }, { 168, 185, 56, 255}}},
{{{ -101, 10, -7 }, 0, { 0, 0 }, { 216, 137, 17, 255}}},
{{{ -70, 101, 113 }, 0, { 0, 0 }, { 171, 22, 91, 255}}},
{{{ -135, 70, 23 }, 0, { 0, 0 }, { 132, 21, 16, 255}}},
{{{ -125, 38, -45 }, 0, { 0, 0 }, { 141, 236, 209, 255}}},
{{{ -86, 1, -60 }, 0, { 0, 0 }, { 206, 140, 246, 255}}},
{{{ -41, 144, 64 }, 0, { 0, 0 }, { 220, 121, 0, 255}}},
{{{ -76, 84, -60 }, 0, { 0, 0 }, { 213, 110, 211, 255}}},
{{{ 136, 70, 22 }, 0, { 0, 0 }, { 123, 22, 16, 255}}},
{{{ 71, 101, 113 }, 0, { 0, 0 }, { 85, 22, 91, 255}}},
{{{ 96, 22, 45 }, 0, { 0, 0 }, { 72, 164, 49, 255}}},
};

Vtx VB_marios_cap_geo_0x30228c0[] = {
{{{ 42, 144, 64 }, 0, { 0, 0 }, { 43, 118, 13, 255}}},
{{{ 136, 70, 22 }, 0, { 0, 0 }, { 123, 22, 16, 255}}},
{{{ 76, 84, -60 }, 0, { 0, 0 }, { 42, 108, 207, 255}}},
{{{ 103, 10, -6 }, 0, { 0, 0 }, { 66, 150, 18, 255}}},
{{{ 126, 38, -46 }, 0, { 0, 0 }, { 115, 236, 208, 255}}},
{{{ 71, 101, 113 }, 0, { 0, 0 }, { 85, 22, 91, 255}}},
{{{ 96, 22, 45 }, 0, { 0, 0 }, { 72, 164, 49, 255}}},
{{{ 67, 2, 139 }, 0, { 0, 0 }, { 80, 186, 68, 255}}},
{{{ 33, 17, 109 }, 0, { 0, 0 }, { 251, 132, 234, 255}}},
{{{ 33, 35, 118 }, 0, { 0, 0 }, { 48, 38, 110, 255}}},
{{{ 86, 1, -60 }, 0, { 0, 0 }, { 32, 134, 254, 255}}},
{{{ 0, 0, 163 }, 0, { 0, 0 }, { 0, 186, 105, 255}}},
{{{ -31, 35, 118 }, 0, { 0, 0 }, { 208, 38, 111, 255}}},
{{{ 53, 0, -118 }, 0, { 0, 0 }, { 44, 181, 165, 255}}},
{{{ 49, 62, -139 }, 0, { 0, 0 }, { 50, 73, 166, 255}}},
};

Vtx VB_marios_cap_geo_0x30229b0[] = {
{{{ -76, 84, -60 }, 0, { 0, 0 }, { 213, 110, 211, 255}}},
{{{ -41, 144, 64 }, 0, { 0, 0 }, { 220, 121, 0, 255}}},
{{{ 76, 84, -60 }, 0, { 0, 0 }, { 42, 108, 207, 255}}},
{{{ 0, 110, 143 }, 0, { 0, 0 }, { 0, 52, 115, 255}}},
{{{ 42, 144, 64 }, 0, { 0, 0 }, { 43, 118, 13, 255}}},
{{{ -70, 101, 113 }, 0, { 0, 0 }, { 171, 22, 91, 255}}},
{{{ 71, 101, 113 }, 0, { 0, 0 }, { 85, 22, 91, 255}}},
{{{ 49, 62, -139 }, 0, { 0, 0 }, { 50, 73, 166, 255}}},
{{{ 126, 38, -46 }, 0, { 0, 0 }, { 115, 236, 208, 255}}},
{{{ -52, 0, -118 }, 0, { 0, 0 }, { 210, 157, 193, 255}}},
{{{ -49, 62, -138 }, 0, { 0, 0 }, { 206, 26, 143, 255}}},
{{{ 53, 0, -118 }, 0, { 0, 0 }, { 44, 181, 165, 255}}},
{{{ -125, 38, -45 }, 0, { 0, 0 }, { 141, 236, 209, 255}}},
{{{ 86, 1, -60 }, 0, { 0, 0 }, { 32, 134, 254, 255}}},
{{{ -86, 1, -60 }, 0, { 0, 0 }, { 206, 140, 246, 255}}},
};

Vtx VB_marios_cap_geo_0x3022aa0[] = {
{{{ 86, 1, -60 }, 0, { 0, 0 }, { 32, 134, 254, 255}}},
{{{ -86, 1, -60 }, 0, { 0, 0 }, { 206, 140, 246, 255}}},
{{{ -52, 0, -118 }, 0, { 0, 0 }, { 210, 157, 193, 255}}},
{{{ 33, 17, 109 }, 0, { 0, 0 }, { 251, 132, 234, 255}}},
{{{ -32, 17, 109 }, 0, { 0, 0 }, { 0, 131, 240, 255}}},
{{{ -101, 10, -7 }, 0, { 0, 0 }, { 216, 137, 17, 255}}},
{{{ 96, 22, 45 }, 0, { 0, 0 }, { 72, 164, 49, 255}}},
{{{ 103, 10, -6 }, 0, { 0, 0 }, { 66, 150, 18, 255}}},
{{{ 53, 0, -118 }, 0, { 0, 0 }, { 44, 181, 165, 255}}},
};

Vtx VB_marios_cap_geo_0x3022d38[] = {
{{{ 199, 247, -55 }, 0, { 990, 0 }, { 89, 237, 88, 255}}},
{{{ 131, 274, 20 }, 0, { 0, 0 }, { 89, 237, 88, 255}}},
{{{ 69, 71, 38 }, 0, { 0, 2012 }, { 89, 237, 88, 255}}},
{{{ 199, 247, -55 }, 0, { 990, 0 }, { 88, 238, 88, 255}}},
{{{ 69, 71, 38 }, 0, { 0, 2012 }, { 88, 238, 88, 255}}},
{{{ 138, 44, -37 }, 0, { 990, 2012 }, { 88, 238, 88, 255}}},
{{{ -137, 44, -37 }, 0, { 990, 2012 }, { 168, 238, 88, 255}}},
{{{ -68, 71, 38 }, 0, { 0, 2012 }, { 168, 238, 88, 255}}},
{{{ -198, 247, -55 }, 0, { 990, 0 }, { 168, 238, 88, 255}}},
{{{ -68, 71, 38 }, 0, { 0, 2012 }, { 167, 237, 88, 255}}},
{{{ -130, 274, 20 }, 0, { 0, 0 }, { 167, 237, 88, 255}}},
{{{ -198, 247, -55 }, 0, { 990, 0 }, { 167, 237, 88, 255}}},
};

Vtx VB_marios_cap_geo_0x3022df8[] = {
{{{ 268, 219, -132 }, 0, { 990, 0 }, { 89, 237, 87, 255}}},
{{{ 199, 247, -55 }, 0, { 0, 0 }, { 89, 237, 87, 255}}},
{{{ 138, 44, -37 }, 0, { 0, 2012 }, { 89, 237, 87, 255}}},
{{{ 207, 16, -114 }, 0, { 990, 2012 }, { 89, 237, 87, 255}}},
{{{ -206, 16, -114 }, 0, { 990, 2012 }, { 167, 237, 87, 255}}},
{{{ -137, 44, -37 }, 0, { 0, 2012 }, { 167, 237, 87, 255}}},
{{{ -267, 219, -132 }, 0, { 990, 0 }, { 167, 237, 87, 255}}},
{{{ -198, 247, -55 }, 0, { 0, 0 }, { 167, 237, 87, 255}}},
};

Light_t Light_marios_winged_metal_cap_geo_0x301cf28 = {
{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_marios_winged_metal_cap_geo_0x301cf20 = {
{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_marios_winged_metal_cap_geo_0x3022ff8[] = {
gsDPPipeSync(),
gsSPGeometryMode(0, G_TEXTURE_GEN),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
gsDPSetTextureImage(0, 2, 1, marios_winged_metal_cap_geo__texture_0301CF50),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 5, 0, 0, 6, 0),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsDPPipeSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 0, 5, 0, 0, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPTexture(3968, 1984, 0, 0, 1),
gsSPLight(&Light_marios_winged_metal_cap_geo_0x301cf28.col, 1),
gsSPLight(&Light_marios_winged_metal_cap_geo_0x301cf20.col, 2),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b30),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b68),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022cc8),
gsDPPipeSync(),
gsSPGeometryMode(G_TEXTURE_GEN, 0),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPTexture(3968, 1984, 0, 0, 0),
gsDPSetAlphaCompare(0),
gsDPSetEnvColor(255, 255, 255, 255),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022b30[] = {
gsSPVertex(VB_marios_winged_metal_cap_geo_0x3022750, 7, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 0, 0),
gsSP2Triangles(3, 5, 4, 0,2, 3, 0, 0),
gsSP1Triangle(5, 6, 4, 0),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022b68[] = {
gsSPVertex(VB_marios_winged_metal_cap_geo_0x30227c0, 16, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 1, 0),
gsSP2Triangles(3, 1, 0, 0,3, 5, 6, 0),
gsSP2Triangles(3, 0, 5, 0,5, 7, 8, 0),
gsSP2Triangles(5, 8, 6, 0,0, 2, 5, 0),
gsSP2Triangles(6, 9, 10, 0,8, 9, 6, 0),
gsSP2Triangles(11, 8, 7, 0,8, 12, 9, 0),
gsSP2Triangles(12, 8, 11, 0,13, 14, 15, 0),
gsSPVertex(VB_marios_winged_metal_cap_geo_0x30228c0, 15, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 1, 0),
gsSP2Triangles(4, 2, 1, 0,5, 1, 0, 0),
gsSP2Triangles(1, 6, 3, 0,6, 7, 8, 0),
gsSP2Triangles(9, 7, 6, 0,10, 4, 3, 0),
gsSP2Triangles(9, 11, 7, 0,7, 11, 8, 0),
gsSP2Triangles(12, 11, 9, 0,13, 14, 4, 0),
gsSPVertex(VB_marios_winged_metal_cap_geo_0x30229b0, 15, 0),
gsSP2Triangles(0, 1, 2, 0,1, 3, 4, 0),
gsSP2Triangles(5, 3, 1, 0,1, 4, 2, 0),
gsSP2Triangles(4, 3, 6, 0,0, 2, 7, 0),
gsSP2Triangles(8, 7, 2, 0,9, 10, 11, 0),
gsSP2Triangles(12, 10, 9, 0,7, 10, 0, 0),
gsSP2Triangles(10, 7, 11, 0,0, 10, 12, 0),
gsSP2Triangles(11, 8, 13, 0,14, 12, 9, 0),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022cc8[] = {
gsSPVertex(VB_marios_winged_metal_cap_geo_0x3022aa0, 9, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 3, 5, 0,7, 6, 5, 0),
gsSP2Triangles(0, 7, 5, 0,0, 5, 1, 0),
gsSP1Triangle(2, 8, 0, 0),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3023108[] = {
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022ed8),
gsDPSetTextureImage(0, 2, 1, marios_winged_metal_cap_geo__texture_03020750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022e78),
gsDPSetTextureImage(0, 2, 1, marios_winged_metal_cap_geo__texture_03021750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022ea8),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022f20),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022ed8[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022e78[] = {
gsSPVertex(VB_marios_winged_metal_cap_geo_0x3022d38, 12, 0),
gsSP2Triangles(0, 1, 2, 0,3, 4, 5, 0),
gsSP2Triangles(6, 7, 8, 0,9, 10, 11, 0),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022ea8[] = {
gsSPVertex(VB_marios_winged_metal_cap_geo_0x3022df8, 8, 0),
gsSP2Triangles(0, 1, 2, 0,0, 2, 3, 0),
gsSP2Triangles(4, 5, 6, 0,5, 7, 6, 0),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3022f20[] = {
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsSPEndDisplayList(),
};

Gfx DL_marios_winged_metal_cap_geo_0x3023298[] = {
gsDPPipeSync(),
gsSPGeometryMode(0, G_TEXTURE_GEN),
gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
gsDPSetTextureImage(0, 2, 1, marios_winged_metal_cap_geo__texture_0301CF50),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 5, 0, 0, 6, 0),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 128),
gsDPPipeSync(),
gsDPSetTile(0, 2, 16, 0, 0, 0, 0, 5, 0, 0, 6, 0),
gsDPSetTileSize(0, 0, 0, 252, 124),
gsSPTexture(3968, 1984, 0, 0, 1),
gsSPLight(&Light_marios_winged_metal_cap_geo_0x301cf28.col, 1),
gsSPLight(&Light_marios_winged_metal_cap_geo_0x301cf20.col, 2),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b30),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b68),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022cc8),
gsSPTexture(3968, 1984, 0, 0, 0),
gsDPPipeSync(),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING|G_TEXTURE_GEN, 0),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsDPSetTextureImage(0, 2, 1, marios_winged_metal_cap_geo__texture_03020750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022e78),
gsDPSetTextureImage(0, 2, 1, marios_winged_metal_cap_geo__texture_03021750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022ea8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsDPSetAlphaCompare(0),
gsDPSetEnvColor(255, 255, 255, 255),
gsSPEndDisplayList(),
};

Light_t Light_marios_wing_cap_geo_0x301cf40 = {
{ 255, 0, 0}, 0, { 255, 0, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_marios_wing_cap_geo_0x301cf10 = {
{ 115, 6, 0}, 0, { 115, 6, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_marios_wing_cap_geo_0x301cf38 = {
{127, 0, 0}, 0, {127, 0, 0}, 0
};

Ambient_t Light_marios_wing_cap_geo_0x301cf08 = {
{57, 3, 0}, 0, {57, 3, 0}, 0
};

Gfx DL_marios_wing_cap_geo_0x3022f48[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsDPSetTextureImage(0, 2, 1, marios_wing_cap_geo__texture_0301DF50),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_marios_wing_cap_geo_0x301cf40.col, 1),
gsSPLight(&Light_marios_wing_cap_geo_0x301cf38.col, 2),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b30),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
gsSPDisplayList(DL_marios_wing_cap_geo_0x3022d10),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsDPSetAlphaCompare(0),
gsDPSetEnvColor(255, 255, 255, 255),
gsSPEndDisplayList(),
};

Gfx DL_marios_wing_cap_geo_0x3022d10[] = {
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b68),
gsSPLight(&Light_marios_wing_cap_geo_0x301cf10.col, 1),
gsSPLight(&Light_marios_wing_cap_geo_0x301cf08.col, 2),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022cc8),
gsSPEndDisplayList(),
};

Gfx DL_marios_wing_cap_geo_0x30230b0[] = {
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022ed8),
gsDPSetTextureImage(0, 2, 1, marios_wing_cap_geo__texture_0301E750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022e78),
gsDPSetTextureImage(0, 2, 1, marios_wing_cap_geo__texture_0301F750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022ea8),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022f20),
gsSPEndDisplayList(),
};

Gfx DL_marios_wing_cap_geo_0x3023160[] = {
gsDPPipeSync(),
gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 124),
gsDPSetTextureImage(0, 2, 1, marios_wing_cap_geo__texture_0301DF50),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 1023, 256),
gsSPLight(&Light_marios_winged_metal_cap_geo_0x301cf40.col, 1),
gsSPLight(&Light_marios_winged_metal_cap_geo_0x301cf38.col, 2),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022b30),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
gsSPDisplayList(DL_marios_wing_cap_geo_0x3022d10),
gsDPPipeSync(),
gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
gsSPTexture(65535, 65535, 0, 0, 1),
gsDPTileSync(),
gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
gsDPSetTileSize(0, 0, 0, 124, 252),
gsDPSetTextureImage(0, 2, 1, marios_wing_cap_geo__texture_0301E750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022e78),
gsDPSetTextureImage(0, 2, 1, marios_wing_cap_geo__texture_0301F750),
gsDPLoadSync(),
gsDPLoadBlock(7, 0, 0, 2047, 256),
gsSPDisplayList(DL_marios_winged_metal_cap_geo_0x3022ea8),
gsSPTexture(65535, 65535, 0, 0, 0),
gsDPPipeSync(),
gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
gsDPSetAlphaCompare(0),
gsDPSetEnvColor(255, 255, 255, 255),
gsSPEndDisplayList(),
};

