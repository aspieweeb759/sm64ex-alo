#include "custom.model.inc.h"
const GeoLayout checkerboard_platform_geo[]= {
GEO_CULLING_RADIUS(400),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_checkerboard_platform_geo_0x800d680),
GEO_CLOSE_NODE(),
GEO_END(),
};
